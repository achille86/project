package it.usi.xframe.cs0.wsutil.ConditionEstimate;


import it.usi.xframe.utl.bfutil.ResponseClass;

import java.io.Serializable;

public class ConditionEstimateResponseClass extends ResponseClass implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String rc_rc = "";
	private String rc_tgmess_tipo = "";
	private String rc_err_desc = "";
	private ConditionEstimateManagementInOut creditEstimateManagementInOut;
	
	public String getRc_rc() {
		return rc_rc;
	}
	public void setRc_rc(String rc_rc) {
		this.rc_rc = rc_rc;
	}
	public String getRc_tgmess_tipo() {
		return rc_tgmess_tipo;
	}
	public void setRc_tgmess_tipo(String rc_tgmess_tipo) {
		this.rc_tgmess_tipo = rc_tgmess_tipo;
	}
	public String getRc_err_desc() {
		return rc_err_desc;
	}
	public void setRc_err_desc(String rc_err_desc) {
		this.rc_err_desc = rc_err_desc;
	}
	public ConditionEstimateManagementInOut getCreditEstimateManagementInOut() {
		return creditEstimateManagementInOut;
	}
	public void setCreditEstimateManagementInOut(
			ConditionEstimateManagementInOut creditEstimateManagementInOut) {
		this.creditEstimateManagementInOut = creditEstimateManagementInOut;
	}
}
