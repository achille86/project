package it.usi.xframe.cs0.bfimpl.conditionEstimate;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import it.usi.xframe.cs0.bfimpl.pm.CS0PersistenceManager;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryManagementInOut;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryResponseClass;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateManagementInOut;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateResponseClass;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.utl.bfutil.FormatUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ConditionEstimatePersistanceManager extends CS0PersistenceManager {
	private Log logger = LogFactory.getLog(this.getClass());
	
	private static ConditionEstimatePersistanceManager instance;

	public static ConditionEstimatePersistanceManager getInstance() {

		if (instance == null)
			instance = new ConditionEstimatePersistanceManager();

		return instance;
	}
		
	
	
	public ConditionEstimateResponseClass getConditionEstimate(ConditionEstimateManagementInOut inOut) throws XFRException,	RemoteException {

		logger.info("ConditionCreditEstimatePersistanceManager.getConditionEstimate ---- begin");

		ConditionEstimateResponseClass responseClass = new ConditionEstimateResponseClass();
		String messageCode = "";

		Connection connection = getConnectionForCOBOLStoreProcedure("CS0SPPSO",	true);
		CallableStatement statement = null;

		// preparo lo statement con la chiamata alla stored procedure
		try {
			String sql = "CALL DB2C.CS0SPPSO(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			statement = connection.prepareCall(sql);

			// Parametri di input
			statement.registerOutParameter(1, Types.DECIMAL);
			statement.registerOutParameter(2, Types.VARCHAR);
			statement.registerOutParameter(3, Types.VARCHAR);
			statement.registerOutParameter(4, Types.VARCHAR);
			statement.registerOutParameter(5, Types.VARCHAR);
			statement.registerOutParameter(6, Types.DECIMAL);
			statement.registerOutParameter(7, Types.DECIMAL);
			statement.registerOutParameter(8, Types.VARCHAR);
			statement.registerOutParameter(9, Types.VARCHAR);
			statement.registerOutParameter(10, Types.VARCHAR);
			statement.registerOutParameter(11, Types.DECIMAL);
			statement.registerOutParameter(12, Types.VARCHAR);
			statement.registerOutParameter(13, Types.DECIMAL);
			statement.registerOutParameter(14, Types.DECIMAL);
			statement.registerOutParameter(15, Types.DECIMAL);

			// parametri di output
			statement.registerOutParameter(16, Types.DECIMAL);
			statement.registerOutParameter(17, Types.VARCHAR);
			statement.registerOutParameter(18, Types.VARCHAR);
			statement.registerOutParameter(19, Types.DECIMAL);
			statement.registerOutParameter(20, Types.DECIMAL);
			statement.registerOutParameter(21, Types.DECIMAL);
			statement.registerOutParameter(22, Types.VARCHAR);
			statement.registerOutParameter(23, Types.VARCHAR);
			statement.registerOutParameter(24, Types.VARCHAR);
			statement.registerOutParameter(25, Types.VARCHAR);
			statement.registerOutParameter(26, Types.DECIMAL);
			statement.registerOutParameter(27, Types.VARCHAR);
			statement.registerOutParameter(28, Types.DECIMAL);
			statement.registerOutParameter(29, Types.DECIMAL);
			statement.registerOutParameter(30, Types.VARCHAR);
			statement.registerOutParameter(31, Types.VARCHAR);
			statement.registerOutParameter(32, Types.VARCHAR);
			statement.registerOutParameter(33, Types.VARCHAR);
			statement.registerOutParameter(34, Types.DECIMAL);
			statement.registerOutParameter(35, Types.DECIMAL);
			statement.registerOutParameter(36, Types.VARCHAR);
			statement.registerOutParameter(37, Types.VARCHAR);
			statement.registerOutParameter(38, Types.DECIMAL);

			// valorizzazione input
			if (inOut.getEstimateNumber() == null
					|| " ".equalsIgnoreCase(inOut.getEstimateNumber())
					|| "".equalsIgnoreCase(inOut.getEstimateNumber())
					|| !StringUtils.isNumeric(inOut.getEstimateNumber())) {
				inOut.setEstimateNumber("0");
			}
			statement.setBigDecimal(1, new BigDecimal(inOut.getEstimateNumber()));
			logger.debug("estimateNumber 1: " + inOut.getEstimateNumber());

			statement.setString(2, FormatUtils.formatString(inOut.getCodFtf()));
			logger.debug("codFtf 2: " + inOut.getCodFtf());
			
			statement.setString(3, FormatUtils.formatString(inOut.getDescFtf()));
			logger.debug("descFtf 3: " + inOut.getDescFtf());
			
			statement.setString(4, FormatUtils.formatString(inOut.getFtf()));
			logger.debug("ftf 4: " + inOut.getFtf());
			
			statement.setString(5, FormatUtils.formatString(inOut.getPosition()));
			logger.debug("position 5: " + inOut.getPosition());
						
			if (inOut.getAmount() == null
					|| " ".equalsIgnoreCase(inOut.getAmount())
					|| "".equalsIgnoreCase(inOut.getAmount())
					|| !StringUtils.isNumeric(inOut.getAmount())) {
				inOut.setAmount("0");
			}
			statement.setBigDecimal(6, new BigDecimal(inOut.getAmount()));
			logger.debug("amount 6: " + inOut.getAmount());
			
			if (inOut.getPeriod() == null
					|| " ".equalsIgnoreCase(inOut.getPeriod())
					|| "".equalsIgnoreCase(inOut.getPeriod())
					|| !StringUtils.isNumeric(inOut.getPeriod())) {
				inOut.setPeriod("0");
			}
			statement.setBigDecimal(7, new BigDecimal(inOut.getPeriod()));
			logger.debug("period() 7: " + inOut.getPeriod());
			
			statement.setString(8, FormatUtils.formatString(inOut.getUserId()));
			logger.debug("userid 8: " + inOut.getUserId());
			
			statement.setString(9, FormatUtils.formatString(inOut.getNdg()));
			logger.debug("ndg 9: " + inOut.getNdg());
			
			statement.setString(10, FormatUtils.formatString(inOut.getNote()));
			logger.debug("userid 10: " + inOut.getNote());
			
			if (inOut.getBranch() == null
					|| " ".equalsIgnoreCase(inOut.getBranch())
					|| "".equalsIgnoreCase(inOut.getBranch())
					|| !StringUtils.isNumeric(inOut.getBranch())) {
				inOut.setBranch("0");
			}
			statement.setBigDecimal(11, new BigDecimal(inOut.getBranch()));
			logger.debug("branch 11: " + inOut.getBranch());
			
			statement.setString(12, FormatUtils.formatString(inOut.getAccountType()));
			logger.debug("userid 12: " + inOut.getTypeRate());
			
			statement.setString(13, FormatUtils.formatString(inOut.getAccount()));
			logger.debug("userid 13: " + inOut.getAccount());
			
			if (inOut.getCost() == null
					|| " ".equalsIgnoreCase(inOut.getCost())
					|| "".equalsIgnoreCase(inOut.getCost())
					|| !StringUtils.isNumeric(inOut.getCost())) {
				inOut.setCost("0");
			}
			statement.setBigDecimal(14, new BigDecimal(inOut.getCost()));
			logger.debug("branch 14: " + inOut.getCost());
			
			if (inOut.getCost() == null
					|| " ".equalsIgnoreCase(inOut.getCost())
					|| "".equalsIgnoreCase(inOut.getCost())
					|| !StringUtils.isNumeric(inOut.getCost())) {
				inOut.setCost("0");
			}
			statement.setBigDecimal(15, new BigDecimal(inOut.getPeriodDay()));
			logger.debug("periodDay 15: " + inOut.getPeriodDay());
			
			// richiamo della stored
			statement.execute();


			inOut = output(statement);
			responseClass.setCreditEstimateManagementInOut(inOut);

		} catch (SQLException e) {
			// e.printStackTrace();
			logger.info("ConditionEstimatePersistanceManager.getConditionEstimate - error (1): "
					+ e.getMessage());
			throw new XFRException(e);
		} finally {
			try {
				// chiudo connessione e statement per liberare risorse
				connection.close();
				statement.close();
			} catch (SQLException e) {
				// e.printStackTrace();
				logger.info("ConditionEstimatePersistanceManager.getConditionEstimate - error (2): "
						+ e.getMessage());
				throw new XFRException(e);
			}
		}

		logger.info("ConditionCreditInquiryPersistanceManager.getConditionCreditInquiry ---- end");
		return responseClass;
	}
		
	
	private ConditionEstimateManagementInOut output(CallableStatement statement) throws XFRException, RemoteException {
		logger.debug("ConditionEstimateManagementInOut.output ---- begin");

		ConditionEstimateManagementInOut inOut = new ConditionEstimateManagementInOut();

		try {
			inOut.setTan(statement.getString("LK_O_TAN"));
			inOut.setParameter(statement.getString("LK_O_PARAMETRO"));
			inOut.setTypeRate(statement.getString("LK_O_TIPO_TASSO"));
			inOut.setDif(statement.getString("LK_O_DIF"));
			inOut.setTaeg(statement.getString("LK_O_TAEG"));
			inOut.setOtherExpenses(statement.getString("LK_O_ALTRE_SPESE"));
			inOut.setFtr(statement.getString("LK_O_F_TEC_RAP"));
			inOut.setDateInput(statement.getString("LK_O_DATA_INS"));
			inOut.setExpirationDate(statement.getString("LK_O_DATA_SCA"));
			inOut.setNdg(statement.getString("LK-O-NDG"));
			inOut.setAccFido(statement.getString("LK_O_ACC_FIDO"));
			inOut.setDescFtf(statement.getString("LK_O_DESC_FT_FIDO"));
			inOut.setPeriod(statement.getString("LK-O-DURATA"));
			inOut.setSpread(statement.getString("LK-O-SPREAD"));
			inOut.setSQLCODE(statement.getString("LK-O-SQLCODE"));
			inOut.setMessageType(statement.getString("LK-O-TIPO-MSG"));
			inOut.setMessageNumber(statement.getString("LK-O-NUM-MSG"));
			inOut.setTable(statement.getString("LK-O-TABELLA"));
			inOut.setTotAmount(statement.getString("LK-O-IMPORTO-TOT"));
			inOut.setInstalmentAmount(statement.getString("LK-O-IMPORTO-RATA"));
			inOut.setCurrency(statement.getString("LK-O-DIVISA"));
			inOut.setInstallmentPeriod(statement.getString("LK-O-PERIOD-RATA"));
			inOut.setTaex(statement.getString("LK-O-TAEX"));
			
			
		} catch (SQLException e) {
			//e.printStackTrace();
			logger.info("ConditionEstimatePersistanceManager.output - error (1): " + e.getMessage());
		}
		
		logger.debug("ConditionEstimatePersistanceManager.output ---- end");
		return inOut;
	}
	

}
