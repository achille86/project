package it.usi.xframe.cs0.wsutil.ConditionEstimate;


public interface ConditionEstimateWS_SEI extends java.rmi.Remote
{
  public it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateResponse conditionEstimate(it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateIn request) throws it.usi.xframe.system.errors.XFRException,java.text.ParseException;
}