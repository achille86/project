package it.usi.xframe.cs0.wsutil.ConditionEstimate;

public class ConditionEstimateManagementInOut {
	
	//Input
	private String estimateNumber = "";   //LK-I-INUM-PREV
	private String codFtf = "";           //LK-I-COD-FT-FIDO
	private String descFtf = "";          //LK-I-DESC-FT-FIDO
	private String ftf = "";			  //LK-I-FM-TEC-FIDO
	private String position = "";		  //LK-I-POSIZIONE
	private String amount = "";           //LK-I-IMPORTO
	private String period = "";           //LK-I-DURATA
	private String userId = "";			  //LK-I-MAT-OPE
	private String ndg = "";			  //LK-I-NDG
	private String note = "";			  //LK-I-NOTE
	private String branch = "";			  //LK-I-DIP
	private String accountType = "";	  //LK-I-TIPORAPP
	private String account = "";		  //LK-I-CONTO
	private String cost = "";			  //LK-I-SPESE-INIZ
	private String periodDay = "";		  //LK-I-DURATA-GG
	
	//Output
	private String tan = "";              //LK-O-TAN
	private String parameter = "";	      //LK-O-PARAMETRO
	private String typeRate = "";         //LK-O-TIPO-TASSO
	private String dif = "";              //LK-O-DIF
	private String taeg = "";             //LK-O-TAEG
	private String otherExpenses = "";    //LK-O-ALTRE-SPESE
	private String ftr	= "";		      //LK-O-F-TEC-RAP
	private String dateInput = "";        //LK-O-DATA-INS
	private String expirationDate = "";   //LK-O-DATA-SCA
	private String ndgOut = "";			  //LK-O-NDG
	private String accFido = "";		  //LK-O-ACC-FIDO
	private String descFtfOut = "";		  //LK-O-DESC-FT-FIDO
	private String periodOut = "";		  //LK-O-DURATA
	private String spread = "";			  //LK-O-SPREAD		
	private String SQLCODE = "";		  //LK-O-SQLCODE
	private String messageType = "";      //LK-O-TIPO-MSG
	private String messageNumber = "";	  //LK-O-NUM-MSG
	private String table = "";            //LK-O-TABELLA 
	private String totAmount = "";		  //LK-O-IMPORTO-TOT
	private String instalmentAmount = ""; //LK-O-IMPORTO-RATA
	private String currency = "";		  //LK-O-DIVISA
	private String installmentPeriod = "";//LK-O-PERIOD-RATA
	private String taex = "";			  //LK-O-TAEX
	
	public String getEstimateNumber() {
		return estimateNumber;
	}
	public void setEstimateNumber(String estimateNumber) {
		this.estimateNumber = estimateNumber;
	}
	public String getCodFtf() {
		return codFtf;
	}
	public void setCodFtf(String codFtf) {
		this.codFtf = codFtf;
	}
	public String getDescFtf() {
		return descFtf;
	}
	public void setDescFtf(String descFtf) {
		this.descFtf = descFtf;
	}
	public String getFtf() {
		return ftf;
	}
	public void setFtf(String ftf) {
		this.ftf = ftf;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNdg() {
		return ndg;
	}
	public void setNdg(String ndg) {
		this.ndg = ndg;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getPeriodDay() {
		return periodDay;
	}
	public void setPeriodDay(String periodDay) {
		this.periodDay = periodDay;
	}
	public String getTan() {
		return tan;
	}
	public void setTan(String tan) {
		this.tan = tan;
	}
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	public String getTypeRate() {
		return typeRate;
	}
	public void setTypeRate(String typeRate) {
		this.typeRate = typeRate;
	}
	public String getDif() {
		return dif;
	}
	public void setDif(String dif) {
		this.dif = dif;
	}
	public String getTaeg() {
		return taeg;
	}
	public void setTaeg(String taeg) {
		this.taeg = taeg;
	}
	public String getOtherExpenses() {
		return otherExpenses;
	}
	public void setOtherExpenses(String otherExpenses) {
		this.otherExpenses = otherExpenses;
	}
	public String getFtr() {
		return ftr;
	}
	public void setFtr(String ftr) {
		this.ftr = ftr;
	}
	public String getDateInput() {
		return dateInput;
	}
	public void setDateInput(String dateInput) {
		this.dateInput = dateInput;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getNdgOut() {
		return ndgOut;
	}
	public void setNdgOut(String ndgOut) {
		this.ndgOut = ndgOut;
	}
	public String getAccFido() {
		return accFido;
	}
	public void setAccFido(String accFido) {
		this.accFido = accFido;
	}
	public String getDescFtfOut() {
		return descFtfOut;
	}
	public void setDescFtfOut(String descFtfOut) {
		this.descFtfOut = descFtfOut;
	}
	public String getPeriodOut() {
		return periodOut;
	}
	public void setPeriodOut(String periodOut) {
		this.periodOut = periodOut;
	}
	public String getSpread() {
		return spread;
	}
	public void setSpread(String spread) {
		this.spread = spread;
	}
	public String getSQLCODE() {
		return SQLCODE;
	}
	public void setSQLCODE(String sQLCODE) {
		SQLCODE = sQLCODE;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getMessageNumber() {
		return messageNumber;
	}
	public void setMessageNumber(String messageNumber) {
		this.messageNumber = messageNumber;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public String getTotAmount() {
		return totAmount;
	}
	public void setTotAmount(String totAmount) {
		this.totAmount = totAmount;
	}
	public String getInstalmentAmount() {
		return instalmentAmount;
	}
	public void setInstalmentAmount(String instalmentAmount) {
		this.instalmentAmount = instalmentAmount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getInstallmentPeriod() {
		return installmentPeriod;
	}
	public void setInstallmentPeriod(String installmentPeriod) {
		this.installmentPeriod = installmentPeriod;
	}
	public String getTaex() {
		return taex;
	}
	public void setTaex(String taex) {
		this.taex = taex;
	}
}
