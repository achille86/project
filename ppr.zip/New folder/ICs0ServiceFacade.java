/*
 * Created on Sep 21, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package it.usi.xframe.cs0.bfintf;


import it.usi.xframe.cs0.bfutil.accountReservation.AccountReservationInOut;
import it.usi.xframe.cs0.bfutil.accountReservation.AccountReservationResponseClass;
import it.usi.xframe.cs0.bfutil.accountReservation.ProductListResponseClass;
import it.usi.xframe.cs0.bfutil.activeAccount.ActiveAccountInOut;
import it.usi.xframe.cs0.bfutil.activeAccount.ActiveAccountResponseClass;
import it.usi.xframe.cs0.bfutil.ccd.CcdPrintResponseClass;
import it.usi.xframe.cs0.bfutil.ccd.ComboBox;
import it.usi.xframe.cs0.bfutil.ccd.Preventivo;
import it.usi.xframe.cs0.bfutil.ccd.StampaInOut;
import it.usi.xframe.cs0.bfutil.condition.Condition;
import it.usi.xframe.cs0.bfutil.condition.ConditionCodeListResponseClass;
import it.usi.xframe.cs0.bfutil.condition.ConditionParameterResponseClass;
import it.usi.xframe.cs0.bfutil.condition.ConditionRequestValidationResponseClass;
import it.usi.xframe.cs0.bfutil.condition.FacultyResponseClass;
import it.usi.xframe.cs0.bfutil.condition.FindAccountResponseClass;
import it.usi.xframe.cs0.bfutil.condition.NotesResponseClass;
import it.usi.xframe.cs0.bfutil.condition.derogation.OpenCondition;
import it.usi.xframe.cs0.bfutil.consultation.ConsultationInOut;
import it.usi.xframe.cs0.bfutil.consultation.ConsultationResponseClass;
import it.usi.xframe.cs0.bfutil.cs0Exceptions.CcdException;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableBankFeaturesInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableBlockedValuesForFTInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableBlockedValuesForFTResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableCommunicationTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableCommunicationTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableConditionInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDeductionPercentageInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDeductionPercentageResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDiscountGroupInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDiscountGroupResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableJustifiedMotivationInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableJustifiedMotivationResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableLanguageInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableLanguageResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeFTInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeFTResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableSpreadAdjustmentResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableStructureTableInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableTechnicalTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableTechnicalTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.IndexedRateRegistryInOut;
import it.usi.xframe.cs0.bfutil.domainTable.SpreadAdjustmentInOut;
import it.usi.xframe.cs0.bfutil.erfolgsCard.ErfolgsCardFilterInOut;
import it.usi.xframe.cs0.bfutil.erfolgsCard.ErfolgsCardResponseClass;
import it.usi.xframe.cs0.bfutil.fastCredit.FastCreditBean;
import it.usi.xframe.cs0.bfutil.fastCredit.FastCreditResponseClass;
import it.usi.xframe.cs0.bfutil.features.Features;
import it.usi.xframe.cs0.bfutil.features.FeaturesInOut;
import it.usi.xframe.cs0.bfutil.features.FeaturesResponseClass;
import it.usi.xframe.cs0.bfutil.features.InputParamsFeatures;
import it.usi.xframe.cs0.bfutil.general.AccountType;
import it.usi.xframe.cs0.bfutil.general.Cs0Account;
import it.usi.xframe.cs0.bfutil.general.InputCS0;
import it.usi.xframe.cs0.bfutil.general.InputDetail;
import it.usi.xframe.cs0.bfutil.general.InputRequest;
import it.usi.xframe.cs0.bfutil.general.JustifiedMotivationInOut;
import it.usi.xframe.cs0.bfutil.general.MovementStatisticInOut;
import it.usi.xframe.cs0.bfutil.general.MovementStatisticResponseClass;
import it.usi.xframe.cs0.bfutil.general.UserRoleResponseClass;
import it.usi.xframe.cs0.bfutil.general.ViewPTCTInOut;
import it.usi.xframe.cs0.bfutil.general.ViewPTCTResponseClass;
import it.usi.xframe.cs0.bfutil.ifjava.CS0OpenParamsElement;
import it.usi.xframe.cs0.bfutil.informativeReport.InformativeReport;
import it.usi.xframe.cs0.bfutil.loan.LoanAnagInOut;
import it.usi.xframe.cs0.bfutil.loan.LoanResponseClass;
import it.usi.xframe.cs0.bfutil.loanStandardRate.LoanStandardRateInOut;
import it.usi.xframe.cs0.bfutil.loanStandardRate.LoanStandardRateResponseClass;
import it.usi.xframe.cs0.bfutil.massiveVariation.MassiveVariationInOut;
import it.usi.xframe.cs0.bfutil.massiveVariation.MassiveVariationResponseClass;
import it.usi.xframe.cs0.bfutil.massiveVariation.MassiveVariationSQLResponseClass;
import it.usi.xframe.cs0.bfutil.outOfAutonomy.OutOfAutonomyRequest;
import it.usi.xframe.cs0.bfutil.outOfAutonomy.OutOfAutonomyRequestAccount;
import it.usi.xframe.cs0.bfutil.outOfAutonomy.OutOfAutonomyRequestResponseClass;
import it.usi.xframe.cs0.bfutil.position.AccountListPositionResponseClass;
import it.usi.xframe.cs0.bfutil.position.ConditionDetailPositionResponseClass;
import it.usi.xframe.cs0.bfutil.position.DerogableConditionsForPositionInOut;
import it.usi.xframe.cs0.bfutil.position.InputSearchPosition;
import it.usi.xframe.cs0.bfutil.position.PositionBean;
import it.usi.xframe.cs0.bfutil.position.PositionResponseClass;
import it.usi.xframe.cs0.bfutil.position.PromotionalPositions;
import it.usi.xframe.cs0.bfutil.position.SimplePosition;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardAmountInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardBaseInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardBaseRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardBidRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardCmsLoanRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardCodeInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardConditionResponseClass;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardCurrenciesInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardPercentageInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardPortfolioRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardValuesInOut;
import it.usi.xframe.cs0.bfutil.technicalType.InputSearchTechnicalType;
import it.usi.xframe.cs0.bfutil.technicalType.TechnicalTypeResponseClass;
import it.usi.xframe.cs0.bfutil.utilities.CommonParameters;
import it.usi.xframe.cs0.bfutil.x4eyes.X4eyesInOut;
import it.usi.xframe.cs0.bfutil.x4eyes.X4eyesResponseClass;
import it.usi.xframe.cs0.bfutil.yourConditions.YourConditionsInOut;
import it.usi.xframe.cs0.bfutil.yourConditions.YourConditionsResponseClass;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryManagementInOut;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryResponseClass;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateManagementInOut;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateResponseClass;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.system.eservice.IServiceFacade;
import it.usi.xframe.utl.bfutil.DomainParams;
import it.usi.xframe.utl.bfutil.GaussResponse;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;



/**
 * @author US01147
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * @modelguid {C4755D53-69C1-4E2B-800A-7ECBEB578768}
 */
public interface ICs0ServiceFacade extends IServiceFacade {
	
	public abstract OutOfAutonomyRequestResponseClass retrieveOutOfAutonomySynthesysForPDF(OutOfAutonomyRequest outOfAutonomyRequest,OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani ) throws XFRException, RemoteException ;
	public abstract Cs0Account retrieveConditionsList (InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionsListDetail (InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionsListLoan(InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionsListPTF(InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionSynthesis (InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionDetail (InputCS0 params, InputDetail detailParams, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionDetailPortaf (InputCS0 params, InputDetail detailParams, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionDetailTapa (InputCS0 params, InputDetail detailParams, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account retrieveConditionDetailLoan (InputCS0 params, InputDetail detailParams, CommonParameters cP)throws XFRException, RemoteException;

	public abstract FindAccountResponseClass findAccount(InputCS0 inputCS0, UserData userInfo) throws XFRException, RemoteException;
	
	public abstract ConditionRequestValidationResponseClass validateDetailRequest(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail,JustifiedMotivationInOut justifiedMotivationInOut,CommonParameters cP) throws XFRException, RemoteException;
	public abstract ConditionRequestValidationResponseClass confirmDetailRequest(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail, JustifiedMotivationInOut justifiedMotivationInOut,CommonParameters cP) throws XFRException, RemoteException;
	public abstract ConditionRequestValidationResponseClass confirmChangeRequest(InputCS0 cs0Params, Condition condition, CommonParameters cP) throws XFRException, RemoteException;
	public abstract ConditionRequestValidationResponseClass rollback(InputCS0 cs0Params, CommonParameters cP) throws XFRException, RemoteException;
	public abstract ConditionCodeListResponseClass retrieveCodeList(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException;
	public abstract ConditionParameterResponseClass retrieveParameterList(InputCS0 cs0Params, CommonParameters cP) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveSegmentList(CommonParameters cP) throws XFRException, RemoteException;

	public abstract FacultyResponseClass retrieveFaculty(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract FacultyResponseClass retrieveFacultyCode(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract FacultyResponseClass retrieveFacultyDay(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;

	public abstract NotesResponseClass retrieveNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse insertNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract NotesResponseClass retrievePositionNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse insertPositionNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;

	public abstract PositionResponseClass retrieveSearchPosition (PositionBean position, CommonParameters cP)throws XFRException, RemoteException;
	public abstract PositionResponseClass retrieveSearchPosition (PositionBean position, CommonParameters cP, boolean fastCreditFlag )throws XFRException, RemoteException;
	public abstract TechnicalTypeResponseClass retrieveSearchTechnicalType (InputCS0 params, InputSearchTechnicalType techTypeParams, CommonParameters cP)throws XFRException, RemoteException;
	public abstract GaussResponse verifyTT(InputCS0 params, InputSearchTechnicalType techTypeParams, CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse changeTT(InputCS0 params, InputSearchTechnicalType techTypeParams, CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse retrieveChangerPosition(InputCS0 params, InputSearchPosition posParams, CommonParameters cP) throws XFRException, RemoteException;
	
	public abstract Cs0Account[] retrieveHistory (InputCS0 params, CommonParameters cP, InputDetail inputDetail)throws XFRException, RemoteException;
	public abstract GaussResponse retrieveVerifyPosition(InputCS0 params, InputSearchPosition posParams, CommonParameters cP) throws XFRException, RemoteException;
	public abstract InformativeReport retrieveInformativeProspect (InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account[] retrieveRegistryHistory (InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract Cs0Account[] retrieveHistoryOnLine(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException;
	
	public abstract Cs0Account retrieveConditionsListChannel(InputCS0 params, CommonParameters cP)throws XFRException, RemoteException;
	public abstract AccountType[] retrieveAccountTypeList(CommonParameters cP) throws XFRException, RemoteException;
	public abstract Features retrieveSpecialInquiry( InputParamsFeatures  featuresParams, CommonParameters cP) throws XFRException, RemoteException;
	public abstract Features retrieveFeaturesHistory( InputParamsFeatures  featuresParams, CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse verifyFeatures(InputParamsFeatures featuresParams, CommonParameters cP) throws XFRException, RemoteException;	
	public abstract GaussResponse changeFeatures(InputParamsFeatures featuresParams, CommonParameters cP) throws XFRException, RemoteException;
	
	public abstract ArrayList retrieveOutOfAutonomyStateList(CommonParameters cP) throws XFRException, RemoteException;
	public abstract OutOfAutonomyRequestResponseClass[] retrieveOutOfAutonomyAccountList(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException;
	public abstract OutOfAutonomyRequestResponseClass[] retrieveOutOfAutonomyPositionList(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani) throws XFRException, RemoteException;
	public abstract OutOfAutonomyRequestResponseClass retrieveOutOfAutonomyAccountInquiry(OutOfAutonomyRequest outOfAutonomyRequest,OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani) throws XFRException, RemoteException;
	public abstract OutOfAutonomyRequestResponseClass retrieveOutOfAutonomyPositionInquiry(OutOfAutonomyRequest outOfAutonomyRequest, PositionBean position, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani) throws XFRException, RemoteException;
	public abstract OutOfAutonomyRequestResponseClass retrieveOutOfAutonomyHistorical( OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	
	
	public abstract GaussResponse verifyOutOfAutonomyOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse modifyOutOfAutonomyOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException;
	
//	public abstract PositionResponseClass retrievePositionDetail (PositionBean pBean, CommonParameters cP)throws XFRException, RemoteException;
	public abstract PositionResponseClass retrieveConditionsSynthesisPosition(CommonParameters cP, PositionBean pB, Map conditionParam)throws XFRException, RemoteException;

	public abstract PositionResponseClass retrieveConditionsListPosition(CommonParameters cP, PositionBean  pBean, Map conditionParam)throws XFRException, RemoteException;
	public abstract PositionResponseClass[] retrievePositionHistory (PositionBean pBean, CommonParameters cP)throws XFRException, RemoteException;
	public abstract PositionResponseClass retrieveHistoryConditionDetail(PositionBean positionBean, CommonParameters cP, Map conditionParam)throws XFRException, RemoteException;
	public abstract PositionResponseClass retrievePositionLoanFHistory(CommonParameters cP, PositionBean pBean, Map conditionParam)throws XFRException, RemoteException;
	public abstract ConditionDetailPositionResponseClass retrieveConditionDetail(PositionBean positionBean, CommonParameters cP, Map conditionParam)throws XFRException, RemoteException;
	public abstract AccountListPositionResponseClass retrieveAccountListPosition(PositionBean pBean, PositionBean fBean ,CommonParameters cP, Map navParam)throws XFRException, RemoteException;
	
	public abstract PositionResponseClass replyPosition(String action, PositionBean position, CommonParameters cP) throws XFRException, RemoteException;
	public abstract HashMap retrievePositionProperties(CommonParameters cP) throws XFRException, RemoteException;
	public abstract String retrieveSingleProperty(String resourceName,String code,CommonParameters cP) throws XFRException, RemoteException;
	public abstract PositionResponseClass performAction(String action, PositionBean position, CommonParameters cP) throws XFRException, RemoteException;
	public abstract UserRoleResponseClass retrieveUserRole(CommonParameters cP) throws XFRException, RemoteException;
	public abstract UserRoleResponseClass retrieveUserRoleMod(CommonParameters cP) throws XFRException, RemoteException;
	public abstract UserRoleResponseClass retrieveConditionUserRole(CommonParameters cP) throws XFRException, RemoteException;
	public abstract PositionResponseClass performExpiration(String action, PositionBean position, CommonParameters cP) throws XFRException, RemoteException;
	
	public abstract ConditionRequestValidationResponseClass validateDetailRequestPosition(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail , JustifiedMotivationInOut justifiedMotivationInOut  ,CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse confirmDetailRequestPosition(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail, JustifiedMotivationInOut justifiedMotivationInOut ,CommonParameters cP) throws XFRException, RemoteException;	
	
	public abstract FacultyResponseClass retrieveFacultyByPos(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract FacultyResponseClass retrieveFacultyCodeByPos(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract FacultyResponseClass retrieveFacultyDayByPos(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException;
	public abstract LoanStandardRateResponseClass retrieveLoanStandardRate( LoanStandardRateInOut loanStandardRateInOut) throws XFRException, RemoteException;

	public abstract GaussResponse verifyPositionOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException;
	public abstract GaussResponse modifyPositionOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException;
	
	public abstract PositionResponseClass retrieveDerogableConditionsList(DerogableConditionsForPositionInOut derogableConditionsForPositionInOut) throws XFRException, RemoteException;
			
	// Standard Conditions
	public abstract StandardConditionResponseClass retrieveStandardAmount(StandardBaseInOut standardBaseInOut,StandardAmountInOut standardAmountInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass retrieveStandardCode(StandardBaseInOut standardBaseInOut, StandardCodeInOut standardCodeInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardAmount(StandardBaseInOut standardBaseInOut, StandardAmountInOut standardAmountInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardCode(StandardBaseInOut standardBaseInOut, StandardCodeInOut standardCodeInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardAmount(StandardBaseInOut standardBaseInOut, StandardAmountInOut standardAmountInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass retrieveStandardValues(StandardBaseInOut standardBaseInOut,StandardValuesInOut standardValuesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardValues(StandardBaseInOut standardBaseInOut, StandardValuesInOut standardValuesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardValues(StandardBaseInOut standardBaseInOut, StandardValuesInOut standardValuesInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass retrieveStandardPercentage(StandardBaseInOut standardBaseInOut,StandardPercentageInOut standardPercentageInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardPercentage(StandardBaseInOut standardBaseInOut, StandardPercentageInOut standardPercentageInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardPercentage(StandardBaseInOut standardBaseInOut, StandardPercentageInOut standardPercentageInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass retrieveStandardCurrency(StandardBaseInOut standardBaseInOut,StandardCurrenciesInOut standardCurrenciesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardCurrency(StandardBaseInOut standardBaseInOut, StandardCurrenciesInOut standardCurrenciesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardCurrency(StandardBaseInOut standardBaseInOut, StandardCurrenciesInOut standardCurrenciesInOut) throws XFRException, RemoteException;
	
	 // Standard Conditions Rate
	public abstract StandardConditionResponseClass retrieveStandardCmsLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardCmsLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardCmsLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass retrieveStandardCmsExtraLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardCmsExtraLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardCmsExtraLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass retrieveStandardPortfolioRate(StandardBaseRateInOut standardBaseRateInOut, StandardPortfolioRateInOut standardPortfolioRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardPortfolioRate(StandardBaseRateInOut standardBaseRateInOut, StandardPortfolioRateInOut standardPortfolioRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardPortfolioRate(StandardBaseRateInOut standardBaseRateInOut, StandardPortfolioRateInOut standardPortfolioRateInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass retrieveStandardBidRate(StandardBaseRateInOut standardBaseRateInOut, StandardBidRateInOut standardBidRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass checkChangeStandardBidRate(StandardBaseRateInOut standardBaseRateInOut, StandardBidRateInOut standardBidRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract StandardConditionResponseClass deleteFacultyStandardBidRate(StandardBaseRateInOut standardBaseRateInOut, StandardBidRateInOut standardBidRateInOut) throws XFRException, RemoteException;
	
	// Domain Tables
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableAccountTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass changeTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveIndexedRate(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeIndexedRateRegistry(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass insertValuesIndexedRateRegistry(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveConditionListDetail(DomainTableConditionInOut conditionInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveConditionHistory(DomainTableConditionInOut conditionInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass modifyCondition(DomainTableConditionInOut conditionInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass insertCondition(DomainTableConditionInOut conditionInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass deleteCondition(DomainTableConditionInOut conditionInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass replyCondition(DomainTableConditionInOut conditionInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass historyDetail(DomainTableConditionInOut conditionInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveLoanTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeLoanTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDocumentTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDocumentTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableAccountType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableAccountType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTablePermission(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTablePermission(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableStructureTable(DomainTableStructureTableInOut domainTableStructureTableInOut ) throws XFRException , RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableHierarchcalLevel(DomainTableStructureTableInOut domainTableStructureTableInOut) throws XFRException , RemoteException ;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableHierarchicalLevel(DomainTableStructureTableInOut domainTableStructureTableInOut) throws XFRException, RemoteException; 
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableFeatureCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableFeatureCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableChannels(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableChannels(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableBankFeatures(DomainTableBankFeaturesInOut domainTableBankFeaturesInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableFeatures(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableFeatures(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableTrasparencylimitDays(DomainTableBankFeaturesInOut domainTableBankFeaturesInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTableTrasparencyLimitDays(DomainTableBankFeaturesInOut domainTableBankFeaturesInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableCongruency(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException ,RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableSegment(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException ,RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTablePromotion(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException ,RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeDomainTablePromotion(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException ,RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveTechnicalTypeGroup(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException ,RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass checkChangeTechnicalTypeGroup(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException ,RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveRisbCodesList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException ,RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableNdgPosition(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract AccountType[] retrieveRisbCodesListForCombo(CommonParameters cP) throws XFRException ,RemoteException;
	public abstract DomainTableJustifiedMotivationResponseClass retrieveDomainTableJustifiedMotivation(DomainTableJustifiedMotivationInOut domainTableJustifiedMotivationInOut) throws XFRException ,RemoteException;
	public abstract DomainTableJustifiedMotivationResponseClass checkChangeDomainTableJustifiedMotivation(DomainTableJustifiedMotivationInOut domainTableJustifiedMotivationInOut) throws XFRException ,RemoteException;
	public abstract DomainTableDeductionPercentageResponseClass retrieveDomainTableDeductionPercentage(DomainTableDeductionPercentageInOut domainTableDeductionPercentageInOut) throws XFRException,RemoteException;
	public abstract DomainTableDeductionPercentageResponseClass checkChangeDomainTableDeductionPercentage(DomainTableDeductionPercentageInOut domainTableDeductionPercentageInOut) throws XFRException,RemoteException;
	public abstract DomainTableDiscountGroupResponseClass retrieveDomainTableDiscountGroup(DomainTableDiscountGroupInOut domainTableDiscountGroupInOut) throws XFRException,RemoteException;
	public abstract DomainTableDiscountGroupResponseClass checkChangeDomainTableDiscountGroup(DomainTableDiscountGroupInOut domainTableDiscountGroupInOut) throws XFRException,RemoteException;
	public abstract DomainTableBlockedValuesForFTResponseClass retrieveDomainTableBlockedValues(DomainTableBlockedValuesForFTInOut domainTableBlockedValuesForFTInOut) throws XFRException,RemoteException;
	public abstract DomainTableBlockedValuesForFTResponseClass checkChangeDomainTableBlockedValues(DomainTableBlockedValuesForFTInOut domainTableBlockedValuesForFTInOut) throws XFRException,RemoteException;   
	public abstract DomainTableCommunicationTypeResponseClass retrieveDomainTableCommunicationType(DomainTableCommunicationTypeInOut domainTableCommunicationTypeInOut) throws XFRException,RemoteException;
	public abstract DomainTableCommunicationTypeResponseClass checkChangeDomainTableCommunicationType(DomainTableCommunicationTypeInOut domainTableCommunicationTypeInOut) throws XFRException,RemoteException;                                                       
	public abstract DomainTableProfileTypeResponseClass retrieveDomainTableProfileType(DomainTableProfileTypeInOut domainTableProfileTypeInOut) throws XFRException,RemoteException;                                                        
	public abstract DomainTableProfileTypeResponseClass checkChangeDomainTableProfileType(DomainTableProfileTypeInOut domainTableProfileTypeInOut) throws XFRException,RemoteException;
	public abstract DomainTableProfileTypeCommunicationTypeResponseClass retrieveDomainTableProfileTypeCommunicationType(DomainTableProfileTypeCommunicationTypeInOut domainTableProfileTypeInOut) throws XFRException,RemoteException;                                                        
	public abstract DomainTableProfileTypeCommunicationTypeResponseClass checkChangeDomainTableProfileTypeCommunicationType(DomainTableProfileTypeCommunicationTypeInOut domainTableProfileTypeInOut) throws XFRException,RemoteException;
	public abstract DomainTableProfileTypeCommunicationTypeFTResponseClass retrieveDomainTableProfileTypeCommunicationTypeFT(DomainTableProfileTypeCommunicationTypeFTInOut domainTableProfileTypeFTInOut) throws XFRException,RemoteException;                                                        
	public abstract DomainTableProfileTypeCommunicationTypeFTResponseClass checkChangeDomainTableProfileTypeCommunicationTypeFT(DomainTableProfileTypeCommunicationTypeFTInOut domainTableProfileTypeFTInOut) throws XFRException,RemoteException;
	//modifica sg004
	public abstract DomainTableSpreadAdjustmentResponseClass retrieveSpreadAdjustmentList( SpreadAdjustmentInOut spreadAdjustmentInOut) throws XFRException,RemoteException;
	public abstract DomainTableSpreadAdjustmentResponseClass retrieveSpreadAdjustmentItemList( SpreadAdjustmentInOut spreadAdjustmentInOut) throws XFRException,RemoteException;
	public abstract DomainTableSpreadAdjustmentResponseClass checkChangeSpreadAdjustment(SpreadAdjustmentInOut spreadAdjustmentInOut) throws XFRException,RemoteException;
	
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableTechnicalCube(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass insertDomainTableTechnicalCube(DomainTableTechnicalTypeInOut objIn) throws XFRException, RemoteException;
	
	//	modifica sg003
	public abstract ViewPTCTResponseClass retrieveViewPTCT(ViewPTCTInOut viewPTCTInOut) throws XFRException,RemoteException;
			
	// Domain Table Languages
	public abstract GaussResponse insertLanguage(DomainTableLanguageInOut domainTableLanguageInOut) throws XFRException, RemoteException;
	public abstract DomainTableLanguageResponseClass retrieveLanguageResponseClass(DomainTableLanguageInOut domainTableLanguageInOut) throws XFRException, RemoteException;
	
	// (new) Special Features
	public abstract FeaturesResponseClass newInquirySpecialFeatures(FeaturesInOut featuresInOut) throws XFRException, RemoteException;
	public abstract FeaturesResponseClass verifySpecialFeaturesChange(FeaturesInOut featuresInOut) throws XFRException, RemoteException;
	public abstract FeaturesResponseClass confirmSpecialFeaturesChange(FeaturesInOut featuresInOut) throws XFRException, RemoteException;
	
	// Standard Features
	public abstract FeaturesResponseClass inquiryStandardFeatures(FeaturesInOut featuresInOut) throws XFRException, RemoteException;
	public abstract FeaturesResponseClass verifyStandardFeaturesChange(FeaturesInOut featuresInOut) throws XFRException, RemoteException;
	public abstract FeaturesResponseClass confirmStandardFeaturesChange(FeaturesInOut featuresInOut) throws XFRException, RemoteException;
	
	// Massive Variation - Standard and Faculty
	public abstract MassiveVariationResponseClass massiveVariationStandardChange(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass massiveVariationStandardCheckChange(MassiveVariationInOut massiveVariationInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass massiveVariationFacultyChange(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass massiveVariationFacultyCheckChange(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	//public abstract MassiveVariationResponseClass retrieveSectorCustomer(SectorCustomerInOut sectorCustomerInOut) throws XFRException, RemoteException;
	
	// Massive Variation - Loading and Request List
	public abstract MassiveVariationResponseClass retrieveMassiveVariationRequestList(MassiveVariationInOut massiveVariationInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass changeMassiveVariationHeader(MassiveVariationInOut massiveVariationInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass retrieveMassiveVariationFmanListFrom02(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass crudFmanMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass retrieveMassiveVariationFndgListFrom02(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass crudFndgMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass retrieveMassiveVariationCateList(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass retrieveCateInMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass crudCateMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass retrieveMassiveVariationSgmcList(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass retrieveSgmcInMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass crudSgmcMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationSQLResponseClass retrieveMassiveVariationAccountsListSQL(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	//	EE32518 - START
	public abstract MassiveVariationResponseClass retrieveMassiveVariationCustomerList(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass updateMassiveVariationCustomerList(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass retrieveMassiveVariationCustomerDetail(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass saveMassiveVariationCustomerDetail(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	//	EE32518 - END
	//(Austria)
	//public abstract MassiveVariationNewResponseClass retrieveMassiveVariationNewRequestList(MassiveVariationNewInOut massiveVariationInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException;
	
	// Selezione dei rapporti in una massiva
	public abstract MassiveVariationResponseClass retrieveMassiveVariationAccountList(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	public abstract MassiveVariationResponseClass massiveVariationSaveAccount(MassiveVariationInOut massiveVariationInOut) throws XFRException, RemoteException;
	
	// Massive Variation - Target Objects
	public abstract MassiveVariationResponseClass retrieveMassiveVariationTargetSearch(MassiveVariationInOut massiveVariationInOut) throws XFRException , RemoteException;
		
	// Massive Variation - Condition
	public abstract MassiveVariationResponseClass retrieveMassiveVariationCondition(MassiveVariationInOut massiveVariationInOut) throws XFRException , RemoteException;	
	public abstract MassiveVariationResponseClass massiveVariationConditionModify(MassiveVariationResponseClass rClass) throws XFRException , RemoteException;
	
	// Massive Variation - Account&Agreement list
	public abstract MassiveVariationResponseClass retrieveMassiveVariationListAccount(MassiveVariationInOut massiveVariationInOut) throws XFRException , RemoteException;
	
	// Consultation 
	public abstract ConsultationResponseClass retrieveConsultationListDetail(ConsultationInOut inOut, CommonParameters cP) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass usuryRatesList(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException , RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveUsuryRatesSelectionList(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException , RemoteException;

	
	// Account Reservation
	public abstract ProductListResponseClass retrieveProductList(CommonParameters cP, String ndg) throws XFRException, RemoteException;
	public abstract AccountReservationResponseClass reservedAccount(CommonParameters cP,AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException;
	public abstract AccountReservationResponseClass inquiryAccountReserved(CommonParameters cP, AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException;
	public abstract AccountReservationResponseClass modifyAccountReserved(CommonParameters cP, AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException;
	public abstract GaussResponse deleteAccountReserved(CommonParameters cP, AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException;
	public abstract GaussResponse convalidAccountReserved(CommonParameters cP, String ndg, String accountId, String fiscalRegimen) throws XFRException, RemoteException;

	// Active Account 
	public abstract ActiveAccountResponseClass inquiryActiveAccount(CommonParameters cP, ActiveAccountInOut activeAccountInOut) throws XFRException, RemoteException;
	public abstract ActiveAccountResponseClass modifyActiveAccount(CommonParameters cP, ActiveAccountInOut activeAccountInOut) throws XFRException, RemoteException;

	//Your Conditions (XELION)
	public abstract YourConditionsResponseClass retrieveYourConditionsDetail(YourConditionsInOut yourConditionsInOut) throws XFRException, RemoteException;
	public abstract ArrayList retrieveYourConditionsDescriptions() throws XFRException, RemoteException;
	
	// Movement Statistic
	public abstract  MovementStatisticResponseClass retrieveMovementStatistic(MovementStatisticInOut movementStatisticInOut)throws XFRException, RemoteException;
	
	// Loan: chiamata esterna dalla FIDI
	public abstract LoanResponseClass retrieveLoanConditions(LoanAnagInOut loanAnagInOut) throws XFRException, RemoteException;; 
	public abstract LoanResponseClass retrieveLoanEchelons(LoanAnagInOut loanAnagInOut) throws XFRException, RemoteException;
	public abstract LoanResponseClass changeEchelon(LoanAnagInOut loanAnagInOut) throws XFRException, RemoteException;

	// Austria modifica per NP1 ndg type legal form
	public abstract DomainTableTechnicalTypeResponseClass retrieveNdgTypeList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveLegalFormList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveNp1CouplesList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass crudNp1Couple(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveDomainTableTechnicalTypeNdgTypeLegalForm(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	// Ndg Position
	public abstract DomainTableTechnicalTypeResponseClass retrieveComboAgreement() throws XFRException, RemoteException;
	//public abstract DomainTableTechnicalTypeResponseClass retrieveComboAgreement(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
		
	// Metodi per C0 (chiamate esterne)
	public PromotionalPositions retrievePromotionalPositions(String accountType, it.usi.xframe.ifg.bfutil.wpro.UserData userInfo) throws XFRException, RemoteException;
	public SimplePosition retrieveSinglePosition(String position) throws XFRException, RemoteException;
//FT1 public OpenCondition retrieveOpenCondition(String condition, String channel) throws XFRException, RemoteException;
//FT1 public OpenCondition retrieveOpenCondition(String condition, String channel, String value) throws XFRException, RemoteException;
	public OpenCondition retrieveOpenCondition(Locale locale, String condition, String channel) throws XFRException, RemoteException;
	public OpenCondition retrieveOpenCondition(Locale locale, String condition, String channel, Object value) throws XFRException, RemoteException;
	//metodi per chiamate esterne da UWM (pj142229 - preventivatore)
	public abstract CcdPrintResponseClass printPreventivo(StampaInOut params) throws XFRException, RemoteException;
	public abstract ComboBox getFidi(String tipoOp, String filiale,String numPrev) throws XFRException, RemoteException,CcdException;
	public abstract ComboBox getFidiFromCodice(String tipoOp, String filiale,String numPrev,String codice)throws XFRException, RemoteException,CcdException;
	public abstract ComboBox getConvenzioniFromDesc(String tipo,String filiale,String numPrev,String desc)throws XFRException, RemoteException,CcdException;
	public abstract Preventivo calcolaPreventivo(String filiale, String numPrev,String codFido,String tecFido,String posizione,String importo,String durata,String matrOpe,String ndg,String desFido,String filialeCcd,String tipoRapp,String conto,String speseIniziali,String giorniEffettivi )throws XFRException,RemoteException,CcdException;
//	chiamata alla CS0SLEAN per Fast Credit (UWM)
	public FastCreditResponseClass retrieveFastCreditCS0(FastCreditBean filter) throws XFRException, RemoteException, SQLException ;	

	// ErfolgsCard
	public ErfolgsCardResponseClass checkTechnicalType(ErfolgsCardFilterInOut objIn) throws XFRException, RemoteException;
	public ErfolgsCardResponseClass updateSimulation(ErfolgsCardFilterInOut objIn) throws XFRException, RemoteException;
	public ErfolgsCardResponseClass listTechnicalType(ErfolgsCardFilterInOut objIn) throws XFRException, RemoteException;
	
	//X4Eyes
	public abstract X4eyesResponseClass inquiryListX4Eyes(X4eyesInOut x4eyesInOut) throws XFRException, RemoteException;
	public abstract X4eyesResponseClass detListX4Eyes(X4eyesInOut x4eyesInOut) throws XFRException, RemoteException;
	public abstract X4eyesResponseClass modListX4Eyes(X4eyesInOut x4eyesInOut) throws XFRException, RemoteException;
	//_____________________________________________________________________________
	// Metodo da usare in sviluppo
	//public abstract void tableElab(String table,ArrayList rows)throws XFRException, RemoteException;
    //������������������������������������������������������������������������������
	
	//Cre.Ma - ConditionCreditInquiry
	//Cre.Ma - ConditionCreditInquiry
	public abstract ConditionCreditInquiryResponseClass getConditionCreditInquiry(ConditionCreditInquiryManagementInOut inOut, String inTipoCall) throws XFRException, RemoteException;
	
	
	
	//=============================================
	//========== CHALLANGES MANAGEMENT ============
	//=============================================
	
	public Object callSPServiceForMassiveTest(String cobolProgram, Map params,
			UserData userData, DomainParams domainParams, int numOutputParam) throws Exception;
	public Object callGaussServiceForMassiveTest(String serviceName,
			Map params, UserData userData, DomainParams domainParams) throws Exception;


	//=============================================
	//==== DGSIG - OPEN parameters management =====
	//=============================================

	public Map retrieveOpenParametriColumnsSize() throws Exception;
	public CS0OpenParamsElement[] getOpenParameters(DomainParams domainParams) throws Exception;
	public int insertNewOpenParameter(CS0OpenParamsElement openParam) throws Exception;
	public int removeOpenParameter(CS0OpenParamsElement openParam) throws Exception;
	public int updateOpenParameter(CS0OpenParamsElement toUpdate, CS0OpenParamsElement newParam) throws Exception;
	public void updateOpenParameterCache(CS0OpenParamsElement newParam) throws Exception;
	public int updateRifParametro(String newRifParam, String bank, String parameterName) throws Exception;
	public int updateValParametro(String newValParam, String bank, String parameterName, String parameterRif) throws Exception;
	
	//PJ479853- Mitigation of Deloitte findings 
	public abstract DomainTableTechnicalTypeResponseClass retrieveNdgTypeForUnitList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveUnitFormList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass retrieveNdgUnitCouplesList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	public abstract DomainTableTechnicalTypeResponseClass crudNdgUnitCouple(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException;
	
	//ConditionEstimate
	public abstract ConditionEstimateResponseClass getConditionEstimate(ConditionEstimateManagementInOut inOut) throws XFRException, RemoteException;
	
}