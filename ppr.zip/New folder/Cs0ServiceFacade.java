/*
 * Created on Sep 21, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
 
package it.usi.xframe.cs0.bfimpl;
 
import it.usi.xframe.cs0.bfimpl.accountReservation.AccountReservationServiceManager;
import it.usi.xframe.cs0.bfimpl.accountReservation.ConvalidationAccountResercedServiceManager;
import it.usi.xframe.cs0.bfimpl.accountReservation.DeleteAccountReservedServiceManager;
import it.usi.xframe.cs0.bfimpl.accountReservation.InquiryAccountReservedServiceManager;
import it.usi.xframe.cs0.bfimpl.accountReservation.ProductListServiceManager;
import it.usi.xframe.cs0.bfimpl.accountReservation.VariationAccountReservedServiceManager;
import it.usi.xframe.cs0.bfimpl.activeAccount.InquiryActiveAccountServiceManager;
import it.usi.xframe.cs0.bfimpl.activeAccount.VariationActiveAccountServiceManager;
import it.usi.xframe.cs0.bfimpl.challange.CS0ChallangesManager;
import it.usi.xframe.cs0.bfimpl.condition.ConditionDetailRequestServiceManager;
import it.usi.xframe.cs0.bfimpl.condition.ConditionDetailServiceManager;
import it.usi.xframe.cs0.bfimpl.condition.ConditionsUtilityServiceManager;
import it.usi.xframe.cs0.bfimpl.condition.FacultyServiceManager;
import it.usi.xframe.cs0.bfimpl.condition.GetterConditionsListServiceManager;
import it.usi.xframe.cs0.bfimpl.condition.NotesServiceManager;
import it.usi.xframe.cs0.bfimpl.conditionCredit.ConditionCreditInquiryPersistanceManager;
import it.usi.xframe.cs0.bfimpl.conditionEstimate.ConditionEstimatePersistanceManager;
import it.usi.xframe.cs0.bfimpl.consultation.ConsultationServiceManager;
import it.usi.xframe.cs0.bfimpl.consultation.UsuryRatesServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.ConditionUserRoleServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableAccountTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableBankFeaturesServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableBlockedValuesForFTServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableChannelsServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableCodeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableCommunicationTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableConditionServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableCongruencyServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableDeductionPercentageServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableDiscountGroupServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableDocumentTechnicalTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableFeatureCodeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableFeaturesServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableHierarchicalLevelServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableIndexedRateRegistryServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableJustifiedMotivationServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableLanguageServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableLoanTechnicalTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableNdgPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTablePermissionServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableProfileTypeCommunicationTypeFTServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableProfileTypeCommunicationTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableProfileTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTablePromotionServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableRisbCodeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableSegmentServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableSpreadAdjustmentServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableStructureTableServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableTechnicalCubeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableTechnicalTypeGroupServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableTechnicalTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.DomainTableTrasparencyLimitDaysServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.NdgTypeLegalFormServiceManager;
import it.usi.xframe.cs0.bfimpl.domainTable.NdgTypeUnitFormServiceManager;
import it.usi.xframe.cs0.bfimpl.erfolgsCard.ErfolgsCardServiceManager;
import it.usi.xframe.cs0.bfimpl.features.ChangeFeaturesServiceManager;
import it.usi.xframe.cs0.bfimpl.features.FeaturesSpecialServiceManager;
import it.usi.xframe.cs0.bfimpl.features.SpecialFeaturesServiceManager;
import it.usi.xframe.cs0.bfimpl.features.StandardFeaturesServiceManager;
import it.usi.xframe.cs0.bfimpl.features.VerifyFeaturesServiceManager;
import it.usi.xframe.cs0.bfimpl.general.AccountTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.general.InformativeProspectServiceManager;
import it.usi.xframe.cs0.bfimpl.general.MovementStatisticServiceManager;
import it.usi.xframe.cs0.bfimpl.general.NdgPositionPersistanceManager;
import it.usi.xframe.cs0.bfimpl.general.ViewPTCTServiceManager;
import it.usi.xframe.cs0.bfimpl.history.GetterHistoryListServiceManager;
import it.usi.xframe.cs0.bfimpl.history.GetterRegistryHistoryServiceManager;
import it.usi.xframe.cs0.bfimpl.loan.LoanServiceManager;
import it.usi.xframe.cs0.bfimpl.loanStandarRate.LoanStandardRateServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationAccountsListPersistenceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationCateServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationConditionServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationFacultyServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationFeesServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationFmanServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationFndgServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationListAccountServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationManageServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationSgmcServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationStandardServiceManager;
import it.usi.xframe.cs0.bfimpl.massiveVariation.MassiveVariationTargetServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.OutOfAutonomyAccountInquiryServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.OutOfAutonomyAccountListServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.OutOfAutonomyHistoricalServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.OutOfAutonomyOperationServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.OutOfAutonomyPositionInquiryServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.OutOfAutonomyPositionListServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.PositionOperationServiceManager;
import it.usi.xframe.cs0.bfimpl.outOfAutonomy.RequestStateServiceManager;
import it.usi.xframe.cs0.bfimpl.position.AccountListPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.ChangerPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.ConditionDetailRequestPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.DerogableConditionsServiceManager;
import it.usi.xframe.cs0.bfimpl.position.ExpirePositionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.FacultyPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionActionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionConditionDetailServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionConditionListServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionHistoryConditionDetailServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionHistoryServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionLoanFHistoryServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionNotesServiceManager;
import it.usi.xframe.cs0.bfimpl.position.PositionPropertiesServiceManager;
import it.usi.xframe.cs0.bfimpl.position.ReplyPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.SearchPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.position.UserRoleServiceManager;
import it.usi.xframe.cs0.bfimpl.position.VerifyPositionServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardAmountServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardBidRateServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardCmsExtraLoanRateServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardCmsLoanRateServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardCodeServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardCurrencyServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardPercentageServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardPortfolioRateServiceManager;
import it.usi.xframe.cs0.bfimpl.standardCondition.StandardValuesServiceManager;
import it.usi.xframe.cs0.bfimpl.technicalType.ChangerTechnicalTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.technicalType.SearchTechnicalTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.technicalType.VerifyTechnicalTypeServiceManager;
import it.usi.xframe.cs0.bfimpl.x4eyes.X4EyesServiceManager;
import it.usi.xframe.cs0.bfimpl.yourConditions.YourConditionsPersistenceManager;
import it.usi.xframe.cs0.bfimpl.yourConditions.YourConditionsServiceManager;
import it.usi.xframe.cs0.bfintf.ICs0ServiceFacade;
import it.usi.xframe.cs0.bfutil.accountReservation.AccountReservationInOut;
import it.usi.xframe.cs0.bfutil.accountReservation.AccountReservationResponseClass;
import it.usi.xframe.cs0.bfutil.accountReservation.ProductListResponseClass;
import it.usi.xframe.cs0.bfutil.activeAccount.ActiveAccountInOut;
import it.usi.xframe.cs0.bfutil.activeAccount.ActiveAccountResponseClass;
import it.usi.xframe.cs0.bfutil.ccd.CcdPrintResponseClass;
import it.usi.xframe.cs0.bfutil.ccd.ComboBox;
import it.usi.xframe.cs0.bfutil.ccd.Preventivo;
import it.usi.xframe.cs0.bfutil.ccd.StampaInOut;
import it.usi.xframe.cs0.bfutil.condition.Condition;
import it.usi.xframe.cs0.bfutil.condition.ConditionCodeListResponseClass;
import it.usi.xframe.cs0.bfutil.condition.ConditionParameterResponseClass;
import it.usi.xframe.cs0.bfutil.condition.ConditionRequestValidationResponseClass;
import it.usi.xframe.cs0.bfutil.condition.FacultyResponseClass;
import it.usi.xframe.cs0.bfutil.condition.FindAccountResponseClass;
import it.usi.xframe.cs0.bfutil.condition.NotesResponseClass;
import it.usi.xframe.cs0.bfutil.condition.derogation.OpenCondition;
import it.usi.xframe.cs0.bfutil.consultation.ConsultationInOut;
import it.usi.xframe.cs0.bfutil.consultation.ConsultationResponseClass;
import it.usi.xframe.cs0.bfutil.cs0Exceptions.CcdException;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableBankFeaturesInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableBlockedValuesForFTInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableBlockedValuesForFTResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableCommunicationTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableCommunicationTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableConditionInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDeductionPercentageInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDeductionPercentageResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDiscountGroupInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableDiscountGroupResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableJustifiedMotivationInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableJustifiedMotivationResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableLanguageInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableLanguageResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeFTInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeFTResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeCommunicationTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableProfileTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableSpreadAdjustmentResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableStructureTableInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableTechnicalTypeInOut;
import it.usi.xframe.cs0.bfutil.domainTable.DomainTableTechnicalTypeResponseClass;
import it.usi.xframe.cs0.bfutil.domainTable.IndexedRateRegistryInOut;
import it.usi.xframe.cs0.bfutil.domainTable.SpreadAdjustmentInOut;
import it.usi.xframe.cs0.bfutil.erfolgsCard.ErfolgsCardFilterInOut;
import it.usi.xframe.cs0.bfutil.erfolgsCard.ErfolgsCardResponseClass;
import it.usi.xframe.cs0.bfutil.fastCredit.FastCreditBean;
import it.usi.xframe.cs0.bfutil.fastCredit.FastCreditResponseClass;
import it.usi.xframe.cs0.bfutil.features.Features;
import it.usi.xframe.cs0.bfutil.features.FeaturesInOut;
import it.usi.xframe.cs0.bfutil.features.FeaturesResponseClass;
import it.usi.xframe.cs0.bfutil.features.InputParamsFeatures;
import it.usi.xframe.cs0.bfutil.general.AccountType;
import it.usi.xframe.cs0.bfutil.general.Cs0Account;
import it.usi.xframe.cs0.bfutil.general.InputCS0;
import it.usi.xframe.cs0.bfutil.general.InputDetail;
import it.usi.xframe.cs0.bfutil.general.InputRequest;
import it.usi.xframe.cs0.bfutil.general.JustifiedMotivationInOut;
import it.usi.xframe.cs0.bfutil.general.MovementStatisticInOut;
import it.usi.xframe.cs0.bfutil.general.MovementStatisticResponseClass;
import it.usi.xframe.cs0.bfutil.general.UserRoleResponseClass;
import it.usi.xframe.cs0.bfutil.general.ViewPTCTInOut;
import it.usi.xframe.cs0.bfutil.general.ViewPTCTResponseClass;
import it.usi.xframe.cs0.bfutil.ifjava.CS0OpenParamsElement;
import it.usi.xframe.cs0.bfutil.informativeReport.InformativeReport;
import it.usi.xframe.cs0.bfutil.loan.LoanAnagInOut;
import it.usi.xframe.cs0.bfutil.loan.LoanResponseClass;
import it.usi.xframe.cs0.bfutil.loanStandardRate.LoanStandardRateInOut;
import it.usi.xframe.cs0.bfutil.loanStandardRate.LoanStandardRateResponseClass;
import it.usi.xframe.cs0.bfutil.massiveVariation.MassiveVariationInOut;
import it.usi.xframe.cs0.bfutil.massiveVariation.MassiveVariationResponseClass;
import it.usi.xframe.cs0.bfutil.massiveVariation.MassiveVariationSQLResponseClass;
import it.usi.xframe.cs0.bfutil.outOfAutonomy.OutOfAutonomyRequest;
import it.usi.xframe.cs0.bfutil.outOfAutonomy.OutOfAutonomyRequestAccount;
import it.usi.xframe.cs0.bfutil.outOfAutonomy.OutOfAutonomyRequestResponseClass;
import it.usi.xframe.cs0.bfutil.position.AccountListPositionResponseClass;
import it.usi.xframe.cs0.bfutil.position.ConditionDetailPositionResponseClass;
import it.usi.xframe.cs0.bfutil.position.DerogableConditionsForPositionInOut;
import it.usi.xframe.cs0.bfutil.position.InputSearchPosition;
import it.usi.xframe.cs0.bfutil.position.PositionBean;
import it.usi.xframe.cs0.bfutil.position.PositionResponseClass;
import it.usi.xframe.cs0.bfutil.position.PromotionalPositions;
import it.usi.xframe.cs0.bfutil.position.SimplePosition;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardAmountInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardBaseInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardBaseRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardBidRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardCmsLoanRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardCodeInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardConditionResponseClass;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardCurrenciesInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardPercentageInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardPortfolioRateInOut;
import it.usi.xframe.cs0.bfutil.standardCondition.StandardValuesInOut;
import it.usi.xframe.cs0.bfutil.technicalType.InputSearchTechnicalType;
import it.usi.xframe.cs0.bfutil.technicalType.TechnicalTypeResponseClass;
import it.usi.xframe.cs0.bfutil.utilities.CommonParameters;
import it.usi.xframe.cs0.bfutil.x4eyes.X4eyesInOut;
import it.usi.xframe.cs0.bfutil.x4eyes.X4eyesResponseClass;
import it.usi.xframe.cs0.bfutil.yourConditions.YourConditionsInOut;
import it.usi.xframe.cs0.bfutil.yourConditions.YourConditionsResponseClass;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryManagementInOut;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryResponseClass;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateManagementInOut;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateResponseClass;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.ifj.bfimpl.dgsig.pm.IFJEGTParametersPersistenceManager;
import it.usi.xframe.ifj.bfutil.IFJDomainParams;
import it.usi.xframe.ifj.bfutil.OpenParamsElement;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.system.eservice.AbstractSupportServiceFacade;
import it.usi.xframe.utl.bfutil.DomainParams;
import it.usi.xframe.utl.bfutil.GaussResponse;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


/**
 * @author US01147
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * @modelguid {0CA4D8A5-1D1A-4B56-A3DA-03AC422556C5}
 */
public class Cs0ServiceFacade extends AbstractSupportServiceFacade implements ICs0ServiceFacade {
	
	public OutOfAutonomyRequestResponseClass retrieveOutOfAutonomySynthesysForPDF(OutOfAutonomyRequest outOfAutonomyRequest,OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani) throws XFRException, RemoteException {
		return OutOfAutonomyAccountInquiryServiceManager.getInstance().retrieveOutOfAutonomySynthesysForPDF( outOfAutonomyRequest, outOfAutonomyRequestAccount,  cP, bersani);
			}	
	public Cs0Account retrieveConditionsList(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterConditionsListServiceManager.getInstance().retrieveConditionsList(params, cP);
	}
	public Cs0Account retrieveConditionsListDetail(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterConditionsListServiceManager.getInstance().retrieveConditionsListDetail(params, cP);
	}
	public Cs0Account retrieveConditionsListChannel(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterConditionsListServiceManager.getInstance().retrieveConditionsListChannel(params, cP);
	}
	public Cs0Account retrieveConditionsListLoan(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterConditionsListServiceManager.getInstance().retrieveConditionsListLoan(params, cP);
	}
	public Cs0Account retrieveConditionsListPTF(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterConditionsListServiceManager.getInstance().retrieveConditionsListPTF(params, cP);
	}
	public Cs0Account retrieveConditionSynthesis(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterConditionsListServiceManager.getInstance().retrieveConditionSynthesis(params, cP);
	}
	public Cs0Account retrieveConditionDetail(InputCS0 params, InputDetail detailParams, CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailServiceManager.getInstance().retrieveConditionDetail(params, detailParams, cP);
	}
	public Cs0Account retrieveConditionDetailLoan(InputCS0 params, InputDetail detailParams, CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailServiceManager.getInstance().retrieveConditionDetailLoan(params, detailParams, cP);
	}
	public Cs0Account retrieveConditionDetailPortaf(InputCS0 params, InputDetail detailParams, CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailServiceManager.getInstance().retrieveConditionDetailPortaf(params, detailParams, cP);
	}
	public Cs0Account retrieveConditionDetailTapa(InputCS0 params, InputDetail detailParams, CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailServiceManager.getInstance().retrieveConditionDetailTapa(params, detailParams, cP);
	}
	public ConditionRequestValidationResponseClass validateDetailRequest(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail, JustifiedMotivationInOut justifiedMotivationInOut,CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailRequestServiceManager.getInstance().validateDetailRequest(cs0Params, inputRequest, inputDetail,justifiedMotivationInOut, cP);
	}
	public ConditionRequestValidationResponseClass confirmDetailRequest(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail , JustifiedMotivationInOut justifiedMotivationInOut ,CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailRequestServiceManager.getInstance().confirmDetailRequest(cs0Params, inputRequest, inputDetail, justifiedMotivationInOut ,cP);
	}
	public ConditionRequestValidationResponseClass confirmChangeRequest(InputCS0 cs0Params, Condition condition ,CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailRequestServiceManager.getInstance().confirmChangeRequest(cs0Params, condition , cP);
	}
	public ConditionRequestValidationResponseClass rollback(InputCS0 cs0Params,CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailRequestServiceManager.getInstance().rollback(cs0Params, cP);
	}
	public ConditionCodeListResponseClass retrieveCodeList(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return ConditionsUtilityServiceManager.getInstance().retrieveCodeList(params, cP);
	}
	public ConditionParameterResponseClass retrieveParameterList(InputCS0 cs0Params, CommonParameters cP) throws XFRException, RemoteException {
		return ConditionsUtilityServiceManager.getInstance().retrieveParameterList(cs0Params, cP);
	}
	public DomainTableTechnicalTypeResponseClass retrieveSegmentList(CommonParameters cP) throws XFRException, RemoteException {
		return ConditionsUtilityServiceManager.getInstance().retrieveSegmentList(cP);
	}
	public FacultyResponseClass retrieveFaculty(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return FacultyServiceManager.getInstance().retrieveFaculty(cs0Params, inputDetail, cP);
	}
	public FacultyResponseClass retrieveFacultyCode(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return FacultyServiceManager.getInstance().retrieveFacultyCode(cs0Params, inputDetail, cP);
	}
	public FacultyResponseClass retrieveFacultyDay(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return FacultyServiceManager.getInstance().retrieveFacultyDay(cs0Params, inputDetail, cP);
	}
	public NotesResponseClass retrieveNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return NotesServiceManager.getInstance().retrieveNotes(cs0Params, inputDetail, cP);
	}
	public NotesResponseClass retrievePositionNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return PositionNotesServiceManager.getInstance().retrieveNotes(cs0Params, inputDetail, cP);
	}
	public GaussResponse insertNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return NotesServiceManager.getInstance().insertNotes(cs0Params, inputDetail, cP);
	}
	public GaussResponse insertPositionNotes(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return PositionNotesServiceManager.getInstance().insertNotes(cs0Params, inputDetail, cP);
	}
	public PositionResponseClass retrieveSearchPosition(PositionBean position, CommonParameters cP) throws XFRException, RemoteException {
		return SearchPositionServiceManager.getInstance().retrieveSearchPosition(position, cP);
	}
	//F inserito per gestire il ritorno delle posizioni fast credit 
	public PositionResponseClass retrieveSearchPosition(PositionBean position, CommonParameters cP ,boolean fastCreditFlag) throws XFRException, RemoteException {
			return null;
	}
	public TechnicalTypeResponseClass retrieveSearchTechnicalType(InputCS0 params, InputSearchTechnicalType techTypeParams, CommonParameters cP) throws XFRException, RemoteException {
		return SearchTechnicalTypeServiceManager.getInstance().retrieveSearchTechnicalType(params, techTypeParams, cP);
	}
	public GaussResponse verifyTT(InputCS0 params, InputSearchTechnicalType techTypeParams, CommonParameters cP) throws XFRException, RemoteException {
		return VerifyTechnicalTypeServiceManager.getInstance().verifyTechType(params,techTypeParams, cP);
	}
	public GaussResponse changeTT(InputCS0 params, InputSearchTechnicalType techTypeParams, CommonParameters cP) throws XFRException, RemoteException {
		return ChangerTechnicalTypeServiceManager.getInstance().ChangerTechType(params,techTypeParams, cP);
	}
	public GaussResponse retrieveVerifyPosition(InputCS0 params, InputSearchPosition posParams, CommonParameters cP) throws XFRException, RemoteException {
		return VerifyPositionServiceManager.getInstance().retrieveVerifyPosition(params,posParams,cP);
	}
	public GaussResponse retrieveChangerPosition(InputCS0 params, InputSearchPosition posParams, CommonParameters cP) throws XFRException, RemoteException {
		return ChangerPositionServiceManager.getInstance().retrieveChangerPosition(params,posParams,cP);
	}
	public MovementStatisticResponseClass retrieveMovementStatistic(MovementStatisticInOut movementStatisticInOut) throws XFRException, RemoteException {
		return MovementStatisticServiceManager.getInstance().retrieveMovementStatistic(movementStatisticInOut);
	}
	public InformativeReport retrieveInformativeProspect(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
			return InformativeProspectServiceManager.getInstance().retrieveInformativeProspect(params,cP);
		}
	public Cs0Account[] retrieveHistory(InputCS0 params, CommonParameters cP, InputDetail detailParams) throws XFRException, RemoteException {
		return GetterHistoryListServiceManager.getInstance().retrieveHistory(params, cP, detailParams);
	}
	public Cs0Account[] retrieveHistoryOnLine(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterHistoryListServiceManager.getInstance().retrieveHistoryOnLine(params, cP);
	}
	public Cs0Account[] retrieveRegistryHistory(InputCS0 params, CommonParameters cP) throws XFRException, RemoteException {
		return GetterRegistryHistoryServiceManager.getInstance().retrieveRegistryHistory(params, cP);
	}
	public AccountType[] retrieveAccountTypeList(CommonParameters cP) throws XFRException, RemoteException {
		return AccountTypeServiceManager.getInstance().retrieveAccountTypeList(cP);
	}
	public Features retrieveSpecialInquiry(InputParamsFeatures featuresParams, CommonParameters cP) throws XFRException, RemoteException {		
		return FeaturesSpecialServiceManager.getInstance().inquirySpecialFeatures(featuresParams, cP);
	}
	public Features retrieveFeaturesHistory(InputParamsFeatures  featuresParams, CommonParameters cP) throws XFRException, RemoteException {
		return FeaturesSpecialServiceManager.getInstance().retrieveFeaturesHistory(featuresParams, cP);
	}
	public GaussResponse verifyFeatures(InputParamsFeatures featuresParams, CommonParameters cP) throws XFRException, RemoteException {
		return VerifyFeaturesServiceManager.getInstance().verifyFeatures(featuresParams,cP);
	}
	public GaussResponse changeFeatures(InputParamsFeatures featuresParams, CommonParameters cP) throws XFRException, RemoteException {
		return ChangeFeaturesServiceManager.getInstance().changeFeatures(featuresParams,cP);
	}
	public ArrayList retrieveOutOfAutonomyStateList(CommonParameters cP) throws XFRException, RemoteException {
		return RequestStateServiceManager.getInstance().retrieveOutOfAutonomyStateList(cP);
	}
	public OutOfAutonomyRequestResponseClass[] retrieveOutOfAutonomyAccountList(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException {
		return OutOfAutonomyAccountListServiceManager.getInstance().retrieveOutOfAutonomyAccountList(outOfAutonomyRequest, outOfAutonomyRequestAccount, cP);
	}
	public OutOfAutonomyRequestResponseClass[] retrieveOutOfAutonomyPositionList(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani) throws XFRException, RemoteException {
		return OutOfAutonomyPositionListServiceManager.getInstance().retrieveOutOfAutonomyPositionList(outOfAutonomyRequest, outOfAutonomyRequestAccount, cP, bersani);
	}
	public OutOfAutonomyRequestResponseClass retrieveOutOfAutonomyAccountInquiry(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani) throws XFRException, RemoteException {
		return OutOfAutonomyAccountInquiryServiceManager.getInstance().retrieveOutOfAutonomyAccountInquiry(outOfAutonomyRequest, outOfAutonomyRequestAccount, cP, bersani);
	}
	
	
	// Out of Autonomy Position Inquiry
	public OutOfAutonomyRequestResponseClass retrieveOutOfAutonomyPositionInquiry(OutOfAutonomyRequest outOfAutonomyRequest,PositionBean position, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP, boolean bersani) throws XFRException, RemoteException {
		return OutOfAutonomyPositionInquiryServiceManager.getInstance().retrieveOutOfAutonomyPositionInquiry(outOfAutonomyRequest, position, outOfAutonomyRequestAccount, cP, bersani);
	}
	public OutOfAutonomyRequestResponseClass retrieveOutOfAutonomyHistorical( OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return OutOfAutonomyHistoricalServiceManager.getInstance().retrieveOutOfAutonomyHistorical(outOfAutonomyRequest, outOfAutonomyRequestAccount, inputDetail, cP);
	}
	public GaussResponse verifyOutOfAutonomyOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException {
		return OutOfAutonomyOperationServiceManager.getInstance().verifyOutOfAutonomyOperation(outOfAutonomyRequest, outOfAutonomyRequestAccount, cP);
	}
	public GaussResponse modifyOutOfAutonomyOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException {
		return OutOfAutonomyOperationServiceManager.getInstance().modifyOutOfAutonomyOperation(outOfAutonomyRequest, outOfAutonomyRequestAccount, cP);
	}
/** accorpato con SearchPositionServiceManger 
	public PositionResponseClass retrievePositionDetail (PositionBean pBean, CommonParameters cP)throws XFRException, RemoteException {
		return PositionDetailServiceManager.getInstance().retrievePositionDetail( pBean, cP);
	}
*/
	public PositionResponseClass retrieveConditionsListPosition(CommonParameters cP, PositionBean pBean, Map conditionParam)throws XFRException, RemoteException {
		return PositionConditionListServiceManager.getInstance().retrieveConditionsListPosition( cP, pBean, conditionParam);
	}
	public PositionResponseClass retrieveConditionsSynthesisPosition(CommonParameters cP, PositionBean pB, Map conditionParam)throws XFRException, RemoteException {
		return PositionConditionListServiceManager.getInstance().retrieveConditionsSynthesisPosition(cP, pB, conditionParam);
	}
	public ConditionDetailPositionResponseClass retrieveConditionDetail(PositionBean positionBean, CommonParameters cP, Map conditionParam)throws XFRException, RemoteException {
		return PositionConditionDetailServiceManager.getInstance().retrieveConditionDetail(positionBean, cP, conditionParam);
	}
	public PositionResponseClass retrievePositionLoanFHistory(CommonParameters cP, PositionBean pBean, Map conditionParam)throws XFRException, RemoteException {
		return 	PositionLoanFHistoryServiceManager.getInstance().retrievePositionLoanFHistory(  pBean, cP, conditionParam);
	}
	public PositionResponseClass[] retrievePositionHistory (PositionBean pBean, CommonParameters cP)throws XFRException, RemoteException {
		return PositionHistoryServiceManager.getInstance().retrievePositionHistory( pBean, cP);
	}
	public PositionResponseClass retrieveHistoryConditionDetail(PositionBean positionBean, CommonParameters cP, Map conditionParam)throws XFRException, RemoteException {
		return PositionHistoryConditionDetailServiceManager.getInstance().retrieveHistoryConditionDetail(positionBean, cP, conditionParam);
	}
	public AccountListPositionResponseClass retrieveAccountListPosition(PositionBean pBean, PositionBean fBean,CommonParameters cP, Map navParam)throws XFRException, RemoteException {
		return AccountListPositionServiceManager.getInstance().retrieveAccountListPosition(pBean,fBean , cP, navParam);
	}
	public HashMap retrievePositionProperties(CommonParameters cP) throws XFRException, RemoteException {
		return PositionPropertiesServiceManager.getInstance().retrievePositionProperties(cP);
	}
	public String retrieveSingleProperty(String resourceName,String code,CommonParameters cP) throws XFRException, RemoteException {
		return PositionPropertiesServiceManager.getInstance().retrieveSingleProperty(resourceName,code,cP);
	}
	public PositionResponseClass performAction(String action, PositionBean position, CommonParameters cP)throws XFRException, RemoteException {	
		return PositionActionServiceManager.getInstance().performAction(action,position,cP);
	}
	public UserRoleResponseClass retrieveUserRole(CommonParameters cP) throws XFRException, RemoteException {
		return UserRoleServiceManager.getInstance().retrieveUserRole(cP);
	}
	public UserRoleResponseClass retrieveUserRoleMod(CommonParameters cP) throws XFRException, RemoteException {
			return UserRoleServiceManager.getInstance().retrieveUserRoleMod(cP);
		}
	public UserRoleResponseClass retrieveConditionUserRole(CommonParameters cP) throws XFRException, RemoteException {
		return ConditionUserRoleServiceManager.getInstance().retrieveConditionUserRole(cP);
	}
	public PositionResponseClass replyPosition(String action, PositionBean position, CommonParameters cP) throws XFRException, RemoteException {
		return ReplyPositionServiceManager.getInstance().replyPosition(action,position,cP);
	}
	public PositionResponseClass performExpiration(String action, PositionBean position, CommonParameters cP) throws XFRException, RemoteException {
		return ExpirePositionServiceManager.getInstance().performExpiration(action,position,cP);
	}	
	public ConditionRequestValidationResponseClass validateDetailRequestPosition(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail,  JustifiedMotivationInOut justifiedMotivationInOut ,CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailRequestPositionServiceManager.getInstance().validateDetailRequestPosition(cs0Params, inputRequest, inputDetail,justifiedMotivationInOut, cP);
	}
	public GaussResponse confirmDetailRequestPosition(InputCS0 cs0Params, InputRequest inputRequest, InputDetail inputDetail,  JustifiedMotivationInOut justifiedMotivationInOut ,  CommonParameters cP) throws XFRException, RemoteException {
		return ConditionDetailRequestPositionServiceManager.getInstance().confirmDetailRequestPosition(cs0Params, inputRequest, inputDetail , justifiedMotivationInOut ,cP);
	}	
	public FacultyResponseClass retrieveFacultyByPos(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return FacultyPositionServiceManager.getInstance().retrieveFaculty(cs0Params, inputDetail, cP);
	}
	public FacultyResponseClass retrieveFacultyCodeByPos(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return FacultyPositionServiceManager.getInstance().retrieveFacultyCode(cs0Params, inputDetail, cP);
	}
	public FacultyResponseClass retrieveFacultyDayByPos(InputCS0 cs0Params, InputDetail inputDetail, CommonParameters cP) throws XFRException, RemoteException {
		return FacultyPositionServiceManager.getInstance().retrieveFacultyDay(cs0Params, inputDetail, cP);
	}	
	public LoanStandardRateResponseClass retrieveLoanStandardRate(LoanStandardRateInOut loanStandardRateInOut) throws XFRException, RemoteException {
		return LoanStandardRateServiceManager.getInstance().retrieveloanStandardRate( loanStandardRateInOut);
	}
	public GaussResponse verifyPositionOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException {
		return PositionOperationServiceManager.getInstance().verifyPositionOperation(outOfAutonomyRequest, outOfAutonomyRequestAccount, cP);
	}
	public GaussResponse modifyPositionOperation(OutOfAutonomyRequest outOfAutonomyRequest, OutOfAutonomyRequestAccount outOfAutonomyRequestAccount, CommonParameters cP) throws XFRException, RemoteException {
		return PositionOperationServiceManager.getInstance().modifyPositionOperation(outOfAutonomyRequest, outOfAutonomyRequestAccount, cP);
	}
	public PositionResponseClass retrieveDerogableConditionsList(DerogableConditionsForPositionInOut derogableConditionsForPositionInOut) throws XFRException, RemoteException {
		return DerogableConditionsServiceManager.getInstance().retrieveDerogableConditionsList(derogableConditionsForPositionInOut);
	}
	
	// Standard Conditions
	public StandardConditionResponseClass retrieveStandardAmount(StandardBaseInOut standardBaseInOut, StandardAmountInOut standardAmountInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardAmountServiceManager.getInstance().retrieveStandardAmount(standardBaseInOut, standardAmountInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass retrieveStandardCode(StandardBaseInOut standardBaseInOut, StandardCodeInOut standardCodeInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCodeServiceManager.getInstance().retrieveStandardCode(standardBaseInOut, standardCodeInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardAmount(StandardBaseInOut standardBaseInOut, StandardAmountInOut standardAmountInOut) throws XFRException, RemoteException {
		return StandardAmountServiceManager.getInstance().deleteFacultyStandardAmount(standardBaseInOut, standardAmountInOut);
	}
	public StandardConditionResponseClass checkChangeStandardAmount(StandardBaseInOut standardBaseInOut, StandardAmountInOut standardAmountInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardAmountServiceManager.getInstance().checkChangeStandardAmount(standardBaseInOut, standardAmountInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass checkChangeStandardCode(StandardBaseInOut standardBaseInOut, StandardCodeInOut standardCodeInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCodeServiceManager.getInstance().checkChangeStandardCode(standardBaseInOut, standardCodeInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass retrieveStandardValues(StandardBaseInOut standardBaseInOut, StandardValuesInOut standardValuesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardValuesServiceManager.getInstance().retrieveStandardValues(standardBaseInOut, standardValuesInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass checkChangeStandardValues(StandardBaseInOut standardBaseInOut, StandardValuesInOut standardValuesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardValuesServiceManager.getInstance().checkChangeStandardValues(standardBaseInOut, standardValuesInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardValues(StandardBaseInOut standardBaseInOut, StandardValuesInOut standardValuesInOut) throws XFRException, RemoteException {
		return StandardValuesServiceManager.getInstance().deleteFacultyStandardValues(standardBaseInOut, standardValuesInOut);
	}
	public StandardConditionResponseClass retrieveStandardPercentage(StandardBaseInOut standardBaseInOut, StandardPercentageInOut standardPercentageInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardPercentageServiceManager.getInstance().retrieveStandardPercentage(standardBaseInOut, standardPercentageInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass checkChangeStandardPercentage(StandardBaseInOut standardBaseInOut, StandardPercentageInOut standardPercentageInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardPercentageServiceManager.getInstance().checkChangeStandardPercentage(standardBaseInOut, standardPercentageInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardPercentage(StandardBaseInOut standardBaseInOut, StandardPercentageInOut standardPercentageInOut) throws XFRException, RemoteException {
		return StandardPercentageServiceManager.getInstance().deleteFacultyStandardPercentage(standardBaseInOut, standardPercentageInOut);
	}
	public StandardConditionResponseClass retrieveStandardCurrency(StandardBaseInOut standardBaseInOut, StandardCurrenciesInOut standardCurrenciesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCurrencyServiceManager.getInstance().retrieveStandardCurrency(standardBaseInOut, standardCurrenciesInOut, justifiedMotivationInOut);
	}
	public StandardConditionResponseClass checkChangeStandardCurrency(StandardBaseInOut standardBaseInOut, StandardCurrenciesInOut standardCurrenciesInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCurrencyServiceManager.getInstance().checkChangeStandardCurrency(standardBaseInOut, standardCurrenciesInOut, justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardCurrency(StandardBaseInOut standardBaseInOut, StandardCurrenciesInOut standardCurrenciesInOut) throws XFRException, RemoteException {
		return StandardCurrencyServiceManager.getInstance().deleteFacultyStandardCurrency(standardBaseInOut, standardCurrenciesInOut);
	}
	
	// Standard Conditions Rate
	public StandardConditionResponseClass retrieveStandardCmsLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCmsLoanRateServiceManager.getInstance().retrieveStandardCmsLoanRate(standardBaseRateInOut, standardCmsLoanRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass retrieveStandardCmsExtraLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCmsExtraLoanRateServiceManager.getInstance().retrieveStandardCmsExtraLoanRate(standardBaseRateInOut, standardCmsLoanRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass checkChangeStandardCmsLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCmsLoanRateServiceManager.getInstance().checkChangeStandardCmsLoanRate(standardBaseRateInOut, standardCmsLoanRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardCmsLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut) throws XFRException, RemoteException {
		return StandardCmsLoanRateServiceManager.getInstance().deleteFacultyStandardCmsLoanRate(standardBaseRateInOut, standardCmsLoanRateInOut);
	}
	public StandardConditionResponseClass checkChangeStandardCmsExtraLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardCmsExtraLoanRateServiceManager.getInstance().checkChangeStandardCmsExtraLoanRate(standardBaseRateInOut, standardCmsLoanRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardCmsExtraLoanRate(StandardBaseRateInOut standardBaseRateInOut, StandardCmsLoanRateInOut standardCmsLoanRateInOut) throws XFRException, RemoteException {
		return StandardCmsExtraLoanRateServiceManager.getInstance().deleteFacultyStandardCmsExtraLoanRate(standardBaseRateInOut, standardCmsLoanRateInOut);
	}
	public StandardConditionResponseClass retrieveStandardPortfolioRate(StandardBaseRateInOut standardBaseRateInOut, StandardPortfolioRateInOut standardPortfolioRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardPortfolioRateServiceManager.getInstance().retrieveStandardPortfolioRate(standardBaseRateInOut, standardPortfolioRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass checkChangeStandardPortfolioRate(StandardBaseRateInOut standardBaseRateInOut, StandardPortfolioRateInOut standardPortfolioRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardPortfolioRateServiceManager.getInstance().checkChangeStandardPortfolioRate(standardBaseRateInOut, standardPortfolioRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardPortfolioRate(StandardBaseRateInOut standardBaseRateInOut, StandardPortfolioRateInOut standardPortfolioRateInOut) throws XFRException, RemoteException {
		return StandardPortfolioRateServiceManager.getInstance().deleteFacultyStandardPortfolioRate(standardBaseRateInOut, standardPortfolioRateInOut);
	}
	public StandardConditionResponseClass retrieveStandardBidRate(StandardBaseRateInOut standardBaseRateInOut, StandardBidRateInOut standardBidRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardBidRateServiceManager.getInstance().retrieveStandardBidRate(standardBaseRateInOut, standardBidRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass checkChangeStandardBidRate(StandardBaseRateInOut standardBaseRateInOut, StandardBidRateInOut standardBidRateInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException, RemoteException {
		return StandardBidRateServiceManager.getInstance().checkChangeStandardBidRate(standardBaseRateInOut, standardBidRateInOut,justifiedMotivationInOut);
	}
	public StandardConditionResponseClass deleteFacultyStandardBidRate(StandardBaseRateInOut standardBaseRateInOut, StandardBidRateInOut standardBidRateInOut) throws XFRException, RemoteException {
		return StandardBidRateServiceManager.getInstance().deleteFacultyStandardBidRate(standardBaseRateInOut, standardBidRateInOut);
	}
	
	// Domain Tables
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException {
		return DomainTableTechnicalTypeServiceManager.getInstance().retrieveDomainTableTechnicalType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableAccountTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return DomainTableTechnicalTypeServiceManager.getInstance().checkChangeDomainTableAccountTechnicalType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass changeTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return DomainTableTechnicalTypeServiceManager.getInstance().changeTechnicalType(domainTableTechnicalTypeInOut);
	}
	// Aggiunti per NP1 ndg type legal form
	public DomainTableTechnicalTypeResponseClass retrieveNdgTypeList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeLegalFormServiceManager.getInstance().retrieveNdgTypeList(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveLegalFormList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeLegalFormServiceManager.getInstance().retrieveLegalFormList(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveNp1CouplesList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeLegalFormServiceManager.getInstance().retrieveNp1CouplesList(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass crudNp1Couple(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeLegalFormServiceManager.getInstance().crudNp1Couple(domainTableTechnicalTypeInOut);
	}
	//
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableTechnicalTypeNdgTypeLegalForm(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeLegalFormServiceManager.getInstance().retrieveDomainTableTechnicalTypeNdgTypeLegalForm(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveIndexedRate(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException {
		return DomainTableIndexedRateRegistryServiceManager.getInstance().retrieveIndexedRate(indexedRateRegistryInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeIndexedRateRegistry(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException {
		return DomainTableIndexedRateRegistryServiceManager.getInstance().checkChangeIndexedRateRegistry(indexedRateRegistryInOut);
	}
	public DomainTableTechnicalTypeResponseClass insertValuesIndexedRateRegistry(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException {
		return DomainTableIndexedRateRegistryServiceManager.getInstance().insertValuesIndexedRateRegistry(indexedRateRegistryInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveConditionListDetail(DomainTableConditionInOut conditionInOut) throws XFRException {
		return DomainTableConditionServiceManager.getInstance().retrieveConditionListDetail(conditionInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveConditionHistory(DomainTableConditionInOut conditionInOut) throws XFRException {
		return DomainTableConditionServiceManager.getInstance().retrieveConditionHistory(conditionInOut);
	}
	public DomainTableTechnicalTypeResponseClass modifyCondition(DomainTableConditionInOut conditionInOut) throws XFRException {
		return DomainTableConditionServiceManager.getInstance().modifyCondition(conditionInOut);
	}
	public DomainTableTechnicalTypeResponseClass insertCondition(DomainTableConditionInOut conditionInOut) throws XFRException {
		return DomainTableConditionServiceManager.getInstance().insertCondition(conditionInOut);
	}
	public DomainTableTechnicalTypeResponseClass deleteCondition(DomainTableConditionInOut conditionInOut) throws XFRException {
		return DomainTableConditionServiceManager.getInstance().deleteCondition(conditionInOut);
	}
	public DomainTableTechnicalTypeResponseClass replyCondition(DomainTableConditionInOut conditionInOut) throws XFRException {
		return DomainTableConditionServiceManager.getInstance().replyCondition(conditionInOut);
	}
	public DomainTableTechnicalTypeResponseClass historyDetail(DomainTableConditionInOut conditionInOut) throws XFRException {
		return DomainTableConditionServiceManager.getInstance().historyDetail(conditionInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveLoanTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableLoanTechnicalTypeServiceManager.getInstance().retrieveLoanTechnicalType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDocumentTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableDocumentTechnicalTypeServiceManager.getInstance().retrieveDocumentTechnicalType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeLoanTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableLoanTechnicalTypeServiceManager.getInstance().checkChangeLoanTechnicalType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDocumentTechnicalType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableDocumentTechnicalTypeServiceManager.getInstance().checkChangeDocumentTechnicalType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableAccountType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException {
		return DomainTableAccountTypeServiceManager.getInstance().retrieveDomainTableAccountType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableAccountType(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return DomainTableAccountTypeServiceManager.getInstance().checkChangeDomainTableAccountType(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException {
		return DomainTableCodeServiceManager.getInstance().retrieveDomainTableCode(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return DomainTableCodeServiceManager.getInstance().checkChangeDomainTableCode(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTablePermission(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException , RemoteException {
		return DomainTablePermissionServiceManager.getInstance().retrieveDomainTablePermission(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTablePermission(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return DomainTablePermissionServiceManager.getInstance().checkChangeDomainTablePermisssion(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableStructureTable(DomainTableStructureTableInOut domainTableStructureTableInOut ) throws XFRException , RemoteException {
		return DomainTableStructureTableServiceManager.getInstance().retrieveDomainTableStructureTable(domainTableStructureTableInOut );
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableHierarchcalLevel(DomainTableStructureTableInOut domainTableStructureTableInOut) throws XFRException , RemoteException {
		return DomainTableHierarchicalLevelServiceManager.getInstance().retrieveDomainTableHierarchicalLevel(domainTableStructureTableInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableHierarchicalLevel(DomainTableStructureTableInOut domainTableStructureTableInOut) throws XFRException, RemoteException {
		return DomainTableHierarchicalLevelServiceManager.getInstance().checkChangeDomainTableHierarchicalLevel(domainTableStructureTableInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableFeatureCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableFeatureCodeServiceManager.getInstance().retrieveDomainTableFeatureCode(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableFeatureCode(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableFeatureCodeServiceManager.getInstance().checkChangeDomainTableFeatureCode(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableChannels(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableChannelsServiceManager.getInstance().retrieveDomainTableChannels(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableChannels(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableChannelsServiceManager.getInstance().checkChangeDomainTableChannels(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableBankFeatures(DomainTableBankFeaturesInOut domainTableBankFeaturesInOut) throws XFRException {
		return DomainTableBankFeaturesServiceManager.getInstance().retrieveDomainTableBankFeatures(domainTableBankFeaturesInOut);
	} 
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableFeatures(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableFeaturesServiceManager.getInstance().retrieveDomainTableFeatures(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableFeatures(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableFeaturesServiceManager.getInstance().checkChangeDomainTableFeatures(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableTrasparencylimitDays(DomainTableBankFeaturesInOut domainTableBankFeaturesInOut) throws XFRException {
		return DomainTableTrasparencyLimitDaysServiceManager.getInstance().retrieveDomainTableTrasparencyLimitDays(domainTableBankFeaturesInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTableTrasparencyLimitDays(DomainTableBankFeaturesInOut domainTableBankFeaturesInOut) throws XFRException {
		return DomainTableTrasparencyLimitDaysServiceManager.getInstance().checkChangeDomainTableTrasparencyLimitDays(domainTableBankFeaturesInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableCongruency(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException {
		return DomainTableCongruencyServiceManager.getInstance().retrieveDomainTableCongruency(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableSegment(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut ) throws XFRException {
		return DomainTableSegmentServiceManager.getInstance().retrieveDomainTableSegment(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTablePromotion(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTablePromotionServiceManager.getInstance().retrieveDomainTablePromotion(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeDomainTablePromotion(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTablePromotionServiceManager.getInstance().checkChangeDomainTablePromotion(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveTechnicalTypeGroup(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableTechnicalTypeGroupServiceManager.getInstance().retrieveTechnicalTypeGroup(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass checkChangeTechnicalTypeGroup(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableTechnicalTypeGroupServiceManager.getInstance().checkChangeTechnicalTypeGroup(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveRisbCodesList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableRisbCodeServiceManager.getInstance().retrieveRisbCodesList(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableNdgPosition(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException {
		return DomainTableNdgPositionServiceManager.getInstance().retrieveDomainTableNdgPosition(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveComboAgreement() throws XFRException {
		return NdgPositionPersistanceManager.getInstance().retrieveComboAgreement();
	}
	
	// MODIFICA SG004
	public DomainTableSpreadAdjustmentResponseClass retrieveSpreadAdjustmentList(SpreadAdjustmentInOut spreadAdjustmentInOut) throws XFRException {
			return DomainTableSpreadAdjustmentServiceManager.getInstance().retrieveSpreadAdjustmentList( spreadAdjustmentInOut);
	}
	public DomainTableSpreadAdjustmentResponseClass retrieveSpreadAdjustmentItemList(SpreadAdjustmentInOut spreadAdjustmentInOut) throws XFRException {
			return DomainTableSpreadAdjustmentServiceManager.getInstance().retrieveSpreadAdjustmentItemList( spreadAdjustmentInOut);
	}
	
	public DomainTableSpreadAdjustmentResponseClass checkChangeSpreadAdjustment(SpreadAdjustmentInOut spreadAdjustmentInOut) throws XFRException
	{
		return DomainTableSpreadAdjustmentServiceManager.getInstance().checkChangeSpreadAdjustment(spreadAdjustmentInOut);
	}
	
	
	//	MODIFICA SG003
	public ViewPTCTResponseClass retrieveViewPTCT(ViewPTCTInOut viewPTCTInOut) throws XFRException {
			return ViewPTCTServiceManager.getInstance().retrieveViewPTCT(viewPTCTInOut);
	}
	
	
	
	
	
	
	public AccountType[] retrieveRisbCodesListForCombo(CommonParameters cP) throws XFRException ,RemoteException {
		return DomainTableRisbCodeServiceManager.getInstance().retrieveRisbCodesListForCombo(cP);
	}
	public DomainTableJustifiedMotivationResponseClass retrieveDomainTableJustifiedMotivation(DomainTableJustifiedMotivationInOut domainTableJustifiedMotivationInOut) throws XFRException ,RemoteException 
	{   return DomainTableJustifiedMotivationServiceManager.getInstance().retrieveDomainTableJustifiedMotivation(domainTableJustifiedMotivationInOut);
	}
	public DomainTableJustifiedMotivationResponseClass checkChangeDomainTableJustifiedMotivation(DomainTableJustifiedMotivationInOut domainTableJustifiedMotivationInOut) throws XFRException ,RemoteException
	{
		return DomainTableJustifiedMotivationServiceManager.getInstance().checkChangeDomainTableJustifiedMotivation(domainTableJustifiedMotivationInOut);
	}
	public DomainTableDeductionPercentageResponseClass retrieveDomainTableDeductionPercentage(DomainTableDeductionPercentageInOut domainTableDeductionPercentageInOut) throws XFRException,RemoteException
	{
		return DomainTableDeductionPercentageServiceManager.getInstance().retrieveDomainTableDeductionPercentage(domainTableDeductionPercentageInOut);
	}
	public DomainTableDeductionPercentageResponseClass checkChangeDomainTableDeductionPercentage(DomainTableDeductionPercentageInOut domainTableDeductionPercentageInOut) throws XFRException,RemoteException
	{
		return DomainTableDeductionPercentageServiceManager.getInstance().checkChangeDomainTableDeductionPercentage(domainTableDeductionPercentageInOut);
	}
	public DomainTableDiscountGroupResponseClass retrieveDomainTableDiscountGroup(DomainTableDiscountGroupInOut domainTableDiscountGroupInOut) throws XFRException,RemoteException
		{
			return DomainTableDiscountGroupServiceManager.getInstance().retrieveDomainTableDiscountGroup(domainTableDiscountGroupInOut);
		}
	public DomainTableDiscountGroupResponseClass checkChangeDomainTableDiscountGroup(DomainTableDiscountGroupInOut domainTableDiscountGroupInOut) throws XFRException,RemoteException
		{
			return DomainTableDiscountGroupServiceManager.getInstance().checkChangeDomainTableDiscountGroup(domainTableDiscountGroupInOut);
		}
	public DomainTableBlockedValuesForFTResponseClass retrieveDomainTableBlockedValues(DomainTableBlockedValuesForFTInOut domainTableBlockedValuesForFTInOut) throws XFRException,RemoteException
			{
				return DomainTableBlockedValuesForFTServiceManager.getInstance().retrieveDomainTableBlockedValues(domainTableBlockedValuesForFTInOut);
			}
	public DomainTableBlockedValuesForFTResponseClass checkChangeDomainTableBlockedValues(DomainTableBlockedValuesForFTInOut domainTableBlockedValuesForFTInOut) throws XFRException,RemoteException
				{
					return DomainTableBlockedValuesForFTServiceManager.getInstance().checkChangeDomainTableBlockedValues(domainTableBlockedValuesForFTInOut);
				}
				
	public DomainTableCommunicationTypeResponseClass retrieveDomainTableCommunicationType(DomainTableCommunicationTypeInOut domainTableCommunicationTypeInOut) throws XFRException,RemoteException
					{
						return DomainTableCommunicationTypeServiceManager.getInstance().retrieveDomainTableCommunicationType(domainTableCommunicationTypeInOut);
					}
	public DomainTableCommunicationTypeResponseClass checkChangeDomainTableCommunicationType(DomainTableCommunicationTypeInOut domainTableCommunicationTypeInOut) throws XFRException,RemoteException
						{
							return DomainTableCommunicationTypeServiceManager.getInstance().checkChangeDomainTableCommunicationType(domainTableCommunicationTypeInOut);
						}				

	public DomainTableProfileTypeResponseClass retrieveDomainTableProfileType(DomainTableProfileTypeInOut domainTableProfileTypeInOut) throws XFRException,RemoteException
					{
						return DomainTableProfileTypeServiceManager.getInstance().retrieveDomainTableProfileType(domainTableProfileTypeInOut);
					}
	
	public DomainTableProfileTypeResponseClass checkChangeDomainTableProfileType(DomainTableProfileTypeInOut domainTableProfileTypeInOut) throws XFRException,RemoteException
					{
					   return DomainTableProfileTypeServiceManager.getInstance().checkChangeDomainTableProfileType(domainTableProfileTypeInOut);
					} 
    
	public DomainTableProfileTypeCommunicationTypeResponseClass retrieveDomainTableProfileTypeCommunicationType(DomainTableProfileTypeCommunicationTypeInOut domainTableProfileTypeCommunicationTypeInOut) throws XFRException,RemoteException
					{
					   return DomainTableProfileTypeCommunicationTypeServiceManager.getInstance().retrieveDomainTableProfileTypeCommunicationType(domainTableProfileTypeCommunicationTypeInOut);
					}
	
	public DomainTableProfileTypeCommunicationTypeResponseClass checkChangeDomainTableProfileTypeCommunicationType(DomainTableProfileTypeCommunicationTypeInOut domainTableProfileTypeCommunicationTypeInOut) throws XFRException,RemoteException
					{
					  return DomainTableProfileTypeCommunicationTypeServiceManager.getInstance().checkChangeDomainTableProfileTypeCommunicationType(domainTableProfileTypeCommunicationTypeInOut);
					} 
	public DomainTableProfileTypeCommunicationTypeFTResponseClass retrieveDomainTableProfileTypeCommunicationTypeFT(DomainTableProfileTypeCommunicationTypeFTInOut domainTableProfileTypeCommunicationTypeFTInOut) throws XFRException,RemoteException
					{
						   return DomainTableProfileTypeCommunicationTypeFTServiceManager.getInstance().retrieveDomainTableProfileTypeCommunicationTypeFT(domainTableProfileTypeCommunicationTypeFTInOut);
					}
	
	public DomainTableProfileTypeCommunicationTypeFTResponseClass checkChangeDomainTableProfileTypeCommunicationTypeFT(DomainTableProfileTypeCommunicationTypeFTInOut domainTableProfileTypeCommunicationTypeFTInOut) throws XFRException,RemoteException
					{
						  return DomainTableProfileTypeCommunicationTypeFTServiceManager.getInstance().checkChangeDomainTableProfileTypeCommunicationType(domainTableProfileTypeCommunicationTypeFTInOut);
					} 
    	
	// Domain Table Languages
	public GaussResponse insertLanguage(DomainTableLanguageInOut domainTableLanguageInOut) throws XFRException {
		return DomainTableLanguageServiceManager.getInstance().insertLanguage(domainTableLanguageInOut);
	}
	public DomainTableLanguageResponseClass retrieveLanguageResponseClass(DomainTableLanguageInOut domainTableLanguageInOut) throws XFRException {
		return DomainTableLanguageServiceManager.getInstance().retrieveLanguageResponseClass(domainTableLanguageInOut);
	}
	
	// (new) Special Features
	public FeaturesResponseClass newInquirySpecialFeatures(FeaturesInOut featuresInOut) throws XFRException {
		return SpecialFeaturesServiceManager.getInstance().newInquirySpecialFeatures(featuresInOut);
	}
	public FeaturesResponseClass verifySpecialFeaturesChange(FeaturesInOut featuresInOut) throws XFRException {
		return SpecialFeaturesServiceManager.getInstance().verifySpecialFeaturesChange(featuresInOut);
	}
	public FeaturesResponseClass confirmSpecialFeaturesChange(FeaturesInOut featuresInOut) throws XFRException {
		return SpecialFeaturesServiceManager.getInstance().confirmSpecialFeaturesChange(featuresInOut);
	}
	
	// Standard Features
	public FeaturesResponseClass inquiryStandardFeatures(FeaturesInOut featuresInOut) throws XFRException {
		return StandardFeaturesServiceManager.getInstance().inquiryStandardFeatures(featuresInOut);
	}
	public FeaturesResponseClass verifyStandardFeaturesChange(FeaturesInOut featuresInOut) throws XFRException {
		return StandardFeaturesServiceManager.getInstance().verifyStandardFeaturesChange(featuresInOut);
	}
	public FeaturesResponseClass confirmStandardFeaturesChange(FeaturesInOut featuresInOut) throws XFRException {
		return StandardFeaturesServiceManager.getInstance().confirmStandardFeaturesChange(featuresInOut);
	}
	
	// Massive Variation - Standard and Faculty
	public MassiveVariationResponseClass massiveVariationStandardChange(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationStandardServiceManager.getInstance().massiveVariationStandardChange(massiveVariationInOut);
	}
	public MassiveVariationResponseClass massiveVariationStandardCheckChange(MassiveVariationInOut massiveVariationInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException {
		return MassiveVariationStandardServiceManager.getInstance().massiveVariationStandardCheckChange(massiveVariationInOut,justifiedMotivationInOut);
	}
	public MassiveVariationResponseClass massiveVariationFacultyChange(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFacultyServiceManager.getInstance().massiveVariationFacultyChange(massiveVariationInOut);
	}
	public MassiveVariationResponseClass massiveVariationFacultyCheckChange(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFacultyServiceManager.getInstance().massiveVariationFacultyCheckChange(massiveVariationInOut);
	}

	/*
	 * Metodo per recuperare una lista di Fman dalla tabella CS00TU02
	 */
	public MassiveVariationResponseClass retrieveMassiveVariationFmanListFrom02(MassiveVariationInOut massiveVariationInOut) throws XFRException	{
		return MassiveVariationFmanServiceManager.getInstance().retrieveMassiveVariationFmanListFrom02(massiveVariationInOut);
	}
	
	/*
	 * Metodo utilizzato nei casi crud di un FMAN
	 */
	public MassiveVariationResponseClass crudFmanMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFmanServiceManager.getInstance().crudFmanMassiveVariation(massiveVariationInOut); 
	}
	
	/*
	 * Metodo per recuperare una lista di Fndg dalla tabella CS00TU02
	 */
	public MassiveVariationResponseClass retrieveMassiveVariationFndgListFrom02(MassiveVariationInOut massiveVariationInOut) throws XFRException	{
		return MassiveVariationFndgServiceManager.getInstance().retrieveMassiveVariationFndgListFrom02(massiveVariationInOut);
	}
	
	/*
	 * Metodo utilizzato nei casi crud di un FNDG
	 */
	public MassiveVariationResponseClass crudFndgMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFndgServiceManager.getInstance().crudFndgMassiveVariation(massiveVariationInOut); 
	}

	
	/*
	 * Metodo per recuperare una lista di cate dell'intero Istituto
	 */
	public MassiveVariationResponseClass retrieveMassiveVariationCateList(MassiveVariationInOut massiveVariationInOut) throws XFRException	{
		return MassiveVariationCateServiceManager.getInstance().retrieveMassiveVariationCateList(massiveVariationInOut);
	}
	
	/*
	 * Metodo utilizzato nei casi crud di una cate
	 */
	public MassiveVariationResponseClass crudCateMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationCateServiceManager.getInstance().crudCateMassiveVariation(massiveVariationInOut); 
	}

	/*
	 * Metodo per recuperare le cate investite da una massiva (tabella CS00TU02)
	 */
	public MassiveVariationResponseClass retrieveCateInMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationCateServiceManager.getInstance().retrieveCateInMassiveVariation(massiveVariationInOut);
	}

	/*
	 * Metodo per recuperare una lista di segmenti di credito dell'intero Istituto
	 */
	public MassiveVariationResponseClass retrieveMassiveVariationSgmcList(MassiveVariationInOut massiveVariationInOut) throws XFRException	{
		return MassiveVariationSgmcServiceManager.getInstance().retrieveMassiveVariationSgmcList(massiveVariationInOut);
	}
	
	/*
	 * Metodo utilizzato nei casi crud di un segmento di credito
	 */
	public MassiveVariationResponseClass crudSgmcMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationSgmcServiceManager.getInstance().crudSgmcMassiveVariation(massiveVariationInOut); 
	}

	/*
	 * Metodo per recuperare i segmenti di credito investiti da una massiva (tabella CS00TU02)
	 */
	public MassiveVariationResponseClass retrieveSgmcInMassiveVariation(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationSgmcServiceManager.getInstance().retrieveSgmcInMassiveVariation(massiveVariationInOut);
	}

	// Massive Variation - Loading and Request List
	public MassiveVariationResponseClass retrieveMassiveVariationRequestList(MassiveVariationInOut massiveVariationInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException {
		return MassiveVariationManageServiceManager.getInstance().retrieveMassiveVariationRequestList(massiveVariationInOut,justifiedMotivationInOut);
	}
	//	Massive Variation - Request Account List
	public MassiveVariationResponseClass retrieveMassiveVariationAccountList(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationManageServiceManager.getInstance().retrieveMassiveVariationAccountList(massiveVariationInOut);
	}
	
	public MassiveVariationSQLResponseClass retrieveMassiveVariationAccountsListSQL(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationAccountsListPersistenceManager.getInstance().retrieveAccountsList(massiveVariationInOut);
	}
	
	public MassiveVariationResponseClass changeMassiveVariationHeader(MassiveVariationInOut massiveVariationInOut,JustifiedMotivationInOut justifiedMotivationInOut) throws XFRException {
		return MassiveVariationManageServiceManager.getInstance().changeMassiveVariationHeader(massiveVariationInOut,justifiedMotivationInOut);
	}
	
	// Registra la selezione dei rapporti in una massiva
	public MassiveVariationResponseClass massiveVariationSaveAccount(MassiveVariationInOut massiveVariationInOut) throws XFRException {
			return MassiveVariationManageServiceManager.getInstance().massiveVariationSaveAccount(massiveVariationInOut);
	}
	
	// Massive Variation - Target Objects
	public MassiveVariationResponseClass retrieveMassiveVariationTargetSearch(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationTargetServiceManager.getInstance().retrieveMassiveVariationTargetSearch(massiveVariationInOut);
	}
	
	// Massive Variation - Condition
	public MassiveVariationResponseClass retrieveMassiveVariationCondition(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationConditionServiceManager.getInstance().retrieveMassiveVariationCondition(massiveVariationInOut);
	}
	public MassiveVariationResponseClass massiveVariationConditionModify(MassiveVariationResponseClass rClass) throws XFRException {
		return MassiveVariationConditionServiceManager.getInstance().massiveVariationConditionModify(rClass);
	
	}
	
	// Massive Variation - Account and Agreement list
	public MassiveVariationResponseClass retrieveMassiveVariationListAccount(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationListAccountServiceManager.getInstance().retrieveMassiveVariationListAccount(massiveVariationInOut);
	}
	
	// Massive Variation - Loading and Request List
	public MassiveVariationResponseClass retrieveMassiveVariationCustomerList(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFeesServiceManager.getInstance().retrieveMassiveVariationCustomerList(massiveVariationInOut);
	}
	
	// Massive Variation - Update Customer
	public MassiveVariationResponseClass updateMassiveVariationCustomerList(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFeesServiceManager.getInstance().updateMassiveVariationCustomerList(massiveVariationInOut);
	}
	
	// Massive Variation - Loading and Request List
	public MassiveVariationResponseClass retrieveMassiveVariationCustomerDetail(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFeesServiceManager.getInstance().retrieveMassiveVariationCustomerDetail(massiveVariationInOut);
	}
	
	// Massive Variation - Loading and Request List
	public MassiveVariationResponseClass saveMassiveVariationCustomerDetail(MassiveVariationInOut massiveVariationInOut) throws XFRException {
		return MassiveVariationFeesServiceManager.getInstance().saveMassiveVariationCustomerDetail(massiveVariationInOut);
	}
	
	// Consultation
	public ConsultationResponseClass retrieveConsultationListDetail(ConsultationInOut inOut, CommonParameters cP) throws XFRException {
		return ConsultationServiceManager.getInstance().retrieveConsultationListDetail(inOut,cP);
	}
	
	public DomainTableTechnicalTypeResponseClass usuryRatesList(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException {
		return UsuryRatesServiceManager.getInstance().usuryRatesList(indexedRateRegistryInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveUsuryRatesSelectionList(IndexedRateRegistryInOut indexedRateRegistryInOut) throws XFRException {
		return UsuryRatesServiceManager.getInstance().retrieveUsuryRatesSelectionList(indexedRateRegistryInOut);
	}
	
	// Account Reservation
	public ProductListResponseClass retrieveProductList(CommonParameters cP, String ndg) throws XFRException, RemoteException {
		return ProductListServiceManager.getInstance().retrieveProductList(cP, ndg);
	}
	public AccountReservationResponseClass reservedAccount(CommonParameters cP,AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException {
		return AccountReservationServiceManager.getInstance().reservedAccount(cP,accountReservationInOut);
	}
	public AccountReservationResponseClass inquiryAccountReserved(CommonParameters cP, AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException {
		return InquiryAccountReservedServiceManager.getInstance().inquiryAccountReserved(cP,accountReservationInOut);
	}
	public AccountReservationResponseClass modifyAccountReserved(CommonParameters cP, AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException {
		return VariationAccountReservedServiceManager.getInstance().modifyAccountReserved(cP, accountReservationInOut);
	}
	public GaussResponse deleteAccountReserved(CommonParameters cP, AccountReservationInOut accountReservationInOut) throws XFRException, RemoteException {
		return DeleteAccountReservedServiceManager.getInstance().deleteAccountReserved(cP, accountReservationInOut);
	}
	public GaussResponse convalidAccountReserved(CommonParameters cP, String ndg, String accountId, String fiscalRegimen) throws XFRException, RemoteException {
		return ConvalidationAccountResercedServiceManager.getInstance().convalidAccountReserved(cP, ndg, accountId, fiscalRegimen);
	}

	// Active Account 
	public ActiveAccountResponseClass inquiryActiveAccount(CommonParameters cP, ActiveAccountInOut activeAccountInOut) throws XFRException, RemoteException{
		return InquiryActiveAccountServiceManager.getInstance().inquiryActiveAccount(cP, activeAccountInOut);
	}
	public ActiveAccountResponseClass modifyActiveAccount(CommonParameters cP, ActiveAccountInOut activeAccountInOut) throws XFRException, RemoteException{
		return VariationActiveAccountServiceManager.getInstance().modifyActiveAccount(cP, activeAccountInOut);
	}

	//Your Conditions (XELION)
	public YourConditionsResponseClass retrieveYourConditionsDetail(YourConditionsInOut yourConditionsInOut) throws XFRException, RemoteException{
		return YourConditionsServiceManager.getInstance().retrieveYourConditionsDetail(yourConditionsInOut);
	}

	public ArrayList retrieveYourConditionsDescriptions() throws XFRException, RemoteException{
		return YourConditionsPersistenceManager.getInstance().retrieveYourConditionsDescriptions();
	}
	
	// Loan: Chiamata esterna dela FIDI
	public LoanResponseClass retrieveLoanConditions(LoanAnagInOut loanAnagInOut) throws XFRException, RemoteException{
		return LoanServiceManager.getInstance().retrieveLoanConditions(loanAnagInOut);
	}
	public LoanResponseClass retrieveLoanEchelons(LoanAnagInOut loanAnagInOut) throws XFRException, RemoteException{
		return LoanServiceManager.getInstance().retrieveLoanEchelons(loanAnagInOut);
	}
	
	public LoanResponseClass changeEchelon(LoanAnagInOut loanAnagInOut) throws XFRException, RemoteException {
	return LoanServiceManager.getInstance().changeEchelon(loanAnagInOut);
		}
		
	public FindAccountResponseClass findAccount(InputCS0 inputCS0, UserData userInfo) throws XFRException, RemoteException {
		return GetterConditionsListServiceManager.getInstance().findAccount(inputCS0, userInfo);
	}
	
	public DomainTableTechnicalTypeResponseClass retrieveDomainTableTechnicalCube(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return DomainTableTechnicalCubeServiceManager.getInstance().retrieveDomainTableTechnicalCube(domainTableTechnicalTypeInOut);
	}
	
	public DomainTableTechnicalTypeResponseClass insertDomainTableTechnicalCube(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return DomainTableTechnicalCubeServiceManager.getInstance().insertDomainTableTechnicalCube(domainTableTechnicalTypeInOut);
	}

	// Metodi per C0 (chiamate esterne)
	public PromotionalPositions retrievePromotionalPositions(String accountType, it.usi.xframe.ifg.bfutil.wpro.UserData userInfo) throws XFRException, RemoteException {
		return null;
	}
	public SimplePosition retrieveSinglePosition(String position) throws XFRException, RemoteException {
		return null;
	}
	public OpenCondition retrieveOpenCondition(Locale locale, String condition, String channel) throws XFRException, RemoteException {
		return null;
	}
	public OpenCondition retrieveOpenCondition(Locale locale, String condition, String channel, Object value) throws XFRException, RemoteException {
		return null;
	}
//	metodi per chiamate esterne da UWM (pj142229 - preventivatore)
	public CcdPrintResponseClass printPreventivo(StampaInOut params) throws XFRException, RemoteException{
		return null;
	}
	public ComboBox getFidi(String tipoOp, String filiale,String numPrev) throws XFRException, RemoteException,CcdException	{
		return null;
	}
 	public ComboBox getFidiFromCodice(String tipoOp, String filiale,String numPrev,String codice) throws XFRException, RemoteException,CcdException	{
		return null;
	}	
	public ComboBox getConvenzioniFromDesc(String tipoOp, String filiale,String numPrev,String desc) throws XFRException, RemoteException,CcdException {
		return null;
	}
	public Preventivo calcolaPreventivo(String filiale, String numPrev,String codFido,String tecFido,String posizione,String importo,String durata,String matrOpe,String ndg,String desFido,String filialeCcd,String tipoRapp,String conto,String speseIniziali,String giorniEffettivi) throws XFRException, RemoteException,CcdException {
		return null;
	}
//	chiamata alla CS0SLEAN per Fast Credit (UWM) 
	public FastCreditResponseClass retrieveFastCreditCS0(FastCreditBean filter) throws XFRException, RemoteException, SQLException {
	    return null;
	}
	// ErfolgsCard
	public ErfolgsCardResponseClass checkTechnicalType(ErfolgsCardFilterInOut objIn) throws XFRException, RemoteException {
		return ErfolgsCardServiceManager.getInstance().checkTechnicalType(objIn);
	}
	public ErfolgsCardResponseClass updateSimulation(ErfolgsCardFilterInOut objIn) throws XFRException, RemoteException {
		return ErfolgsCardServiceManager.getInstance().updateSimulation(objIn);
	}
	public ErfolgsCardResponseClass listTechnicalType(ErfolgsCardFilterInOut objIn) throws XFRException, RemoteException {
		return ErfolgsCardServiceManager.getInstance().listTechnicalType(objIn);
	}
	
	public X4eyesResponseClass inquiryListX4Eyes(X4eyesInOut x4eyesInOut) throws XFRException {
		return X4EyesServiceManager.getInstance().inquiryListX4Eyes(x4eyesInOut);
	}
	
	public X4eyesResponseClass detListX4Eyes(X4eyesInOut x4eyesInOut) throws XFRException {
		return X4EyesServiceManager.getInstance().detListX4Eyes(x4eyesInOut);
	}
	
	public X4eyesResponseClass modListX4Eyes(X4eyesInOut x4eyesInOut) throws XFRException {
		return X4EyesServiceManager.getInstance().modListX4Eyes(x4eyesInOut);
	}
//  _______________________________________________________________________
//  Metodo da usare in sviluppo
//	public void tableElab(String table,ArrayList rows)throws XFRException, RemoteException
//	{
//		TablePersistenceManager.getInstance().tableElab(table,rows);
//	}
//  ��������������������������������������������������������������������������
	
	//Cre.Ma - ConditionCreditInquiry
	public ConditionCreditInquiryResponseClass getConditionCreditInquiry(ConditionCreditInquiryManagementInOut inOut, String inTipoCall) throws XFRException, RemoteException {
		return ConditionCreditInquiryPersistanceManager.getInstance().getConditionCreditInquiry(inOut, inTipoCall);
	}
	
	//ConditionEstimate
	public ConditionEstimateResponseClass getConditionEstimate(ConditionEstimateManagementInOut inOut) throws XFRException, RemoteException {
		return ConditionEstimatePersistanceManager.getInstance().getConditionEstimate(inOut);
	}
	
	
	
	public Object callSPServiceForMassiveTest(String spName, Map spParams,
			UserData userData, DomainParams domainParams, int numOutputParam)
			throws Exception {
		
		IFJDomainParams mdmParams = new IFJDomainParams(userData);
		mdmParams.setDomainParams(domainParams);

		try
		{
			return CS0ChallangesManager.getInstance().callSPServiceForMassiveTest(spName, spParams,mdmParams, numOutputParam);
		}
		catch ( Exception e )
		{
			// bla bla 
			getSupport().setRollBackOnly();
		}
		finally
		{
		}
		
		return null;
	}

	public Object callGaussServiceForMassiveTest(String serviceName,
			Map params, UserData userData, DomainParams domainParams)
			throws Exception {

		IFJDomainParams mdmParams = new IFJDomainParams(userData);
		mdmParams.setDomainParams(domainParams);

		return CS0ChallangesManager.getInstance().callGaussServiceForMassiveTest(serviceName,params, mdmParams);

	}

	//=============================================
	//==== DGSIG - OPEN parameters management =====
	//=============================================

	public Map retrieveOpenParametriColumnsSize() throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("PK0");
		return pm.retrieveColumnsSize();
	}
	public CS0OpenParamsElement[] getOpenParameters(DomainParams domainParams) throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("PK0");
		OpenParamsElement [] dbRes = pm.retrieveOpenParameters(domainParams);
		
		return getAsCS0OpenParamsElement(dbRes);
	}
	
	private CS0OpenParamsElement[] getAsCS0OpenParamsElement(
			OpenParamsElement[] dbRes) {
		
		CS0OpenParamsElement[] result = dbRes == null ? null : new CS0OpenParamsElement[dbRes.length];
		
		if ( result == null )
			return null;
		
		for (int i = 0; i < dbRes.length; i++)
			result[i] = getAsCS0OpenParamsElement(dbRes[i]);

		return result;
	}

	private CS0OpenParamsElement getAsCS0OpenParamsElement(
			OpenParamsElement element) {
		
		return new CS0OpenParamsElement(
			element.getBank(),
			element.getParameter(),
			element.getDesParameter(),
			element.getStateParameter(),
			element.getValueParameter(),
			element.getTypeParameter()
		);

	}

	private OpenParamsElement getAsOpenParamElement(
			CS0OpenParamsElement element) {
		
		return new OpenParamsElement(
			element.getBank(),
			element.getParameter(),
			element.getDesParameter(),
			element.getStateParameter(),
			element.getValueParameter(),
			element.getTypeParameter()
		);

	}
	
	public int insertNewOpenParameter(CS0OpenParamsElement openParam) throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("CS0");
		return pm.insertNewOpenParameter(getAsOpenParamElement(openParam));
	}
	public int removeOpenParameter(CS0OpenParamsElement openParam) throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("CS0");
		return pm.removeOpenParameter(getAsOpenParamElement(openParam));
	}
	public int updateOpenParameter(CS0OpenParamsElement toUpdate, CS0OpenParamsElement newParam) throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("CS0");
		return pm.updateOpenParameter(getAsOpenParamElement(toUpdate), getAsOpenParamElement(newParam));
	}
	public void updateOpenParameterCache(CS0OpenParamsElement newParam) throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("CS0");
		if(newParam != null){
			pm.refreshCache(newParam.getValueParameter());
		}
	}
	public int updateRifParametro(String newRifParam, String bank, String parameterName) throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("CS0");
		return pm.updateStateParametro(newRifParam, bank, parameterName);
	}
	public int updateValParametro(String newValParam, String bank, String parameterName, String parameterRif) throws Exception {
		IFJEGTParametersPersistenceManager pm = (IFJEGTParametersPersistenceManager) IFJEGTParametersPersistenceManager.getUniqueInstance("CS0");
		return pm.updateValParametro(newValParam, bank, parameterName, parameterRif);
	}	

	// Aggiunti per NP1 ndg type unit form
	public DomainTableTechnicalTypeResponseClass retrieveNdgTypeForUnitList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeUnitFormServiceManager.getInstance().retrieveNdgTypeForUnitList(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveUnitFormList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeUnitFormServiceManager.getInstance().retrieveUnitFormList(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass retrieveNdgUnitCouplesList(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeUnitFormServiceManager.getInstance().retrieveNdgUnitCouplesList(domainTableTechnicalTypeInOut);
	}
	public DomainTableTechnicalTypeResponseClass crudNdgUnitCouple(DomainTableTechnicalTypeInOut domainTableTechnicalTypeInOut) throws XFRException, RemoteException {
		return NdgTypeUnitFormServiceManager.getInstance().crudNdgUnitCouple(domainTableTechnicalTypeInOut);
	}
	
	
}