package it.usi.xframe.cs0.wsutil.ConditionEstimate;

import it.usi.xframe.cs0.bfintf.ICs0ServiceFacade;
import it.usi.xframe.cs0.bfutil.Cs0ServiceFactory;
import it.usi.xframe.system.errors.XFRException;

import java.text.ParseException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ConditionEstimateWS {

	static Log logger = LogFactory.getLog(ConditionEstimateWS.class);
	
	/**
	 * ConditionEstimateWS.ConditionEstimate
	 * 
	 * @param request
	 * @return
	 * @throws XFRException
	 * @throws ParseException
	 */
	public ConditionEstimateResponse conditionEstimate (ConditionEstimateIn request) throws XFRException, ParseException {
		
		ConditionEstimateResponse conditionEstimateResponse = new ConditionEstimateResponse();
		ConditionEstimateResponseClass responseClass = new ConditionEstimateResponseClass();
		
		ConditionEstimateManagementInOut inOut = new ConditionEstimateManagementInOut();
		
		// valorizzazione input
		inOut = transferInput(request);
		
		try {
			Cs0ServiceFactory cs0Factory = Cs0ServiceFactory.getInstance();
			try {
				ICs0ServiceFacade cs0Service = cs0Factory.getCs0ServiceFacade();
				try {
					// chiamata a host alla stored CS0SPPSO
					responseClass = cs0Service.getConditionEstimate(inOut);
					
				} finally {
					cs0Factory.dispose(cs0Service);
				}
			} catch (Exception e) {
				logger.error("ConditionEstimateWS.ConditionEstimate - error (1): " + e.getMessage());
				throw new Exception(e);
			}
		} catch (Exception ex) {
			logger.error("ConditionEstimateWS.ConditionEstimate - error (2): " + ex.getMessage());
		}
		
		return null;
		
	}
	
	private ConditionEstimateManagementInOut transferInput (ConditionEstimateIn in){
		
		ConditionEstimateManagementInOut inOut = new ConditionEstimateManagementInOut();
		
		inOut.setEstimateNumber(in.getEstimateNumber());
		inOut.setCodFtf(in.getCodFtf());
		inOut.setDescFtf(in.getDescFtf());
		inOut.setFtf(in.getFtf());
		inOut.setPosition(in.getPosition());
		inOut.setAmount(in.getAmount());
		inOut.setPeriod(in.getPeriod());
		inOut.setUserId(in.getUserId());
		inOut.setNdg(in.getNdg());
		inOut.setNote(in.getNote());
		inOut.setBranch(in.getBranch());
		inOut.setAccountType(in.getAccountType());
		inOut.setAccount(in.getAccount());
		inOut.setCost(in.getCost());
		inOut.setPeriodDay(in.getPeriodDay());

		return inOut;
	}
	
	
}
