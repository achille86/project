/**
 * ApplicationCode.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */
package it.usi.xframe.cmc.utility;

import java.io.Serializable;

public class ApplicationCode  implements Serializable {

	private static final long serialVersionUID = 4822007219796264101L;
	private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    private transient ThreadLocal __history;
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj.getClass() != this.getClass()) { return false;}
        ApplicationCode other = (ApplicationCode) obj;
        boolean _equals;
        _equals = true
            && ((this.code==null && other.getCode()==null) || 
             (this.code!=null &&
              this.code.equals(other.getCode())));
        if (!_equals) { return false; }
        if (__history == null) {
            synchronized (this) {
                if (__history == null) {
                    __history = new ThreadLocal();
                }
            }
        }
        ApplicationCode history = (ApplicationCode) __history.get();
        if (history != null) { return (history == obj); }
        if (this == obj) return true;
        __history.set(obj);
        __history.set(null);
        return true;
    }

    private transient ThreadLocal __hashHistory;
    public int hashCode() {
        if (__hashHistory == null) {
            synchronized (this) {
                if (__hashHistory == null) {
                    __hashHistory = new ThreadLocal();
                }
            }
        }
        ApplicationCode history = (ApplicationCode) __hashHistory.get();
        if (history != null) { return 0; }
        __hashHistory.set(this);
        int _hashCode = 1;
        if (getCode() != null) {
            _hashCode += getCode().hashCode();
        }
        __hashHistory.set(null);
        return _hashCode;
    }

}
