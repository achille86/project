/**
 * MessageId.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */

package it.usi.xframe.cmc.utility;

import java.io.Serializable;

public class MessageId implements Serializable {

	private static final long serialVersionUID = -2149738117988485001L;
	private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private transient ThreadLocal __history;
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj.getClass() != this.getClass()) { return false;}
        MessageId other = (MessageId) obj;
        boolean _equals;
        _equals = true
            && this.id == other.getId();
        if (!_equals) { return false; }
        if (__history == null) {
            synchronized (this) {
                if (__history == null) {
                    __history = new ThreadLocal();
                }
            }
        }
        MessageId history = (MessageId) __history.get();
        if (history != null) { return (history == obj); }
        if (this == obj) return true;
        __history.set(obj);
        __history.set(null);
        return true;
    }

    private transient ThreadLocal __hashHistory;
    public int hashCode() {
        if (__hashHistory == null) {
            synchronized (this) {
                if (__hashHistory == null) {
                    __hashHistory = new ThreadLocal();
                }
            }
        }
        MessageId history = (MessageId) __hashHistory.get();
        if (history != null) { return 0; }
        __hashHistory.set(this);
        int _hashCode = 1;
        _hashCode += getId();
        __hashHistory.set(null);
        return _hashCode;
    }

}
