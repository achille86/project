/**
 * ErrorMessageList.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */

package it.usi.xframe.cmc.utility;

import java.io.Serializable;
import java.lang.reflect.Array;

public class ErrorMessageList  implements Serializable {

	private static final long serialVersionUID = -6843592957196158136L;
	private ErrorMessage[] errorMessage;

    public ErrorMessage[] getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(ErrorMessage[] errorMessage) {
        this.errorMessage = errorMessage;
    }

    public ErrorMessage getErrorMessage(int i) {
        return errorMessage[i];
    }

    public void setErrorMessage(int i, ErrorMessage value) {
        this.errorMessage[i] = value;
    }

    private transient ThreadLocal __history;
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj.getClass() != this.getClass()) { return false;}
        if (__history == null) {
            synchronized (this) {
                if (__history == null) {
                    __history = new ThreadLocal();
                }
            }
        }
        ErrorMessageList history = (ErrorMessageList) __history.get();
        if (history != null) { return (history == obj); }
        if (this == obj) return true;
        __history.set(obj);
        ErrorMessageList other = (ErrorMessageList) obj;
        boolean _equals;
        _equals = true
            && ((this.errorMessage==null && other.getErrorMessage()==null) || 
             (this.errorMessage!=null &&
              java.util.Arrays.equals(this.errorMessage, other.getErrorMessage())));
        if (!_equals) {
            __history.set(null);
            return false;
        };
        __history.set(null);
        return true;
    }

    private transient ThreadLocal __hashHistory;
    public int hashCode() {
        if (__hashHistory == null) {
            synchronized (this) {
                if (__hashHistory == null) {
                    __hashHistory = new ThreadLocal();
                }
            }
        }
        ErrorMessageList history = (ErrorMessageList) __hashHistory.get();
        if (history != null) { return 0; }
        __hashHistory.set(this);
        int _hashCode = 1;
        if (getErrorMessage() != null) {
            for (int i=0;
                 i<Array.getLength(getErrorMessage());
                 i++) {
                Object obj = Array.get(getErrorMessage(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashHistory.set(null);
        return _hashCode;
    }

}
