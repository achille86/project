package it.usi.xframe.cmc.utility;

import it.usi.xframe.cmc.CmcServiceException;
import it.usi.xframe.cmc.model.InterfaceFieldsOutput;

import java.util.Calendar;

public class ExceptionManager {
	
	private static String GENERIC_ERROR = "GENERIC ERROR";
    
    public static ServiceException   generateServiceError (CommonHeader header, String key, int errorCode, String message) {
    	
		ErrorMessage errorMessage = new ErrorMessage();
		
		MessageText messageText = new MessageText();
		messageText.setText(message);
		errorMessage.setMessageText(messageText);
		
		errorMessage.setMessageLevel(MessageLevelError.ERROR);
		
		
		MessageKey messageKey = new MessageKey();
		
		ApplicationCode applicationCode = new ApplicationCode();
		applicationCode.setCode(key);

		MessageId messageId = new MessageId();
		messageId.setId(errorCode);
	
		messageKey.setCode(applicationCode);
		messageKey.setId(messageId);
		
		
		errorMessage.setMessageKey(messageKey);
		
		errorMessage.setTimestamp(Calendar.getInstance());
		ErrorMessageList errorList = new ErrorMessageList();
		errorList.setErrorMessage(new ErrorMessage[] { errorMessage });

		return new ServiceException(header.getCorrelationId(), errorList);
    }
    
    public static CmcServiceException generateRollbackServiceError (CommonHeader header, String key, int errorCode, String message, String input, String output) {
    	
		ErrorMessage errorMessage = new ErrorMessage();
		
		MessageText messageText = new MessageText();
		messageText.setText(message);
		errorMessage.setMessageText(messageText);
		
		errorMessage.setMessageLevel(MessageLevelError.ERROR);
		
		
		MessageKey messageKey = new MessageKey();
		
		ApplicationCode applicationCode = new ApplicationCode();
		applicationCode.setCode(key);

		MessageId messageId = new MessageId();
		messageId.setId(errorCode);
	
		messageKey.setCode(applicationCode);
		messageKey.setId(messageId);
		
		
		errorMessage.setMessageKey(messageKey);
		
		errorMessage.setTimestamp(Calendar.getInstance());
		ErrorMessageList errorList = new ErrorMessageList();
		errorList.setErrorMessage(new ErrorMessage[] { errorMessage });
        
		ServiceException se=new ServiceException(header.getCorrelationId(), errorList); //cambiato correlationId in stringa
		return new CmcServiceException(se,input,output);
    }
    
    public static CmcServiceException generateRollbackServiceError (CommonHeader header, InterfaceFieldsOutput iOutput, String input, String output) {
    	return generateRollbackServiceError(header, "GEC", (int)iOutput.getReturnCode(), iOutput.getReturnMessage(),input,output);
    }
    
    public static ServiceException generateServiceError (CommonHeader header) {
    	return generateServiceError(header, "GEC", 0, GENERIC_ERROR);
    }
    
    public static ServiceException   generateServiceError (CommonHeader header, Exception e) {
    	return generateServiceError(header, "GEC", 1, e.getMessage());
    }
    
    public static ServiceException   generateServiceError (CommonHeader header, InterfaceFieldsOutput iOutput) {
    	return generateServiceError(header, "GEC", (int)iOutput.getReturnCode(), iOutput.getReturnMessage());
    }
    
    public static SystemException generateSystemError (CommonHeader header, String key, int errorCode, String customerErrorCode, String message) {
    	
    	ErrorMessage errorMessage = new ErrorMessage();
		
		MessageText messageText = new MessageText();
		messageText.setText(message);
		errorMessage.setMessageText(messageText);
		
		errorMessage.setMessageLevel(MessageLevelError.ERROR);
		
		
		MessageKey messageKey = new MessageKey();
		
		ApplicationCode applicationCode = new ApplicationCode();
		applicationCode.setCode(key);

		MessageId messageId = new MessageId();
		messageId.setId(errorCode);
	
		messageKey.setCode(applicationCode);
		messageKey.setId(messageId);
		
		errorMessage.setMessageKey(messageKey);
		
		errorMessage.setTimestamp(Calendar.getInstance());
		ErrorMessageList errorList = new ErrorMessageList();
		errorList.setErrorMessage(new ErrorMessage[] { errorMessage });
		
		return new SystemException(header.getCorrelationId(), customerErrorCode, errorList);
    }
    
    public static SystemException generateSystemError (CommonHeader header) {
    	return generateSystemError(header, "GEC", 10000, "", GENERIC_ERROR);
    }

    public static SystemException generateSystemError (CommonHeader header, Exception e) {
    	return generateSystemError(header, "GEC", 10001, "", e.getMessage());
    }
   
}
