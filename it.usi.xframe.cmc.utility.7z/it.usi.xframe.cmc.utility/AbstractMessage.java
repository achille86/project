/**
 * AbstractMessage.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */

package it.usi.xframe.cmc.utility;

import java.io.Serializable;
import java.util.Calendar;

public abstract class AbstractMessage  implements Serializable {

	private static final long serialVersionUID = 3823629399394573601L;
	private MessageKey messageKey;
    private MessageText messageText;
    private Calendar timestamp;
    private String operationId;

    public MessageKey getMessageKey() {
        return messageKey;
    }

    public void setMessageKey(MessageKey messageKey) {
        this.messageKey = messageKey;
    }

    public MessageText getMessageText() {
        return messageText;
    }

    public void setMessageText(MessageText messageText) {
        this.messageText = messageText;
    }

    public java.util.Calendar getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(java.util.Calendar timestamp) {
        this.timestamp = timestamp;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    private transient ThreadLocal __history;
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj.getClass() != this.getClass()) { return false;}
        AbstractMessage other = (AbstractMessage) obj;
        boolean _equals;
        _equals = true
            && ((this.operationId==null && other.getOperationId()==null) || 
             (this.operationId!=null &&
              this.operationId.equals(other.getOperationId())));
        if (!_equals) { return false; }
        if (__history == null) {
            synchronized (this) {
                if (__history == null) {
                    __history = new ThreadLocal();
                }
            }
        }
        AbstractMessage history = (AbstractMessage) __history.get();
        if (history != null) { return (history == obj); }
        if (this == obj) return true;
        __history.set(obj);
        _equals = true
            && ((this.messageKey==null && other.getMessageKey()==null) || 
             (this.messageKey!=null &&
              this.messageKey.equals(other.getMessageKey())))
            && ((this.messageText==null && other.getMessageText()==null) || 
             (this.messageText!=null &&
              this.messageText.equals(other.getMessageText())))
            && ((this.timestamp==null && other.getTimestamp()==null) || 
             (this.timestamp!=null &&
              this.timestamp.equals(other.getTimestamp())));
        if (!_equals) {
            __history.set(null);
            return false;
        };
        __history.set(null);
        return true;
    }

    private transient ThreadLocal __hashHistory;
    public int hashCode() {
        if (__hashHistory == null) {
            synchronized (this) {
                if (__hashHistory == null) {
                    __hashHistory = new ThreadLocal();
                }
            }
        }
        AbstractMessage history = (AbstractMessage) __hashHistory.get();
        if (history != null) { return 0; }
        __hashHistory.set(this);
        int _hashCode = 1;
        if (getMessageKey() != null) {
            _hashCode += getMessageKey().hashCode();
        }
        if (getMessageText() != null) {
            _hashCode += getMessageText().hashCode();
        }
        if (getTimestamp() != null) {
            _hashCode += getTimestamp().hashCode();
        }
        if (getOperationId() != null) {
            _hashCode += getOperationId().hashCode();
        }
        __hashHistory.set(null);
        return _hashCode;
    }

}
