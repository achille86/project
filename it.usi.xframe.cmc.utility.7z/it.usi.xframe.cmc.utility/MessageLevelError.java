/**
 * MessageLevelError.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */
package it.usi.xframe.cmc.utility;

import java.io.Serializable;
import java.util.HashMap;

public class MessageLevelError implements Serializable {

	private static final long serialVersionUID = -2717516086513025156L;
	private String _value_;
    private static HashMap _table_ = new HashMap();
    public static final String _ERROR = "ERROR";
    public static final MessageLevelError ERROR = new MessageLevelError(_ERROR);

    // Constructor
    protected MessageLevelError(String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public String getValue() { 
    	return _value_;
    }
    public static MessageLevelError fromValue(String value) throws IllegalStateException {
        MessageLevelError item = (MessageLevelError) _table_.get(value);
        if (item == null) { 
        	throw new IllegalStateException();
        }
        return item;
    }
    public static MessageLevelError fromString(java.lang.String value) throws IllegalStateException {
        return fromValue(value);
    }
    public boolean equals(Object obj) {
    	return (obj == this);
    }
    public int hashCode() { 
    	return toString().hashCode();
    }
    public String toString() { 
    	return _value_;
    }
}
