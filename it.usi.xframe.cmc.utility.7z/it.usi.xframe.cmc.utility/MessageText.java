/**
 * MessageText.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */

package it.usi.xframe.cmc.utility;

import java.io.Serializable;

public class MessageText implements Serializable {

	private static final long serialVersionUID = -5773308658422510768L;
	private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    private transient ThreadLocal __history;
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj.getClass() != this.getClass()) { return false;}
        MessageText other = (MessageText) obj;
        boolean _equals;
        _equals = true
            && ((this.text==null && other.getText()==null) || 
             (this.text!=null &&
              this.text.equals(other.getText())));
        if (!_equals) { return false; }
        if (__history == null) {
            synchronized (this) {
                if (__history == null) {
                    __history = new ThreadLocal();
                }
            }
        }
        MessageText history = (MessageText) __history.get();
        if (history != null) { return (history == obj); }
        if (this == obj) return true;
        __history.set(obj);
        __history.set(null);
        return true;
    }

    private transient ThreadLocal __hashHistory;
    public int hashCode() {
        if (__hashHistory == null) {
            synchronized (this) {
                if (__hashHistory == null) {
                    __hashHistory = new ThreadLocal();
                }
            }
        }
        MessageText history = (MessageText) __hashHistory.get();
        if (history != null) { return 0; }
        __hashHistory.set(this);
        int _hashCode = 1;
        if (getText() != null) {
            _hashCode += getText().hashCode();
        }
        __hashHistory.set(null);
        return _hashCode;
    }

}
