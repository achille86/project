/**
 * ErrorMessage.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */

package it.usi.xframe.cmc.utility;

import java.io.Serializable;

public class ErrorMessage  extends AbstractMessage  implements Serializable {

	private static final long serialVersionUID = 7554170674671335241L;
	private MessageLevelError messageLevel;

    public MessageLevelError getMessageLevel() {
        return messageLevel;
    }

    public void setMessageLevel(MessageLevelError messageLevel) {
        this.messageLevel = messageLevel;
    }

    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj.getClass() != this.getClass()) { return false;}
        if (!super.equals(obj)) { return false; }
        ErrorMessage other = (ErrorMessage) obj;
        boolean _equals;
        _equals = true
            && ((this.messageLevel==null && other.getMessageLevel()==null) || 
             (this.messageLevel!=null &&
              this.messageLevel.equals(other.getMessageLevel())));
        if (!_equals) {
            return false;
        };
        return true;
    }

    public int hashCode() {
        int _hashCode = super.hashCode();
        if (getMessageLevel() != null) {
            _hashCode += getMessageLevel().hashCode();
        }
        return _hashCode;
    }

}
