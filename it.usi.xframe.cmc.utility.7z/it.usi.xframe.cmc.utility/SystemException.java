/**
 * SystemException.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf190823.02 v62608112801
 */

package it.usi.xframe.cmc.utility;

import java.io.Serializable;

public class SystemException extends Exception implements Serializable {

	private static final long serialVersionUID = -292735960463803320L;
	private String correlationId;
    private String customerErrorCode;
    private ErrorMessageList messageList;

    public SystemException(String correlationId, String customerErrorCode, ErrorMessageList messageList) {
        this.correlationId = correlationId;
        this.customerErrorCode = customerErrorCode;
        this.messageList = messageList;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public String getCustomerErrorCode() {
        return customerErrorCode;
    }

    public ErrorMessageList getMessageList() {
        return messageList;
    }

    private transient ThreadLocal __history;
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj.getClass() != this.getClass()) { return false;}
        SystemException other = (SystemException) obj;
        boolean _equals;
        _equals = true
            && ((this.correlationId==null && other.getCorrelationId()==null) || 
             (this.correlationId!=null &&
              this.correlationId.equals(other.getCorrelationId())))
            && ((this.customerErrorCode==null && other.getCustomerErrorCode()==null) || 
             (this.customerErrorCode!=null &&
              this.customerErrorCode.equals(other.getCustomerErrorCode())));
        if (!_equals) { return false; }
        if (__history == null) {
            synchronized (this) {
                if (__history == null) {
                    __history = new ThreadLocal();
                }
            }
        }
        SystemException history = (SystemException) __history.get();
        if (history != null) { return (history == obj); }
        if (this == obj) return true;
        __history.set(obj);
        _equals = true
            && ((this.messageList==null && other.getMessageList()==null) || 
             (this.messageList!=null &&
              this.messageList.equals(other.getMessageList())));
        if (!_equals) {
            __history.set(null);
            return false;
        };
        __history.set(null);
        return true;
    }

    private transient ThreadLocal __hashHistory;
    public int hashCode() {
        if (__hashHistory == null) {
            synchronized (this) {
                if (__hashHistory == null) {
                    __hashHistory = new ThreadLocal();
                }
            }
        }
        SystemException history = (SystemException) __hashHistory.get();
        if (history != null) { return 0; }
        __hashHistory.set(this);
        int _hashCode = 1;
        if (getCorrelationId() != null) {
            _hashCode += getCorrelationId().hashCode();
        }
        if (getCustomerErrorCode() != null) {
            _hashCode += getCustomerErrorCode().hashCode();
        }
        if (getMessageList() != null) {
            _hashCode += getMessageList().hashCode();
        }
        __hashHistory.set(null);
        return _hashCode;
    }

}
