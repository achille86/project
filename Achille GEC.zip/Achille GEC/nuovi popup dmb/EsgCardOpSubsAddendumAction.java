package it.usi.xframe.gec.pfstruts.actions.eurosig.cardOperations;

import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import eu.unicredit.xframe.dsi.ws.basket.CallbackParameter;
import eu.unicredit.xframe.dsi.ws.basket.Customer;
import eu.unicredit.xframe.dsi.ws.basket.DocumentParameter;
import eu.unicredit.xframe.dsi.ws.basket.DossierData;
import eu.unicredit.xframe.dsi.ws.basket.DossierDocument;
import eu.unicredit.xframe.dsi.ws.basket.DossierDocumentInput;
import eu.unicredit.xframe.dsi.ws.basket.DossierDocumentOutput;
import eu.unicredit.xframe.dsi.ws.basket.DossierInput;
import eu.unicredit.xframe.dsi.ws.basket.DossierOutput;
import eu.unicredit.xframe.dsi.ws.basket.DossierParameter;
import eu.unicredit.xframe.dsi.ws.basket.FieldType;
import eu.unicredit.xframe.dsi.ws.basket.ProcessInfo;
import eu.unicredit.xframe.dsi.ws.basket.ProcessParams;
import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpGeneralRequestInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpNdgConnectedRequestInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOperationsResponseClass;
import it.usi.xframe.gec.bfutil.general.GecConstants;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.pfstruts.forms.eurosig.cardInquiry.EsgCardInquiryActionForm;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.gec.pfstruts.utilities.GecWebUtilities;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.FormatUtils;
import it.usi.xframe.utl.bfutil.GaussResponse;
import it.usi.xframe.utl.bfutil.HostResponseMessage;
import it.usi.xframe.utl.bfutil.Utl;
import it.usi.xframe.utl.bfutil.XlcConstantTag;
import it.usi.xframe.xpi.bfutil.Signer;
import it.usi.xframe.xpi.bfutil.XPrintUtilities;

public class EsgCardOpSubsAddendumAction extends EsgCardOperationsGeneralAction {

	private static final Log logger = LogFactory.getLog(EsgCardOpSubsAddendumAction.class);
	
	private static final String ISSUE_FUNCTION = "Emissione";
	private static final String EXPIRATION_TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	private static final String DMB_REMOTE_CHANNEL = "DMB_REMOTO";
	private static final String GEC_APPLICATION = "GEC";
	
	// Variabili controllo DS2
	private final String DSI_BVI = "N";
	private final String DSI_SELECTSIGNER = "N";
	private final String DSI_SHOWHTML="N";
	private final String DSI_SKIPSMS = "N";
	private final String DSI_FIRMAMIA_AND_SPORTELLO = "N";
	
	// Defaultizza il valore del flag front-end.
	// con FLAG_FE = "0" allora indico che l'origine della chiamata alla SP
	// proviene dal mondo Debito OLD
	//		private final String SP_DEFAULT_FLAG_FE="O";		
		
	/**
	 * recupera i dati relativi alla conferma
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */ 
	public ActionForward subsAddendumInquiry(ActionMapping mapping,
									  ActionForm form,
									  HttpServletRequest request,
									  HttpServletResponse response) throws java.lang.Exception {
		
		logger.debug("*********  [EsgCardOpSubsAddendumAction:subsAddendumInquiry] *******START*****");
		//Metto in request alcuni parametri tipici
		this.setRequestParams(form, request);
		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		//[INIT]Call to inquiry service management
		EsgCardInquiryResponseClass inquiryResponseClass = new EsgCardInquiryResponseClass();

		EsgCardInquiryInOut inquiryInOut = new EsgCardInquiryInOut();
		EsgCardOpGeneralRequestInOut inOut = new EsgCardOpGeneralRequestInOut();
		//Definizione dei parametri di input al servizio
		inquiryInOut = this.retrieveInquiryInput(request, actionForm.getCardInquiryInOut());

		inquiryResponseClass = (EsgCardInquiryResponseClass) this.getInquiryData(inquiryInOut, request);
		
		request.getSession().setAttribute("inquiryInOut", inquiryInOut);
		request.getSession().setAttribute("esgCardOpGeneralRequestInOut", inOut);
		request.getSession().setAttribute("inqResponse", inquiryResponseClass);

		if (this.isGaussResponseError(inquiryResponseClass.getGaussResponse())) { // errore inquiry
			logger.debug("##### [EsgCardOpChangeAuthorizationAction:subsAddendumInquiry] Chiamata servizio Inquiry KO");

			//Gestione del forward e del warning
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, inquiryResponseClass.getGaussResponse());
			complexPopUpParams.setSevereError(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;
		}
		

		logger.debug("#### [EsgCardOpSubsAddendumAction:subsAddendumInquiry] Chiamata al servizio Inquiry OK");
		actionForm.setCardInquiry(inquiryResponseClass.getCardInquiryData());
		actionForm.setVariations(inquiryResponseClass.getVariations());

		inOut.setService(GecConstants.ESG_GR_ADDENDUM);
		inOut.getContractNum().setValue(inquiryInOut.getContractNum().getValue());
		inOut.getCardSeqNumber().setValue(inquiryInOut.getCardSeqNumber().getValue());
		inOut.getNdgCardHolder().setValue(inquiryInOut.getNdgCardHolder().getValue());
		inOut.getCardHolder().setValue(inquiryInOut.getCardHolder().getValue());

		//Beans Directions definitions
		manageInquiryDataDirection(inquiryResponseClass);
		logger.debug("[EsgCardOpSubsAddendumAction:subsAddendumInquiry] Inquiry Service End");
		//[END]Call to inquiry service management Fine della gestione lettura dati di inquiry

		// Call Confirm Service Manager
		EsgCardOperationsResponseClass cardOperationsResponseClass = new EsgCardOperationsResponseClass();

		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			cardOperationsResponseClass = serviceF.esgCardOpGeneralRequestInquiry(inOut);
		} catch (RemoteException e) {
			throw new XFRException(e);
		} finally {
			if(serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		
		if (!this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse())) { // service ok
			actionForm.setGeneralRequestInOut(cardOperationsResponseClass.getGeneralRequestInOut());
			if ("SI".equals(actionForm.getGeneralRequestInOut().getSubsAddendum().getValue())) {
				actionForm.getGeneralRequestInOut().getSubsAddendum().setDirection(XlcConstantTag.OUT);
			}
			this.manageInformationBar(request, "menu.label.subsAddendum.text", actionForm.getCardInquiry());
			
			// Boost input
			if(EsgCountryCode.isItalianCountry()){
//				String type = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountType().getValue(); // es C1 (tipo in Tipo/Sportello/Rapporto)
//				String account = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountNumber().getValue(); // es 0000100094982 (rapporto in Tipo/Sportello/Rapporto)
				String cardType = (String)inquiryResponseClass.getCardInquiryData().getProductData().getProductCode().getValue();  // es MBV VPAY (specie carta)
//				String hierarchyCode = (String)inquiryResponseClass.getCardInquiryData().getProductData().getHierarchyCode().getValue();  // es 01 (gerarchia)

				String developNP = GecUtilities.getGecParameterArea("SMS-OTP-NP","DEVELOP");
				String developND = GecUtilities.getGecParameterArea("SMS-OTP-ND","DEVELOP");
				log.info(">> DEVELOP NP Value >> " + developNP);
				log.info(">> DEVELOP ND Value >> " + developND);

				// Variabile di controllo per esecuzione chiamata DS2
				boolean disableDs2Call = false;

				// Recupera il campo product Type
				String productType = cardType.substring(1, 2);
				
//				if(
//						((developNP != null && developNP.equalsIgnoreCase("Y")) && productType.equalsIgnoreCase("P")) || ((developND != null && developND.equalsIgnoreCase("Y")) && productType.equalsIgnoreCase("D"))
//						&& request.getSession().getAttribute("disableDs2Call")!=null) {
//					String value  	= request.getSession().getAttribute("disableDs2Call").toString();
//					if(value.equals("true")){
//						logger.info("check of DEVELOP values failed");
//						disableDs2Call = true;
//					}
//				}
				if(!GecUtilities.isDigitalMailBoxSet()) {
					logger.info("Digital Mail Box flag set to false");
					disableDs2Call = true;
				}
				
				if(!GecWebUtilities.isPilotBranch(request)){
					logger.info("Pilot branch check failed");
					disableDs2Call = true;
				}
				
				if(!disableDs2Call){
					logger.info("Preparing data for Boost call");
//					String endpointDSI = "https://dsi-uj.collaudo.usinet.it/DSI-EBA-FMW-RS/service-secure/boost/redirect";
					String endpointDSI = GecUtilities.getGecParameterArea("ENDPOINT_URL", "WSDSI");;
					String dsibranch = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountBranch().getValue();
					String dsiBvi = DSI_BVI;
					String dsiCa = GecWebConstants.APPLICATION_CODE;
					String dsiCallBackUrl = getDSICallBackUrl(request) + "/XA-GEC-PF/eurosig/cardOperations/boostCallback.jsp?sessionMarker=" + request.getAttribute("sessionMarker");

					String dsiNdg = "";
					
					// ---
					String ndg = (String)inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg().getValue();
					String productCode = (String)inquiryResponseClass.getCardInquiryData().getProductData().getProductCode().getValue();
					String accountBranch = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountBranch().getValue();
					String accountType = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountType().getValue();
					String accountNumber = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountNumber().getValue();
					String hierarchy = (String)inquiryResponseClass.getCardInquiryData().getProductData().getHierarchyCode().getValue();
					String flagFrontEnd = "N";
					if("03".equalsIgnoreCase(hierarchy)){ // 03 = FAMILIARI
						accountNumber = (String)inquiryInOut.getContractNum().getValue();
					}
					logger.info("subsAddendumInquiry - ndg: " + ndg);
					logger.info("subsAddendumInquiry - productCode: " + productCode);
					logger.info("subsAddendumInquiry - accountBranch: " + accountBranch);
					logger.info("subsAddendumInquiry - accountType: " + accountType);
					logger.info("subsAddendumInquiry - accountNumber: " + accountNumber);
					logger.info("subsAddendumInquiry - hierarchy: " + hierarchy);
					logger.info("subsAddendumInquiry - flagFrontEnd: " + flagFrontEnd);
					String ndgCollResponse = executeSpCardOpNdg(ndg, accountBranch, accountType, accountNumber, productCode, hierarchy, flagFrontEnd);
					logger.info("subsAddendumInquiry - ndgCollResponse: " + ndgCollResponse);
					String ndgResult = ndgCollResponse != null ? ndgCollResponse.trim() : null;
					if(ndgResult==null || ndgResult.equals("")) {
						ndgResult = ndg;
					}
					ndgResult = ndgResult.endsWith(";") ? ndgResult.substring(0,(ndgResult.length()-1)).trim() :ndgResult.trim();
					dsiNdg = ndgResult;
//					String[] ndgColl = ndgResult.split(";");
					// ---
					
					String dsiSelectSigner = DSI_SELECTSIGNER;
					String dsiShowHtml = DSI_SHOWHTML;
					String dsiUserId = GecWebUtilities.getUserCode();
					String dsiSkipSMS = DSI_SKIPSMS;
					String dsiFirmaMiaAndSportello = DSI_FIRMAMIA_AND_SPORTELLO;

					//Carico in request i parametri che verranno utilizzati per BOOST		
					request.setAttribute("endpointDSI", endpointDSI);
					request.setAttribute("branch", dsibranch);
					request.setAttribute("callbackUrl", dsiCallBackUrl);
					request.setAttribute("dsiNdg", dsiNdg);
					request.setAttribute("bvi", dsiBvi);
					request.setAttribute("selectSigner", dsiSelectSigner);
					request.setAttribute("userId", dsiUserId);
					request.setAttribute("skipSMS", dsiSkipSMS);
					request.setAttribute("ca", dsiCa);
					request.setAttribute("showHtml",dsiShowHtml);
					request.setAttribute("dsiFirmaMiaAndSportello", dsiFirmaMiaAndSportello);
					logger.info("subsAddendumInquiry -  Setting request attributes for DSI call");
					logger.info("endpointDSI...................>> " + endpointDSI);
					logger.info("Branch........................>> " + dsibranch);
					logger.info("callBackUrl...................>> " + dsiCallBackUrl);
					logger.info("Ndg...........................>> " + dsiNdg);
					logger.info("Bvi...........................>> " + dsiBvi);
					logger.info("Select Signer.................>> " + dsiSelectSigner);
					logger.info("User id.......................>> " + dsiUserId);
					logger.info("Skip SMS......................>> " + dsiSkipSMS);
					logger.info("Ca............................>> " + dsiCa);
					logger.info("Show HTML.....................>> " + dsiShowHtml);
					logger.info("dsiFirmaMiaAndSportello.......>> " + dsiFirmaMiaAndSportello);
					logger.info("Preparing data for Boost call - END");
				}
				request.setAttribute("disableDs2Call", disableDs2Call ? "true" : "false");
			}
		}

		String urlAfterError = this.urlAfterRetrieveError(request);
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, cardOperationsResponseClass.getGaussResponse());
		complexPopUpParams.setActionBackError(urlAfterError);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_OP_SUBS_ADDENDUM);
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.debug("*********  [EsgCardOpSubsAddendumAction:subsAddendumInquiry] *******END*****");

		return forward;
	}
	
	
	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward subsAddendumUpdate(ActionMapping mapping,
										   ActionForm form,
										   HttpServletRequest request,
										   HttpServletResponse response) throws java.lang.Exception {

		logger.debug("[EsgCardOpSubsAddendumAction:subsAddendumUpdate] *******START*****");

		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		EsgCardOperationsResponseClass classReturn = new EsgCardOperationsResponseClass();
		EsgCardOpGeneralRequestInOut inOut = new EsgCardOpGeneralRequestInOut();

		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		inOut = actionForm.getGeneralRequestInOut();
		inOut.setService(GecConstants.ESG_GR_ADDENDUM);
		
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			classReturn = serviceF.esgCardOpGeneralRequestUpdate(inOut);
		} catch (RemoteException e) {
			throw new XFRException(e);
		} finally {
			if(serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}

		String urlServiceCallOK = "";
		String urlServiceCallKO = "";
		
		if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
			urlServiceCallKO = this.urlAfterUpdateError(request);
			logger.debug("********* Update  ERRORE  ************" + urlServiceCallKO);
		} else {
			urlServiceCallOK = this.urlAfterUpdateSuccess(request);
			logger.debug("********* Update  MESSAGGIO  ************" + urlServiceCallOK);
			
			// gestione stampe automatiche
			this.managePrintInformation(request, classReturn.getPrintManager());
		}
		
		logger.info("EsgCardOpSubsAddendumAction.subsAddendumUpdate - boostProcessOK = " + request.getParameter("boostProcessOK"));
		boolean boostProcessOK = "false".equalsIgnoreCase(request.getParameter("boostProcessOK")) ? false : true;
		
		if(!this.isGaussResponseError(classReturn.getGaussResponse()) && !boostProcessOK){
			logger.info("EsgCardOpSubsAddendumAction.subsAddendumUpdate - boostProcessOK is false: setting up toPaper popup");
			GaussResponse gaussResponse = new GaussResponse();
			gaussResponse.setWarningFlag(true);
			
			HostResponseMessage[] newMessage = new HostResponseMessage[1];
			HostResponseMessage toPaperMsgCode = new HostResponseMessage();
			toPaperMsgCode.setMessage("GEC01526");
			newMessage[0] = toPaperMsgCode;
			gaussResponse.setFlagCode("W");
			gaussResponse.setHostResponseMessage(newMessage);
			//FINE MESSAGGIO PER SOLUZIONE NON DMB
			
			String context = GecWebUtilities.getRequestParameter(request, "context");
			String fwd = "";
			if("BF".equalsIgnoreCase(context)){
				fwd = "esgCardOpInquiry";
			} else {
				fwd = "esgCardAccess";
			}
			
			
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, gaussResponse);
			complexPopUpParams.setForward(fwd);
			forward = Utl.createComplexPopUp(complexPopUpParams);
		} else {
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
			complexPopUpParams.setActionBackError(urlServiceCallKO);
			complexPopUpParams.setReturnBackError(true);
			complexPopUpParams.setActionBackMessage(urlServiceCallOK);
			complexPopUpParams.setReturnBackMessage(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
		}
		
		return forward;
	}
	
	/**
	 * Method to handle the Digital Mail Box procedure. Called from javascript at the end of the Boost process.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward callAddendumBMUpdate(ActionMapping mapping,
										   ActionForm form,
										   HttpServletRequest request,
										   HttpServletResponse response) throws java.lang.Exception {
		
		logger.debug("[EsgCardOpSubsAddendumAction:callAddendumBMUpdate] *******START*****");
		EsgCardInquiryInOut inquiryInOut = (EsgCardInquiryInOut) request.getSession().getAttribute("inquiryInOut");
		EsgCardOpGeneralRequestInOut inOut = (EsgCardOpGeneralRequestInOut)request.getSession().getAttribute("esgCardOpGeneralRequestInOut");
		EsgCardInquiryResponseClass inquiryResponseClass = (EsgCardInquiryResponseClass) request.getSession().getAttribute("inqResponse");
		
		String boostResult = request.getParameter("boostResult");
		String error = request.getParameter("error");
		
		// clean boost call data
		request.removeAttribute("endpointDSI");
		request.removeAttribute("branch");
		request.removeAttribute("callbackUrl");
		request.removeAttribute("dsiNdg");
		request.removeAttribute("bvi");
		request.removeAttribute("selectSigner");
		request.removeAttribute("userId");
		request.removeAttribute("skipSMS");
		request.removeAttribute("ca");
		request.removeAttribute("showHtml");
		request.removeAttribute("dsiFirmaMiaAndSportello");
				
		// Boost result verification
		boolean boostProcessOK = true;
		if(error != null && !"".equals(error.trim())) {
			logger.info("Error from Boost in the error parameter: " + error);
			boostProcessOK = false;
		}
		boolean digitalCompliant = true;
		if(!GecWebUtilities.isDigitalCompliant(boostResult)) {
			logger.info("NDG is not Digital Compliant: " + boostResult);
			digitalCompliant = false;
		}

		if(!boostProcessOK){
			// BOOST ERROR
			logger.info("PROSEGUIMENTO AS-IS a causa di errore nell'output di BOOST o validazione del risultato di BOOST");
			logger.info("error from Boost url parameter: " + error + "; boostResult: " + boostResult);
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, form, request);
		}
		
		if(!digitalCompliant){
			logger.info("Errore nei flag (tablet scollegato o cliente non evoluto), mostro messaggio di errore");
			GaussResponse gaussResponse = new GaussResponse();
			gaussResponse.setErrorFlag(true);
			
			HostResponseMessage[] newMessage = new HostResponseMessage[2];
			HostResponseMessage customerNotDigitalMsgCode = new HostResponseMessage();
			customerNotDigitalMsgCode.setMessage("GEC0000");
			newMessage[0] = customerNotDigitalMsgCode;
			HostResponseMessage customerNotDigitalMsg = new HostResponseMessage();
			customerNotDigitalMsg.setMessage("Contratto non emesso a causa di tablet scollegato o cliente non evoluto.");
			newMessage[1] = customerNotDigitalMsg;
			gaussResponse.setFlagCode("E");
			gaussResponse.setHostResponseMessage(newMessage);
			
			String context = GecWebUtilities.getRequestParameter(request, "context");
			String fwd = "";
			if("BF".equalsIgnoreCase(context)){
				fwd = "esgCardOpInquiry";
			} else {
				fwd = "esgCardAccess";
			}
			
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, gaussResponse);
			complexPopUpParams.setActionBackError(this.urlAfterUpdateSuccess(request)); // back to initial page after showing error message from transaction
			complexPopUpParams.setReturnBackError(true);
			ActionForward forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;
		}
		
		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		
		//####################### INIZIO CHIAMATA OPEN DOSSIER BASKET MANAGER #######################

		UserData userInfo = GecWebUtilities.getUserData(request);
		String sequence = "";
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;
		try {
			service = serviceFactory.getGecServiceFacade();
			sequence = service.retrieveSequenceBM();
		} catch (Exception e) {
			logger.error("[EsgCardOpSubsAddendumAction - callAddendumBMInquiry - retrieveSequence] Error: ", e);
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, form, request);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		String correlationId = 	GEC_APPLICATION + 
				FormatUtils.formatNumber((String)userInfo.getFilialeOperatore(), 5, 0, "N") +
				FormatUtils.formatNumber((String)inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg().getValue(), 15, 0, "N") +//FormatUtils.formatNumber((String)inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg().getValue(), 15, 0, "N") +
				sequence; //sequence (progr)
		String name = GecUtilities.getGecParameterArea("BU1758", "DIGITAMB");
		String classification = "Monetica Post Vendita";
		logger.info("correlationId for BM: " + correlationId);
		Date endOfDayDate = GecWebUtilities.getEndOfDayDate(new Date());
		Date plusThirtyDaysDate = GecWebUtilities.getPlusThirtyDaysDate(new Date());
		Date midDayTestDate = GecWebUtilities.getMidDayTestDate(new Date());
		DateFormat df = new SimpleDateFormat(EXPIRATION_TIMESTAMP_FORMAT);
		String expirationTimeStamp = df.format(plusThirtyDaysDate);
		logger.info("expirationTimeStamp for BM: [" + expirationTimeStamp + "] ");
		DossierInput input = new DossierInput();
		ProcessInfo processInfo = new ProcessInfo();
		processInfo.setApplication(GEC_APPLICATION);
		processInfo.setBranch(userInfo.getFilialeOperatore());
		processInfo.setChannel(DMB_REMOTE_CHANNEL);
		processInfo.setUserId(userInfo.getCodOperatore());
		DossierData dossierData = new DossierData();
		dossierData.setCorrelationId(correlationId);
		String dossierBusinessKey = "DMBSTOCK" + correlationId;
		dossierData.setBusinessKey(dossierBusinessKey);
		dossierData.setName(name);
		dossierData.setClassification(classification);
		DossierParameter dossierParameter = new DossierParameter();
		dossierParameter.setExpirationTimestamp(expirationTimeStamp);
		dossierData.setParameter(dossierParameter);
		input.setProcessInfo(processInfo);
		input.setDossierData(dossierData);
		input.setProcessParams(new ProcessParams());

		//PRINT INPUT START
		Class inputClass = DossierInput.class;
		Object inputObj = input;
		GecWebUtilities.printIOObject(inputClass, inputObj);
		//PRINT INPUT END

		String dossierId = "";
		DossierOutput outputWS = null;
		try {
			service = serviceFactory.getGecServiceFacade();
			outputWS = service.openDossier(input);
		} catch (Exception e) {
			logger.error("[EsgCardOpSubsAddendumAction:callAddendumBMUpdate WS BasketDossier open] Error: ", e);
			logger.info("PROSEGUIMENTO AS-IS a causa di errore durante chiamata Open al servizio di Basket Manager");
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, form, request);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		
		if(outputWS == null || !"0".equals(outputWS.getOutcome().getCode())) { // KO OPEN BASKET MANAGER
			logger.info("[EsgCardOpSubsAddendumAction:callAddendumBMUpdate] BasketDossier Open - End with KO");
			//PRINT INPUT START
			Class outputClass = DossierOutput.class;
			Object outputObj = outputWS;
			GecWebUtilities.printIOObject(outputClass, outputObj);
			//PRINT INPUT END

			logger.info("PROSEGUIMENTO AS-IS a causa di KO dal servizio Basket Manager in chiamata alla Open");
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, form, request);
		}
		
		//####################### FINE CHIAMATA OPEN DOSSIER BASKET MANAGER #######################
		logger.info("[EsgCardOpSubsAddendumAction:callAddendumBMUpdate] BasketDossier Open - End with success");
		
		//PRINT INPUT START
		Class outputClass = DossierOutput.class;
		Object outputObj = outputWS;
		GecWebUtilities.printIOObject(outputClass, outputObj);
		//PRINT INPUT END
		
		// retireving dossierId from service output
		dossierId = outputWS.getDossierId();

		// setting data to call GECKTV36 in UPDATE
		inOut.getContractNum().setValue(inquiryInOut.getContractNum().getValue());
		inOut.getCardSeqNumber().setValue(inquiryInOut.getCardSeqNumber().getValue());
		inOut.getNdgCardHolder().setValue(inquiryInOut.getNdgCardHolder().getValue());
		inOut.getCardHolder().setValue(inquiryInOut.getCardHolder().getValue());
		inOut.setService(GecConstants.ESG_GR_ADDENDUM_BM);
		inOut.setDossier(dossierId);
		inOut.setCorrelationId(correlationId);
		inOut.setDocumentId("");
		inOut.setSubDossier(""); // leave this empty at this moment cause there isn't a subDossier right now
		inOut.setExpirationTimestamp(""); // leave this empty at this moment cause there isn't a subDossier right now
		inOut.setFunction(ISSUE_FUNCTION);
		
		EsgCardOperationsResponseClass classReturn = new EsgCardOperationsResponseClass();
		serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		// GECKTV36 in UPDATE
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			classReturn = serviceF.esgCardOpAddendumBMRequestUpdate(inOut);
		} catch (Exception e) {
			logger.error("[EsgCardOpSubsAddendumAction - callAddendumBMUpdate] Error: ", e);
			logger.info("PROSEGUIMENTO AS-IS a causa di errore nella chiamata a GECKTV36 in UPDATE");
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, form, request);
		} finally {
			if(serviceF != null && serviceFactory != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		
		if (!this.isGaussResponseError(classReturn.getGaussResponse())) {
			logger.info("[EsgCardOpSubsAddendumAction:callAddendumBMUpdate] GECKTV36 response successfully - begin operations on data before calling Basket Manager web service Add");
			try {
				// preliminary operation before Basket Manager Add
				classReturn.setPrintDoc(classReturn.getBmDoc()); // it is necessary to copy this array in the second property to avoid NullPointerException in the code below
				String originalModuleList = XPrintUtilities.createModuleListXMLFromXDocument(classReturn.getPrintDoc());
				logger.info("ORIGINAL MODULELIST: " + originalModuleList);
				
				String ndg = (String)inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg().getValue();
				String hierarchy = (String)inquiryResponseClass.getCardInquiryData().getProductData().getHierarchyCode().getValue();
				boolean famCard = "03".equalsIgnoreCase(hierarchy);
				String productCode = (String)inquiryResponseClass.getCardInquiryData().getProductData().getProductCode().getValue();
				String accountBranch = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountBranch().getValue();
				String accountType = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountType().getValue();
				String accountNumber = (String)inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountNumber().getValue();
				String flagFrontEnd = "N";
				if(famCard){ // 03 = FAMILIARI
					accountNumber = (String)inquiryInOut.getContractNum().getValue();
				}
				logger.info("callAddendumBMUpdate - ndg: " + ndg);
				logger.info("callAddendumBMUpdate - productCode: " + productCode);
				logger.info("callAddendumBMUpdate - accountBranch: " + accountBranch);
				logger.info("callAddendumBMUpdate - accountType: " + accountType);
				logger.info("callAddendumBMUpdate - accountNumber: " + accountNumber);
				logger.info("callAddendumBMUpdate - hierarchy: " + hierarchy);
				logger.info("callAddendumBMUpdate - flagFrontEnd: " + flagFrontEnd);
				String ndgCollResponse = executeSpCardOpNdg(ndg, accountBranch, accountType, accountNumber, productCode, hierarchy, flagFrontEnd);
				logger.info("callAddendumBMUpdate - ndgCollResponse: " + flagFrontEnd);
				String ndgResult = ndgCollResponse != null ? ndgCollResponse.trim() : null;
				if(ndgResult==null || ndgResult.equals("")) {
					ndgResult = ndg;
				}
				ndgResult = ndgResult.endsWith(";") ? ndgResult.substring(0,(ndgResult.length()-1)).trim() :ndgResult.trim();
				String[] ndgColl = ndgResult.split(";");
				
				if(famCard){
					if(ndgColl.length == 2){
						String[] ndgCollReversed = new String[ndgColl.length];
						ndgCollReversed[0] = ndgColl[1];
						ndgCollReversed[1] = ndgColl[0];
						ndgColl = ndgCollReversed;
					}
				}

				for (int i = 0; i < classReturn.getPrintDoc().length; i++) {
					logger.info("EsgCardOpSubsAddendumAction.callAddendumBMUpdate classReturn.getPrintDoc().length = " + classReturn.getPrintDoc().length);
					classReturn.getPrintDoc()[i].setDigitalSigns("".toCharArray());
					if(ndgColl.length > 1){
						if(!famCard){
							classReturn.getPrintDoc()[i].addPrintVar("SYS_COINT", ndg);
						}
						ArrayList signersArray = new ArrayList();
						for (int j = 0; j < ndgColl.length; j++) {
							Signer signer = new Signer();
							signer.setNdg(ndgColl[j]);
							signersArray.add(signer);
							logger.info("callAddendumBMUpdate - adding Signer " + (j + 1) + " to doc #" + i + ": " + ndgColl[j]);
							
							classReturn.getPrintDoc()[i].addPrintVar("SYS_SIGNER_" + (j + 1), ndgColl[j]);
							logger.info("callAddendumBMUpdate - adding SYS_SIGNER_" + (j + 1) + " to doc #" + i + ": " + ndgColl[j]);
						}
						classReturn.getPrintDoc()[i].setSigners(signersArray);
						classReturn.getPrintDoc()[i].setSignersFromCallingApp(true);
						
					}

					if(classReturn.getPrintDoc()[i].getDocID() == null || "".equalsIgnoreCase(classReturn.getPrintDoc()[i].getDocID())){
						classReturn.getPrintDoc()[i].setDocID("module"+i);
					}
				}
				String modifiedModuleList = XPrintUtilities.createModuleListXMLFromXDocument(classReturn.getPrintDoc());
				modifiedModuleList = removeDataRif(modifiedModuleList);
				String wrappedModuleList = "<![CDATA[" + modifiedModuleList + "]]>";
				logger.info("FINAL MODULELIST: " + wrappedModuleList);
				classReturn.setModuleList(wrappedModuleList);

				//####################### INIZIO CHIAMATA ADD DOSSIER BASKET MANAGER #######################

				
				String dossierExpirationTimeStamp = df.format(plusThirtyDaysDate); 
				logger.info("dossierExpirationTimeStamp for BM: [" + dossierExpirationTimeStamp + "] ");
				String documentExpirationTimeStamp = df.format(endOfDayDate); 
				logger.info("documentExpirationTimeStamp for BM: [" + documentExpirationTimeStamp + "] ");

				DossierDocumentInput inputDocument = new DossierDocumentInput();

				DossierData masterDossier = new DossierData();
				masterDossier.setCorrelationId(correlationId);
				masterDossier.setDossierId(dossierId);

				DossierData[] subDossierList = new DossierData[1];

				DossierData subDossier = new DossierData();
				subDossier.setName(name); // using same name as open call
				subDossier.setClassification(classification); // using same classification as open call
				subDossier.setCorrelationId(correlationId); // using same correlationId as open call
				FieldType[] subDossierAttributes = new FieldType[1];
				FieldType pushNotificationAttribute = new FieldType();
				pushNotificationAttribute.setName("sendAddDossierPushNotification");
				pushNotificationAttribute.setValue("Y");
				subDossierAttributes[0] = pushNotificationAttribute;
				subDossier.setAttribute(subDossierAttributes);
				CallbackParameter callback = new CallbackParameter();
				callback.setType("SOAP");
				callback.setEndpoint(GecUtilities.getGecParameterArea("CALLBACKURL", "DMB"));
				subDossier.setCallback(callback);
				
				// ---
				
				Customer[] customersList = new Customer[ndgColl.length];
				for (int i = 0; i < customersList.length; i++) {
					Customer subDossierCustomer = new Customer();
					String customerNdg = ndgColl[i];
					it.usi.xframe.afa.bfutil.Customer afaCustomer = GecWebUtilities.retrieveAfaCustomer(request, null, null, customerNdg);
					String customerNdgType = afaCustomer.getNdgType().getCode();
					String customerName = afaCustomer.getCompleteHeading();
					subDossierCustomer.setNdg(customerNdg);
					subDossierCustomer.setType(customerNdgType);
					subDossierCustomer.setName(customerName);
					subDossierCustomer.setSigner("Y");
					customersList[i] = subDossierCustomer;
					logger.info("callAddendumBMUpdate - Customer #" + i + " set. NDG: " + customerNdg + " TYPE: " + customerNdgType);
				}
				
				// ---
				
				/*Customer subDossierCustomer = new Customer();
				subDossierCustomer.setNdg(classReturn.getBmDoc()[0].getNdg());

				// retrieve ndgType from AFA
				it.usi.xframe.afa.bfutil.Customer c = GecWebUtilities.retrieveAfaCustomer(request, null, null, classReturn.getBmDoc()[0].getNdg());
				String ndgType =  c.getNdgType().getCode();
				classReturn.getBmDoc()[0].setNdgType(ndgType); // must be used in another field in the code below

				subDossierCustomer.setType(classReturn.getBmDoc()[0].getNdgType());
				Customer[] subDossierCustomers = new Customer[1];
				subDossierCustomers[0] = subDossierCustomer;
				subDossier.setCustomers(subDossierCustomers);*/
				subDossier.setCustomers(customersList);

				DossierParameter subDossierParameter = new DossierParameter();
				subDossierParameter.setExpirationTimestamp(dossierExpirationTimeStamp);
				subDossier.setParameter(subDossierParameter);
				
//				// this attribute was required to specify that it's necessary to receive callback notifications only in case of Dossier expiration
//				FieldType[] subDossierAttributes = new FieldType[1];
//				FieldType subscribingEventTypeDossierExpired = new FieldType();
//				subscribingEventTypeDossierExpired.setName("subscribingEventType");
//				subscribingEventTypeDossierExpired.setValue("DOSSIER_EXPIRED");
//				subDossierAttributes[0] = subscribingEventTypeDossierExpired;
//				subDossier.setAttribute(subDossierAttributes);

				DossierDocument[] subDossierDocuments = new DossierDocument[classReturn.getBmDoc().length];
				
				logger.info("EsgCardOpSubsAddendumAction.callAddendumBMUpdate subDossierDocuments.length = " + subDossierDocuments.length);

				for (int j = 0; j < classReturn.getBmDoc().length; j++) {
					DossierDocument subDossierDocument = new DossierDocument();
					subDossierDocument.setBusinessKey("doc_externalKey"); // constant
					subDossierDocument.setName(name); // constant
					subDossierDocument.setModuleCode(classReturn.getBmDoc()[j].getFormName()); //another way can be the field docILC of the class BmDoc
					logger.info("EsgCardOpSubsAddendumAction.callAddendumBMUpdate subDossierDocument[" + j + "] moduleCode = " + classReturn.getBmDoc()[j].getFormName());
					subDossierDocument.setModuleId(classReturn.getBmDoc()[j].getDocID());
					logger.info("EsgCardOpSubsAddendumAction.callAddendumBMUpdate subDossierDocument[" + j + "] moduleId = " + classReturn.getBmDoc()[j].getDocID());
					FieldType[] subDossierDocumentAttributes = new FieldType[1];
					FieldType layoutAttribute = new FieldType();
					layoutAttribute.setName("layout");
					layoutAttribute.setValue("1");
					subDossierDocumentAttributes[0] = layoutAttribute;
					subDossierDocument.setAttribute(subDossierDocumentAttributes);
					DocumentParameter subDossierDocumentParameter = new DocumentParameter();
					subDossierDocumentParameter.setExpirationTimestamp(documentExpirationTimeStamp);
					subDossierDocument.setParameter(subDossierDocumentParameter);
					/*Customer subDossierDocumentCustomer = new Customer();
					subDossierDocumentCustomer.setNdg(classReturn.getBmDoc()[j].getNdg());			    
					subDossierDocumentCustomer.setType(classReturn.getBmDoc()[j].getNdgType());
					Customer[] subDossierDocumentCustomers = new Customer[1];
					subDossierDocumentCustomers[0] = subDossierDocumentCustomer;
					subDossierDocument.setCustomers(subDossierDocumentCustomers);*/
					subDossierDocument.setCustomers(customersList);
					subDossierDocuments[j] = subDossierDocument;
				}

				subDossier.setDocument(subDossierDocuments);
				subDossierList[0] = subDossier;
				masterDossier.setDossier(subDossierList);

				inputDocument.setDossierData(masterDossier);
				inputDocument.setProcessInfo(processInfo); // using same ProcessInfo object of the Open call
				inputDocument.setModuleListData(wrappedModuleList);

				//PRINT INPUT START
				inputClass = DossierDocumentInput.class;
				inputObj = inputDocument;
				GecWebUtilities.printIOObject(inputClass, inputObj);
				//PRINT INPUT END

				serviceFactory = GecServiceFactory.getInstance();
				service = null;


				DossierDocumentOutput outputAddWS = null;
				try {
					service = serviceFactory.getGecServiceFacade();
					outputAddWS = service.addDossier(inputDocument);
				} catch (Exception e) {
					logger.error("Basket Manager Add request error: ", e);
					//INIZIO ROLLBACK
					return addendumBMRequestRollback(mapping, request, inOut);
					//FINE ROLLBACK
				}
				if(outputAddWS == null || !"0".equals(outputAddWS.getOutcome().getCode())) { // KO ADD BASKET MANAGER
					logger.info("[EsgCardOpSubsAddendumAction:callAddendumBMUpdate] BasketDossier Add - End with KO");
					//PRINT INPUT START
					outputClass = DossierDocumentOutput.class;
					outputObj = outputAddWS;
					GecWebUtilities.printIOObject(outputClass, outputObj);
					//PRINT INPUT END

					//INIZIO ROLLBACK
					return addendumBMRequestRollback(mapping, request, inOut);
					//FINE ROLLBACK
				} else {
					logger.info("[EsgCardOpSubsAddendumAction:callAddendumBMUpdate] BasketDossier Add - End with success");
					//####################### FINE CHIAMATA ADD DOSSIER BASKET MANAGER #######################

					//PRINT INPUT START
					outputClass = DossierDocumentOutput.class;
					outputObj = outputAddWS;
					GecWebUtilities.printIOObject(outputClass, outputObj);
					//PRINT INPUT END

					//call GECKTV36 in Uptime
					// all input data are as the previous GECKTV36 update call
					inOut.setSubDossier(outputAddWS.getDossier()[0].getDossierId());
					inOut.setExpirationTimestamp(expirationTimeStamp);
					inOut.setDocumentId(outputAddWS.getDossier()[0].getDocuments()[0].getDocumentId());
					// GECKTV36 in UPTIME
					try {
						serviceF = serviceFactory.getGecServiceFacade();
						classReturn = serviceF.esgCardOpAddendumBMRequestUptime(inOut);
					} finally {
						if(serviceF != null && serviceFactory != null) {
							serviceFactory.dispose(serviceF);
						}
					}

					ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
					if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
						logger.debug("error from GECKTV36 in UPTIME");
						complexPopUpParams.setActionBackError(this.urlAfterUpdateSuccess(request)); // back to initial page after showing error message from transaction
						complexPopUpParams.setReturnBackError(true);
					} else {
						logger.debug("success from GECKTV36 in UPTIME");
						complexPopUpParams.setActionBackMessage(this.urlAfterUpdateSuccess(request));
						complexPopUpParams.setReturnBackMessage(true);
					}

					forward = Utl.createComplexPopUp(complexPopUpParams);
					return forward;
				}
			} catch (Exception e) {
				logger.error("[EsgCardOpSubsAddendumAction - WS BasketDossier add] Error: ", e);
				try{
					//INIZIO ROLLBACK
					return addendumBMRequestRollback(mapping, request, inOut);
					//FINE ROLLBACK
				} catch(XFRException ex) {
					logger.error("Exception from rollback: ", ex);
					throw ex;
				}
			} finally {
				if (service != null) {
					serviceFactory.dispose(service);
				}
			}
		} else { // this is the case of GECKTV36 in UPDATE when returns a GaussReponse with KO
		
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
			logger.debug("GECKTV36 errore in UPDATE");
			complexPopUpParams.setActionBackError(this.urlAfterUpdateSuccess(request)); // back to initial page after showing error message from transaction
			complexPopUpParams.setReturnBackError(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;
		}
	}
	
	/**
	 * This method creates a ComplexPopUp in all the scenarios which require to forward to the old GECKRV36 for UPDATE.<br>
	 * Also knows as Print on Paper procedure.
	 * @param mapping
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private ActionForward openComplexPopUpFailureDMBAndContinueToOldUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception{
		//INIZIO MESSAGGIO PER SOLUZIONE NON DMB
		ActionForward oldForward = mapping.findForward(GecWebConstants.ESG_CARD_OP_SUBS_ADDENDUM_UPDATE);
		ActionForward forward = new ActionForward(oldForward);
		forward.setPath(forward.getPath() + "&boostProcessOK=false");
		return forward;
	}
	
	private ActionForward openComplexPopUpFailureDMBCustomer(ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception{
		//INIZIO MESSAGGIO PER SOLUZIONE NON DMB
		ActionForward oldForward = mapping.findForward(GecWebConstants.ESG_CARD_OP_SUBS_ADDENDUM_UPDATE);
		ActionForward forward = new ActionForward(oldForward);
		forward.setPath(forward.getPath() + "&boostProcessOK=true&digitalCompliant=false");
		return forward;
	}
	
	private ActionForward addendumBMRequestRollback(ActionMapping mapping, HttpServletRequest request, EsgCardOpGeneralRequestInOut inOut) throws XFRException {
		logger.info("Rollback procedure begin");
		GecServiceFactory serviceFactory = null;
		IGecServiceFacade serviceF = null;
		try {
			serviceFactory = GecServiceFactory.getInstance();
			serviceF = serviceFactory.getGecServiceFacade();
			logger.info("Interruzione della procedura con messaggio di successo dalla transazione GECKTV36 in rollback");
			EsgCardOperationsResponseClass classReturn = serviceF.esgCardOpAddendumBMRequestRollback(inOut);
			
			String urlToEsgCardAccessPreInquiry = this.urlAfterUpdateSuccess(request);
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
			
			if (!this.isGaussResponseError(classReturn.getGaussResponse())) {
				logger.info("Interrupting process with success message from GECKTV36 transaction in rollback mode");
			} else {
				logger.info("Interrupting process with error message from GECKTV36 transaction in rollback mode");
				complexPopUpParams.setSevereError(true);
			}
			// in all the two above scenarios the user will be redirected on the EsgCardAccess page
			complexPopUpParams.setActionBackError(urlToEsgCardAccessPreInquiry);
			complexPopUpParams.setReturnBackError(true);
			complexPopUpParams.setActionBackMessage(urlToEsgCardAccessPreInquiry);
			complexPopUpParams.setReturnBackMessage(true);
			logger.info("Rollback procedure end");
			return Utl.createComplexPopUp(complexPopUpParams);// back to initial page after showing error message from transaction
		}catch(Exception e){
			logger.error("Error during GECKTV36 in rollback");
			throw new XFRException(e);
		} finally {
			if(serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}
	}
	
	/**
	 * EE47373 - A.P.
	 * Esegue la chiamata alla SP
	 * su CardIssueAction.cardIssueConrif()
	 * @param ndg
	 * @param accountBranch
	 * @param accountType
	 * @param accountNumber
	 * @param productCode
	 * @param hierarchy
	 * @param flagFrontEnd
	 * @return String
	 * @throws Exception
	 */
	private String executeSpCardOpNdg(String ndg,
									  String accountBranch,
									  String accountType,
									  String accountNumber,
									  String productCode,
									  String hierarchy,
									  String flagFrontEnd)throws Exception{
		
		logger.info("[EsgCardOpSubsAddendumAction - executeSpCardOpNdg] --- start ---");
		
		// variabile di controllo
		String ret = null;
		
		// Ottiene una istanza valida della Service Factory
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
		
		try{
			
			if(ndg!=null && !ndg.equalsIgnoreCase("") &&
					accountBranch!=null && !accountBranch.equalsIgnoreCase("") && 
						accountType!=null && !accountType.equalsIgnoreCase("") &&
							accountNumber!=null && !accountNumber.equalsIgnoreCase(""))
			{
				// Eseguo creazione dell'Oggetto per chiamata a Store Procedure
				
				EsgCardOpNdgConnectedRequestInOut ndgConRequestIn = new EsgCardOpNdgConnectedRequestInOut();
				ndgConRequestIn.getIn_ndg().setValue(ndg);
				ndgConRequestIn.getIn_dipCC().setValue(accountBranch);
				ndgConRequestIn.getIn_tipoRap().setValue(accountType);
				ndgConRequestIn.getIn_numCC().setValue(accountNumber);
				ndgConRequestIn.getIn_codProdotto().setValue(productCode); 
				ndgConRequestIn.getIn_flFrontEnd().setValue(flagFrontEnd);
				ndgConRequestIn.getIn_codGerarchia().setValue(hierarchy);
				
				logger.info("Request SP with follow parameters:");
				logger.info("NDG >>..............." + ndg);
				logger.info("Account branch >>...." + accountBranch);
				logger.info("Account type >>......" + accountType);
				logger.info("Account number >>...." + accountNumber);		
				logger.info("Product code >>......" + productCode);
				logger.info("Hierarchy >>........." + hierarchy);
				logger.info("Flg Front-End >>....." + flagFrontEnd);
				
				// chiamata al servizio
				EsgCardOpNdgConnectedRequestInOut result = new EsgCardOpNdgConnectedRequestInOut();
				ndgConRequestIn.debug(); // display prima della chiamata al servizio
												
				result = serviceF.retriveNdgConnectedRequestInfo(ndgConRequestIn);
				
				// Verifico il risultato della SP.
				// e Creo un array di stringhe contenente gli NDG estratti dalla SP
				if(result!=null){
					
					ret = result.getOut_NdgColl()!=null ?  result.getOut_NdgColl().getValue().toString() :"";					
				}							
			}
			else{
				
				logger.error("Error during executeSpCardOpNdg. Error, parameters not found or not set");
			}
		}
		catch(Exception ex){
			
			// Sollevo eccesione
			logger.error(ex.getLocalizedMessage());
			throw ex;
		}
		finally{
			
			// Eseguo il dispose della risorsa transazionale verso Host
			serviceFactory.dispose(serviceF);
		}
		
		logger.info("[EsgCardOpSubsAddendumAction - executeSpCardOpNdg] --- end ---");
		
		return ret;
	}
	
	/**
	 * Compone la URL di Call Back
	 * @param request
	 * @return String
	 */
	private String getDSICallBackUrl(HttpServletRequest request){
		StringBuffer reqURL = request.getRequestURL();
		String contextPath = request.getContextPath();
		int endUrlServer = reqURL.indexOf(contextPath);
		String urlServer = reqURL.substring(0, endUrlServer); 
		
		// Visualizza la URL del server che verr� utilizzata come call back
		log.debug("Call Back Url >> " + urlServer);
		
		return urlServer;
	}
	
	private String removeDataRif(String moduleListXml){
		String modifiedModuleList = moduleListXml;
		int startIndex = moduleListXml.indexOf("name=\"data_rif");
		if(startIndex != -1){
			int endIndex = moduleListXml.indexOf("</param>", startIndex) + "</param>".length();
			String substrToReplace = moduleListXml.substring(startIndex, endIndex);
			modifiedModuleList = StringUtils.replace(modifiedModuleList, substrToReplace, "name=\"data_rif\"/>");
		}
		return modifiedModuleList;
	}
	
}

