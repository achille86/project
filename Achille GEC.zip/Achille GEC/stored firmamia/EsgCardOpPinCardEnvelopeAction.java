/*
 * Created on Feb 09, 2012
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package it.usi.xframe.gec.pfstruts.actions.eurosig.cardOperations;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckInput;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOutput;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpRequestDeliveryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOperationsResponseClass;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.pfstruts.forms.eurosig.cardInquiry.EsgCardInquiryActionForm;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.gec.pfstruts.utilities.GecWebUtilities;
import it.usi.xframe.ifg.bfutil.IfgServiceFactory;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.Utl;

/**
 * @author US02059-GAUSS
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class EsgCardOpPinCardEnvelopeAction extends EsgCardOperationsGeneralAction {

	private Log logger = LogFactory.getLog(this.getClass());
	
	
	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward pinCardEnvelopeGetData(ActionMapping mapping,
									  ActionForm form,
									  HttpServletRequest request,
									  HttpServletResponse response)throws java.lang.Exception {

		logger.debug("[EsgCardOpPinCardEnvelopeAction: pinCardEnvelopeGetData] *******START GAUSS*********");

		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;
		String urlAfterError = "";

		//Metto in request alcuni parametri tipici
		this.setRequestParams(form, request);
		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		//debug parametri in request
		GecWebUtilities.debugRequest(request);
		
		//EE29052 - FirmaMia - XPI tablet check
		GecUtilities.setSignpadVerifyURL(request);
		//EE29052 - FirmaMia - END

		//[INIT]Chiamata alla inquiry service management
		EsgCardInquiryResponseClass inquiryResponseClass = new EsgCardInquiryResponseClass();
		EsgCardOpRequestDeliveryInOut paramsIn = new EsgCardOpRequestDeliveryInOut();
		//Definizione dei parametri di input al servizio
		paramsIn.getContractNum().setValue(request.getAttribute("contractNumber"));
		paramsIn.getCardSeqNumber().setValue(request.getAttribute("cardSeqNumber"));
		paramsIn.getNdgCardHolder().setValue(request.getAttribute("ndg"));

		inquiryResponseClass = (EsgCardInquiryResponseClass) this.getInquiryData(paramsIn, request);

		if (this.isGaussResponseError(inquiryResponseClass.getGaussResponse())) { // errore inquiry
			//	Gestione del forward e del warning in caso di errore da Host
			logger.debug("[EsgCardOpPinCardEnvelopeAction: pinCardEnvelopeGetData] Chiamata servizio Inquiry KO");
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, inquiryResponseClass.getGaussResponse());
			complexPopUpParams.setSevereError(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;
		} else { // inquiry OK
			logger.debug("[EsgCardOpPinCardEnvelopeAction: pinCardEnvelopeGetData] Chiamata al servizio Inquiry OK");
			actionForm.setCardInquiry(inquiryResponseClass.getCardInquiryData());
			actionForm.setVariations(inquiryResponseClass.getVariations());

			//Beans Directions definitions
			manageInquiryDataDirection(inquiryResponseClass);
		}
		logger.debug("[EsgCardOpPinCardEnvelopeAction: pinCardEnvelopeGetData] Inquiry Service End");
		// Questa parte viene eseguita se il servizio di inquiry non da messaggi di errore e/o altri messaggi                    		        	  

		EsgCardOperationsResponseClass cardOperationsResponseClass = new EsgCardOperationsResponseClass();

		paramsIn.getDeliveryTypeChoice().setValue("PI");
		paramsIn.setService("esgRequestDeliveryRetrieve");
		
		GecServiceFactory serviceFactory = null;
		IGecServiceFacade serviceF = null;
		try {
			serviceFactory = GecServiceFactory.getInstance();
			serviceF = serviceFactory.getGecServiceFacade();
			cardOperationsResponseClass = serviceF.esgCardOpRequestDeliveryRetrieve(paramsIn);
		} catch (Exception e) {
			throw e;
		} finally {
			if (serviceFactory != null && serviceF != null){
				serviceFactory.dispose(serviceF);
			}
		}
		
		if (this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse())) { // service error
			urlAfterError = this.urlAfterRetrieveError(request);
		} else {
			actionForm.setRequestDeliveryInOut(cardOperationsResponseClass.getRequestDeliveryInOut());
		}

		this.manageInformationBar(request, "card.label.pinCardEnvelopeRequest.text", actionForm.getCardInquiry());
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, cardOperationsResponseClass.getGaussResponse());
		complexPopUpParams.setActionBackError(urlAfterError);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_PIN_CARD_ENVELOPE); // forward OK
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.debug("[EsgCardOpPinCardEnvelopeAction: expressDeliveryGetData] *******END***** ");
		return forward;
	}
		

	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 **/
	public ActionForward pinCardEnvelopeUpdate(ActionMapping mapping,
										 ActionForm form,
										 HttpServletRequest request,
										 HttpServletResponse response)throws java.lang.Exception{
		
		logger.debug("[EsgCardOpPinCardEnvelopeAction: pinCardEnvelopeUpdate] *******START*****");

		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;
		
		EsgCardOpRequestDeliveryInOut expressDeliveryIn =  new EsgCardOpRequestDeliveryInOut();
		
		expressDeliveryIn = actionForm.getRequestDeliveryInOut();
		expressDeliveryIn.getAddressTypeChoice().setValue("B");
		
		EsgCardOperationsResponseClass classReturn = new EsgCardOperationsResponseClass();

		//Classe inOut per chiamare il servizio, popolata leggendo i dati da ActionForm 
		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		GecServiceFactory serviceFactory = null;
		IGecServiceFacade serviceF = null;
		try {
			serviceFactory = GecServiceFactory.getInstance();
			serviceF = serviceFactory.getGecServiceFacade();
			expressDeliveryIn.setService("esgRequestDeliveryConfirm");
			classReturn = serviceF.esgCardOpRequestDeliveryUpdate(expressDeliveryIn);
		} catch (Exception e) {
			throw e;
		} finally {
			if (serviceFactory != null && serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}

		String urlServiceCallOK = "";
		String urlServiceCallKO = "";
		
		if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
			urlServiceCallKO = this.urlAfterUpdateError(request);
			logger.debug("********* Update ExpressDeliver  ERRORE  ************" + urlServiceCallKO);
		} else {
			urlServiceCallOK = this.urlAfterUpdateSuccess(request);
			logger.debug("********* Update ExpressDeliver  MESSAGGIO  ************" + urlServiceCallOK);
			
			// gestione stampe automatiche
			this.managePrintInformation(request, classReturn.getPrintManager());
		}
		
		//EE29052 - FirmaMia - Problemi con il popup, quindi imposto il parametro 
		request.getSession().setAttribute("storedOkAndNoTabletIssues", "false");
		boolean isPaper = "".equalsIgnoreCase(request.getParameter("tabletStatusKo"));
		if(!isPaper && !(request.getParameter("tabletStatusKo") != null && "true".equalsIgnoreCase(request.getParameter("tabletStatusKo")))) {
			logger.info("SETTO storedOkAndNoTabletIssues TO TRUE");
			request.getSession().setAttribute("storedOkAndNoTabletIssues", "true");
		}
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
		complexPopUpParams.setActionBackError(urlServiceCallKO);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setActionBackMessage(urlServiceCallOK);
		complexPopUpParams.setReturnBackMessage(true);
		forward = Utl.createComplexPopUp(complexPopUpParams);

		return forward;
	}
	
	
	// EE29052 - Firmamia - stored to determine whether the print is digital
	public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
		return GecUtilities.checkStoredFirmaMia(request, response);
	}
	// EE29052 - Firmamia - END
	
	
	// EE29052 - Firmamia - stored to determine whether the print is digital
	/*public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
		logger.info("EsgCardOpPinCardEnvelopeAction.checkStoredFirmaMia --- start");
		
		String toReturn = "KO";
		
		if(EsgCountryCode.isItalianCountry()){
			if(GecUtilities.isFirmaMiaSkipTabletCheckSet()){
				logger.info("SKIPPING STORED CHECK");
				toReturn = "OK";
			} else {
				String module = request.getParameter("module");
				logger.debug("EsgCardOpChargeDateChangeAction.checkStored --- module: " + module);
				
				UserData userData = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
				String branch = userData.getFilialeOperatore() != null ? userData.getFilialeOperatore() : "";
				
				PaperlessCheckInput input = new PaperlessCheckInput();
				input.setModulo(module);
				input.setFiliale(branch);
				
				logger.info("PILOTBRANCHCHECK - BRANCH: " + branch + " MODULE: " + module);
				
				// -- 3 -- chiamata al servizio -----------------------------------------------------------------------------------------------------
				
				PaperlessCheckOutput output = new PaperlessCheckOutput();		
				GecServiceFactory serviceF = GecServiceFactory.getInstance();
				IGecServiceFacade serv = serviceF.getGecServiceFacade();
				try {
					// service call
					output = serv.retrievePaperlessCheck(input);
				} finally {
					serviceF.dispose(serv);
				}
				
				if (output.getReturnCode() == 0) { // service call OK
					logger.info("GECKSFMR RESPONSE OK. flagRetry = " + output.getFlagRetry());
					if("[Y]".equalsIgnoreCase(output.getFlagRetry().trim())) {
						toReturn = "OK";
					}
				} else {
					logger.info("GECKSFMR RESPONSE KO");
					toReturn = "KO";
				}
			}
		}
		
		String jsonResult = "{\"result\" : \"" + toReturn + "\"}";
		logger.info("JSONRESULT = " + jsonResult);
		
		response.setHeader("Content-Type", "application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.write(jsonResult);
		out.flush();
		out.close();
		logger.info("EsgCardOpPinCardEnvelopeAction.checkStoredFirmaMia --- end");
		return null;
	}*/
	// EE29052 - Firmamia - END
	
	
}
