/*
 * Created on Feb 09, 2012
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package it.usi.xframe.gec.pfstruts.actions.eurosig.cardOperations;


import java.util.ArrayList;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpOptionalRevolvingInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOperationsResponseClass;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.general.GecSevereException;
import it.usi.xframe.gec.bfutil.utilities.CommonParameters;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.pfstruts.forms.eurosig.cardInquiry.EsgCardInquiryActionForm;
import it.usi.xframe.gec.pfstruts.utilities.CommonParametersFactory;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.gec.pfstruts.utilities.GecWebUtilities;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.Utl;
import it.usi.xframe.utl.bfutil.XlcConstantTag;
import it.usi.xframe.utl.bfutil.general.MarkedSessionManager;

public class EsgCardOpOptionalRevolvingAction extends EsgCardOperationsGeneralAction {

	private Log logger = LogFactory.getLog(this.getClass());
	
	
	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward optionalRevolvingGetChoice(ActionMapping mapping,
									  ActionForm form,
									  HttpServletRequest request,
									  HttpServletResponse response)throws java.lang.Exception{

		logger.debug("[EsgCardOpOptionalRevolvingAction: optionalRevolvingGetChoice] *******START *********");

		//EE29052 - FirmaMia - XPI tablet check
		GecUtilities.setSignpadVerifyURL(request);
		//EE29052 - FirmaMia - END
		
		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;
		String urlAfterError = "";

		//debug parametri in request
		GecWebUtilities.debugRequest(request);

		// commonParameters
		UserData userData = GecWebUtilities.getUserData(request);
		CommonParameters cP = CommonParametersFactory.getInstance().createCommonParameters(request, userData);
		actionForm.getOptionalRevolvingInOut().setCommonParameters(cP);
		actionForm.getOptionalRevolvingInOut().setUserData(userData);
		actionForm.getOptionalRevolvingInOut().getXfGaussId().setValue((String) MarkedSessionManager.getInstance().getSessionMarker(request));

		// codice iso ambiente
		String environmentCountry = EsgCountryCode.getEnvironmentCountry();
		actionForm.getOptionalRevolvingInOut().getEnvironmentCountry().setValue(environmentCountry);

		//Metto in request alcuni parametri tipici
		this.setRequestParams(form, request);
		
		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);


		// recupero i parametri di input ai servizi
		String ndg = Utl.trimNum(GecWebUtilities.getRequestParameter(request, "ndg"));
		String contractNumber = Utl.trimNum(GecWebUtilities.getRequestParameter(request, "contractNumber"));
		String contractProgressive = GecWebUtilities.getRequestParameter(request, "cardSeqNumber");
		logger.debug("[EsgCardOpOptionalRevolvingAction - optionalRevolvingGetChoice] ndg: " + ndg);
		logger.debug("[EsgCardOpOptionalRevolvingAction - optionalRevolvingGetChoice] contractNumber: " + contractNumber);
		logger.debug("[EsgCardOpOptionalRevolvingAction - optionalRevolvingGetChoice] contractProgressive: " + contractProgressive);

		// chiamata host inquiry
		EsgCardInquiryResponseClass inquiryResponseClass = new EsgCardInquiryResponseClass();
		EsgCardInquiryInOut paramsIn = new EsgCardInquiryInOut();
		
		paramsIn.getNdgCardHolder().setValue(ndg);
		paramsIn.getContractNum().setValue(contractNumber);
		paramsIn.getCardSeqNumber().setValue(contractProgressive);
		
		
		inquiryResponseClass = (EsgCardInquiryResponseClass) this.getInquiryData(paramsIn, request);
		
		if (inquiryResponseClass.getGaussResponse() != null && inquiryResponseClass.getGaussResponse().isErrorFlag()) { // errore inquiry
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, inquiryResponseClass.getGaussResponse());
			complexPopUpParams.setSevereError(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;
		} else { // inquiry OK
			actionForm.setCardInquiry(inquiryResponseClass.getCardInquiryData());
		}
		actionForm.setCardInquiry(inquiryResponseClass.getCardInquiryData());

		//Beans Directions definitions
		manageInquiryDataDirection(inquiryResponseClass);

		

		EsgCardOperationsResponseClass cardOperationsResponseClass = new EsgCardOperationsResponseClass();

		EsgCardOpOptionalRevolvingInOut optionalRevolvingIn = new EsgCardOpOptionalRevolvingInOut();
		optionalRevolvingIn.getContractNum().setValue(request.getAttribute("contractNumber"));
		optionalRevolvingIn.getCardSeqNumber().setValue(request.getAttribute("cardSeqNumber"));
		optionalRevolvingIn.setUserLocale((Locale)request.getSession().getAttribute(Globals.LOCALE_KEY));
		
		try {
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			try {
				IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
				try {
					cardOperationsResponseClass = serviceF.esgCardOpOptionalRevolvingGetChoice(optionalRevolvingIn);
				} finally {
					serviceFactory.dispose(serviceF);
				}
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}
		

		if (this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse()))  // service error
			urlAfterError = this.urlAfterRetrieveError(request);
		else {
			actionForm.setOptionalRevolvingInOut(cardOperationsResponseClass.getOptionalRevolvingInOut());
			actionForm.getOptionalRevolvingInOut().getContractNum().setValue(optionalRevolvingIn.getContractNum().getValue());
			actionForm.getOptionalRevolvingInOut().getCardSeqNumber().setValue(optionalRevolvingIn.getCardSeqNumber().getValue());
			if (cardOperationsResponseClass.getOptionalRevolvingInOut().getChangeRembursmentModeFlagLayout() == 2) {
				actionForm.getOptionalRevolvingInOut().getChoice().setDirection(XlcConstantTag.INFIXED);
				// EE29570 - Progetto Flexia - Charge con rimborso rateale del debito residuo
				actionForm.getOptionalRevolvingInOut().setChargeRataDisplayFlag(2);
			} else {
				//EE29570 - Progetto Flexia - Charge con rimborso rateale del debito residuo
				// cardOperationsResponseClass.getOptionalRevolvingInOut().testCardListCharge();			
				ArrayList cardListCharge = cardOperationsResponseClass.getOptionalRevolvingInOut().getCardListCharge();
				if (cardListCharge != null && cardListCharge.size() > 0) {
					request.setAttribute("cardListCharge", cardOperationsResponseClass.getOptionalRevolvingInOut().getCardListChargeJSON());				
				}
				//EE29570 - Progetto Flexia - Charge con rimborso rateale del debito residuo
			}
				
			this.manageInformationBar(request, "card.label.optionalRevolvingChoiceChange.text", actionForm.getCardInquiry());
		}
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, cardOperationsResponseClass.getGaussResponse());
		complexPopUpParams.setActionBackError(urlAfterError);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_OP_OPTIONAL_REVOLVING_CHANGE);		   
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.debug("[EsgCardOpOptionalRevolvingAction: optionalRevolvingGetChoice] *******END***** ");
		return forward;
	}
		

	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 **/
	public ActionForward optionalRevolvingSetChoice(ActionMapping mapping,
										 ActionForm form,
										 HttpServletRequest request,
										 HttpServletResponse response)throws java.lang.Exception{
		
		logger.debug("[EsgCardOpOptionalRevolvingAction: optionalRevolvingSetChoice] *******START*****");

		//debug parametri in request
		GecWebUtilities.debugRequest(request);
		
		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		EsgCardOpOptionalRevolvingInOut optionalRevolvingIn = actionForm.getOptionalRevolvingInOut();
		optionalRevolvingIn.getContractNum().setValue(GecWebUtilities.getRequestParameter(request, "contractNumber"));
		optionalRevolvingIn.getCardSeqNumber().setValue(GecWebUtilities.getRequestParameter(request, "cardSeqNumber"));
		optionalRevolvingIn.setUserLocale((Locale)request.getSession().getAttribute(Globals.LOCALE_KEY));
		optionalRevolvingIn.getCurrentChoice().setValue(GecWebUtilities.getRequestParameter(request, "currentChoice"));
		
		EsgCardOperationsResponseClass classReturn = new EsgCardOperationsResponseClass();
		this.setPaginationParams(form, request);

		try {
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			try {
				IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
				try {
					classReturn = serviceF.esgCardOpOptionalRevolvingSetChoice(optionalRevolvingIn);
				} finally {
					serviceFactory.dispose(serviceF);
				}
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}

		String urlServiceCallOK = "";
		String urlServiceCallKO = "";
		
		if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
			urlServiceCallKO = this.urlAfterUpdateError(request);
			logger.debug("********* optionalRevolvingSetChoice  ERRORE  ************" + urlServiceCallKO);
		} else {
			urlServiceCallOK = this.urlAfterUpdateSuccess(request);
			logger.debug("********* optionalRevolvingSetChoice  MESSAGGIO  ************" + urlServiceCallOK);
			
			// gestione stampe automatiche
			this.managePrintInformation(request, classReturn.getPrintManager());
		}
		
		//EE29052 - FirmaMia - Problemi con il popup, quindi imposto il parametro 
		request.getSession().setAttribute("storedOkAndNoTabletIssues", "false");
		boolean isPaper = "".equalsIgnoreCase(request.getParameter("tabletStatusKo"));
		if(!isPaper && !(request.getParameter("tabletStatusKo") != null && "true".equalsIgnoreCase(request.getParameter("tabletStatusKo")))) {
			logger.info("SETTO storedOkAndNoTabletIssues TO TRUE");
			request.getSession().setAttribute("storedOkAndNoTabletIssues", "true");
		}
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
		complexPopUpParams.setActionBackError(urlServiceCallKO);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setActionBackMessage(urlServiceCallOK);
		complexPopUpParams.setReturnBackMessage(true);
		forward = Utl.createComplexPopUp(complexPopUpParams);

		return forward;
	}
	
	
	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward optRevolvingWindowInquiry(ActionMapping mapping,
									  ActionForm form,
									  HttpServletRequest request,
									  HttpServletResponse response)throws java.lang.Exception{
		logger.debug("[EsgCardOpOptionalRevolvingAction: optionalRevolvingWindowInquiry] *******START *********");

		//debug parametri in request
		GecWebUtilities.debugRequest(request);

		//Metto in request alcuni parametri tipici
		this.setRequestParams(form, request);

		this.manageInformationBar(request, "card.label.optionalRevolvingChoiceChange.text", null);
		
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		EsgCardOpOptionalRevolvingInOut optionalRevolvingIn = actionForm.getOptionalRevolvingInOut();
		optionalRevolvingIn.getContractNum().setValue(GecWebUtilities.getRequestParameter(request, "contractNumber"));
		optionalRevolvingIn.getCardSeqNumber().setValue(GecWebUtilities.getRequestParameter(request, "cardSeqNumber"));
		optionalRevolvingIn.setUserLocale((Locale)request.getSession().getAttribute(Globals.LOCALE_KEY));
		optionalRevolvingIn.getCurrentChoice().setValue(GecWebUtilities.getRequestParameter(request, "currentChoice"));
		
		/* ***********************************************************************************************
		// * Questo codice si occupa di richiare il servizio di inquiry in caso di chiamata diretta 
		 
		EsgCardOperationsResponseClass cardOperationsResponseClass = new EsgCardOperationsResponseClass();

		EsgCardOpOptionalRevolvingInOut optionalRevolvingIn = new EsgCardOpOptionalRevolvingInOut();
		optionalRevolvingIn.getContractNum().setValue(request.getParameter("contractNumber"));
		optionalRevolvingIn.getCardSeqNumber().setValue(request.getParameter("cardSeqNumber"));
		optionalRevolvingIn.setUserLocale((Locale)request.getSession().getAttribute(Globals.LOCALE_KEY));

		{ // Richiesta servizio host
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			IGecServiceFacade serviceF = null;
			try {
				serviceF = serviceFactory.getGecServiceFacade();
				cardOperationsResponseClass = serviceF.esgCardOpOptionalRevolvingGetChoice(optionalRevolvingIn);
			} catch (Exception e) {
				throw e;
			} finally {
				if (serviceFactory != null && serviceF != null) {
					serviceFactory.dispose(serviceF);
				}
			}
		} // FINE - Richiesta servizio host

		if (this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse())) {  // service error
			logger.debug("[EsgCardOpOptionalRevolvingAction: optRevolvingWindowInquiry] *******ERROR***** ");
		} else {
				logger.debug("[EsgCardOpOptionalRevolvingAction: optRevolvingWindowInquiry] *******SUCCESSFUL***** ");		
		}

		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, cardOperationsResponseClass.getGaussResponse());
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_OP_OPTIONAL_REVOLVING_CHANGE);		   
		Utl.createComplexPopUp(complexPopUpParams);
		********************************************************************************************************/
		
		logger.debug("[EsgCardOpOptionalRevolvingAction: optRevolvingWindowInquiry] *******END***** ");
		return mapping.findForward(GecWebConstants.ESG_CARD_OP_OPTIONAL_REVOLVING_WINDOW);
	}
	
	
	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward optRevolvingWindowUpdate(ActionMapping mapping,
									  ActionForm form,
									  HttpServletRequest request,
									  HttpServletResponse response)throws java.lang.Exception{
		logger.debug("[EsgCardOpOptionalRevolvingAction: optRevolvingWindowUpdate] *******START*****");

		//debug parametri in request
		GecWebUtilities.debugRequest(request);

		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		//Metto in request alcuni parametri tipici
		this.setRequestParams(form, request);

		EsgCardOpOptionalRevolvingInOut optionalRevolvingIn = actionForm.getOptionalRevolvingInOut();
		
		//optionalRevolvingIn.getContractNum().setValue(GecWebUtilities.getRequestParameter(request, "contractNumber"));
		//optionalRevolvingIn.getCardSeqNumber().setValue(GecWebUtilities.getRequestParameter(request, "cardSeqNumber"));
		optionalRevolvingIn.setUserLocale((Locale)request.getSession().getAttribute(Globals.LOCALE_KEY));
		optionalRevolvingIn.getCurrentChoice().setValue(GecWebUtilities.getRequestParameter(request, "currentChoice"));
		optionalRevolvingIn.getChoice().setValue("SA2");
		 
		this.manageInformationBar(request, "card.label.optionalRevolvingChoiceChange.text", null);

		EsgCardOperationsResponseClass classReturn = new EsgCardOperationsResponseClass();

		{ // Richiesta servizio host
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			IGecServiceFacade serviceF = null;
			try {
				serviceF = serviceFactory.getGecServiceFacade();
				classReturn = serviceF.esgCardOpOptionalRevolvingSetChoice(actionForm.getOptionalRevolvingInOut());
			} catch (Exception e) {
				throw new GecSevereException(e);
			} finally {
				if (serviceFactory != null && serviceF != null) {
					serviceFactory.dispose(serviceF);
				}
			}
		} // FINE - Richiesta servizio host

		if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
			
			request.setAttribute("statusService", "KO");
			
			{ // Se la chiamata � andata in errore allora si richiama la funzione di inquiry per ricaricare i dati
				
				EsgCardOperationsResponseClass cardOperationsResponseClass = new EsgCardOperationsResponseClass();
				GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
				IGecServiceFacade serviceF = null;
				try {
					serviceF = serviceFactory.getGecServiceFacade();
					cardOperationsResponseClass = serviceF.esgCardOpOptionalRevolvingGetChoice(optionalRevolvingIn);
				} finally {
					if (serviceFactory != null && serviceF != null) {
						serviceFactory.dispose(serviceF);
					}
				}
	
				if (this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse())) {  // service error
					logger.debug("********* optRevolvingWindowUpdate  SEVERE ERROR  ************");
				} else {
					ArrayList cardListCharge = cardOperationsResponseClass.getOptionalRevolvingInOut().getCardListCharge();
					if (cardListCharge != null && cardListCharge.size() > 0) {
						request.setAttribute("argumentsWindow", cardOperationsResponseClass.getOptionalRevolvingInOut().getCardListChargeJSON());				
					}
				}
				logger.debug("********* optRevolvingWindowUpdate  RELOAD SUCCESS  ************");
			}
			
			
			logger.debug("********* optRevolvingWindowUpdate  ERRORE  ************");
		} else {
			request.setAttribute("statusService", "OK");
			logger.debug("********* optionalRevolvingSetChoice  MESSAGGIO  ************");

			// gestione stampe automatiche
			this.managePrintInformation(request, classReturn.getPrintManager());
		}

		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_OP_OPTIONAL_REVOLVING_WINDOW);		   
		forward = Utl.createComplexPopUp(complexPopUpParams);

		return forward;
	}
	
	// EE29052 - Firmamia - stored to determine whether the print is digital
	public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
		return GecUtilities.checkStoredFirmaMia(request, response);
	}
	// EE29052 - Firmamia - END
}
