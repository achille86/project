/*
 * Created on Feb 27, 2008
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package it.usi.xframe.gec.pfstruts.actions.eurosig.cardOperations;

import java.io.PrintWriter;
import java.rmi.RemoteException;

import it.usi.warranter.Warranty2;
import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckInput;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOutput;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpConfirmAuthInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpRequestDeliveryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOperationsResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgPrintManager;
import it.usi.xframe.gec.bfutil.eurosig.print.EsgCardPrintResponseClass;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.utilities.GecMessageCacher;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.pfstruts.forms.eurosig.cardInquiry.EsgCardInquiryActionForm;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.gec.pfstruts.utilities.GecWebUtilities;
import it.usi.xframe.gec.pfstruts.utilities.MarkedSessionManager;
import it.usi.xframe.ifg.bfutil.HostUserInfoException;
import it.usi.xframe.ifg.bfutil.IfgServiceFactory;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.system.eservice.ServiceFactoryException;
import it.usi.xframe.system.ifutils.EnvironmentLoader;
import it.usi.xframe.system.ifutils.IEnvironment;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.GaussResponse;
import it.usi.xframe.utl.bfutil.Utl;
import it.usi.xframe.xpi.bfutil.XDocument;
import it.usi.xframe.xpi.bfutil.XPIConstants;
import it.usi.xframe.xpi.bfutil.signpad.SignpadInOut;
import it.usi.xframe.xpi.bfutil.signpad.SignpadResponseClass;
import it.usi.xframe.xpi.bfutil.signpad.SignpadUtilities;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * @author EE06077
 * Azione che si occupa della conferma emissione carta  
 */
public class EsgCardOpIssueConfirmAction extends EsgCardOperationsGeneralAction {

	private Log logger = LogFactory.getLog(this.getClass());

	/**
	 * recupera i dati relativi alla conferma
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward confirmGetData(ActionMapping mapping,
										ActionForm form,
										HttpServletRequest request,
										HttpServletResponse response) throws java.lang.Exception {

		logger.debug("[EsgCardOpIssueConfirmAction - confirmGetData] ---- INIT ----");
		
		// metto in request alcuni parametri tipici
		this.setRequestParams(form, request);
		// inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		// inizializzazione forward e form
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		//EE29052 - FirmaMia - XPI tablet check
		GecUtilities.setSignpadVerifyURL(request);
		//EE29052 - FirmaMia - END

		// chiamata servizio di inquiry
		EsgCardInquiryResponseClass inquiryResponseClass = new EsgCardInquiryResponseClass();
		EsgCardInquiryInOut paramsIn = new EsgCardInquiryInOut();
		EsgCardOpConfirmAuthInOut confirmInOut = new EsgCardOpConfirmAuthInOut();
		EsgCardOpRequestDeliveryInOut expressInOut = new EsgCardOpRequestDeliveryInOut();
		
		// definizione dei parametri di input al servizio
		paramsIn = this.retrieveInquiryInput(request, actionForm.getCardInquiryInOut());
		inquiryResponseClass = (EsgCardInquiryResponseClass) this.getInquiryData(paramsIn, request);
		
		if (this.isGaussResponseError(inquiryResponseClass.getGaussResponse())) { // errore inquiry
			logger.debug("[EsgCardOpIssueConfirmAction - confirmGetData] errore chiamata servizio inquiry!");
			// gestione del forward e del warning
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, inquiryResponseClass.getGaussResponse());
			complexPopUpParams.setSevereError(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;
		}
		else { // inquiry OK
			logger.debug("[EsgCardOpIssueConfirmAction - confirmGetData] chiamata al servizio inquiry ok");
			actionForm.setCardInquiry(inquiryResponseClass.getCardInquiryData());
			actionForm.setVariations(inquiryResponseClass.getVariations());
			confirmInOut.getContractNum().setValue(paramsIn.getContractNum().getValue());
			confirmInOut.getCardSeqNumber().setValue(paramsIn.getCardSeqNumber().getValue());
			confirmInOut.getNdgCardHolder().setValue(paramsIn.getNdgCardHolder().getValue());
			confirmInOut.getCardHolder().setValue(paramsIn.getCardHolder().getValue());
			actionForm.setConfirmAuthInOut(confirmInOut);

			// beans directions definition
			manageInquiryDataDirection(inquiryResponseClass);
		}

		logger.debug("[EsgCardOpIssueConfirmAction - confirmGetData] inquiry service end");		
		
		// chiamata servizio di conferma
		EsgCardOperationsResponseClass cardOperationsResponseClass = new EsgCardOperationsResponseClass();
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			cardOperationsResponseClass = serviceF.esgCardOpIssueConfirm(confirmInOut);
		} catch (Exception e) {
			throw e;
		} finally {
			if (serviceFactory != null && serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}


		if (!this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse())) { // service ok
			actionForm.setConfirmAuthInOut(cardOperationsResponseClass.getConfirmAuthInOut());
			logger.debug("[EsgCardOpIssueConfirmAction - confirmGetData] returnCode: " + cardOperationsResponseClass.getConfirmAuthInOut().getReturnCode());
			this.manageInformationBar(request, "menu.label.issueConfirm.text", actionForm.getCardInquiry());
			
			// gestisco la request per i messaggi da mostrare in fase di submit
			GecWebUtilities.manageOnSubmitMessagesRequest(request, cardOperationsResponseClass.getOnSubmitMessages());
			
			/* EE29570 - Garante2 start */
			if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){
				Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(17, it.usi.warranter.Utils.REQUEST_TYPE_INQUIRY, request); 				
				if (warranty2 != null) {
					this.logGarante2(warranty2, form);
				} else {
					logger.debug("[EsgCardOpIssueConfirmAction:confirmGetData] Errore nella richiesta Garante2");
				}
			}
			/* Garante2 end */
		}
		
		// ---- [init] gestione stampe automatiche ------------- per Bank Austria la stampa del contratto in Emissione avviene a S-IN ----
		if (EsgCountryCode.isAustrianCountry()) {
			// recupero dalla sessione il bean per chiamare l'action di stampa
			EsgPrintManager printManager = (EsgPrintManager) request.getSession().getAttribute(GecWebConstants.ESG_PRINT_MANAGER);
			logger.debug("[EsgCardOpIssueConfirmAction:confirmGetData]  printManager is null? " + (printManager == null));
			
			EsgCardPrintResponseClass responseClass = new EsgCardPrintResponseClass();
			if (printManager != null) { // chiamo transazione host per la stampa
				serviceFactory = GecServiceFactory.getInstance();
				try {
					serviceF = serviceFactory.getGecServiceFacade();
					responseClass = serviceF.esgRetrievePrintDocuments(paramsIn, printManager);
					
					boolean printError = false;
					if (responseClass.getGaussResponse() != null && responseClass.getGaussResponse().isErrorFlag()) {
						// errore
						logger.debug("[EsgCardOpIssueConfirmAction:confirmGetData]  print service error!!");
						printError = true;
					} else {
						// servizio stampa ok: setto in request il dato da stampare
						GecWebUtilities.setPrintActionAttribute(responseClass.getPrintDoc(), GecWebUtilities.retrievePrintMode(printManager)); // modalit� stampa
						MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "printForm", responseClass.getPrintDoc());
						logger.debug("[EsgCardOpIssueConfirmAction:confirmGetData]  print service ok!");
					}
				
					// setto in request le informazioni relative alla stampa (oggetto json utilizzato da javascript)
					request.setAttribute(GecWebConstants.ESG_PRINT_MANAGER_INQUIRY, GecWebUtilities.getPrintInformationJson(printManager, printError));

				} catch (Exception e) {
					logger.debug("[EsgCardOpIssueConfirmAction:confirmGetData] Error while retrieving print documents: " + e.getMessage());
				} finally {
					if (serviceFactory != null && serviceF != null) {
						serviceFactory.dispose(serviceF);
					}
				}
			}
			
			// rimuovo il bean di stampa dalla sessione
			request.getSession().removeAttribute(GecWebConstants.ESG_PRINT_MANAGER);
		}
		// ---- [end] gestione stampe automatiche -----------------------------------------------------------------------------------

		
		// Postalizzazione [init]
		if(actionForm.getConfirmAuthInOut().isFlagExpressDelivery()) {
			//Definizione dei parametri di input al servizio
			expressInOut.getContractNum().setValue(GecWebUtilities.getRequestParameter(request, "contractNumber"));
			expressInOut.getCardSeqNumber().setValue(GecWebUtilities.getRequestParameter(request, "cardSeqNumber"));
			expressInOut.getNdgCardHolder().setValue(GecWebUtilities.getRequestParameter(request, "ndg"));
			
			cardOperationsResponseClass = new EsgCardOperationsResponseClass();
			expressInOut.getDeliveryTypeChoice().setValue("SU");
			
			try {
				serviceFactory = GecServiceFactory.getInstance();
				serviceF = serviceFactory.getGecServiceFacade();
				expressInOut.setService("EsgCardIssueConfirm");
				cardOperationsResponseClass = serviceF.esgCardOpRequestDeliveryRetrieve(expressInOut);
			} catch (Exception e) {
				throw e;
			} finally {
				if (serviceFactory != null && serviceF != null){
					serviceFactory.dispose(serviceF);
				}
			}
			
			if (!this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse())) { // OK
				actionForm.setRequestDeliveryInOut(cardOperationsResponseClass.getRequestDeliveryInOut());
			}
		}		
		// Postalizzazione [end]

		// EE29570 - Progetto Mars - Modifica temporanea
		// TODO : Da rimuovere in futuro il flag di sviluppo
		// Inserisco il controllo del flag per la linea di credito in Germania
		String tipoCarta = (String) actionForm.getCardInquiry().getProductData().getProductCode().getValue();
		String flag = "N";
		if (tipoCarta != null && EsgCountryCode.isGermanCountry() && tipoCarta.charAt(1) == 'C'){
			GecMessageCacher cacher = GecMessageCacher.getInstance();
			Object UWflag = cacher.getFromCache(GecUtilities.UNDERWRITINGFLAG_CACHE);
			if (UWflag != null) {
				flag = UWflag.toString();
			} else {
				UWflag = (GecUtilities.isCommittedCreditLineSet() ? "S" : "N");
				cacher.addToCache(GecUtilities.UNDERWRITINGFLAG_CACHE, UWflag);
				flag = UWflag.toString();
			}
		} 
		request.setAttribute("CommitedCreditLineFlag", flag);
		logger.debug("[EsgCardOpIssueConfirmAction:confirmGetData] TIPOCARTA:" + tipoCarta + " Flag :" + flag);

		String urlAfterError = this.urlAfterRetrieveError(request);
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, cardOperationsResponseClass.getGaussResponse());
		complexPopUpParams.setActionBackError(urlAfterError);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_ISSUE_CONFIRM);
		forward = Utl.createComplexPopUp(complexPopUpParams);
		
		if (EsgCountryCode.isItalianCountry()){
			request.setAttribute("showPlasticCardFrame", "true");
			//Controllo flag di visualizzazione Supporto Plastico
			if (GecUtilities.isDigitalCardSet()){
				request.setAttribute(GecUtilities.FLAG_CACHE_DIGITAL_CARD, GecUtilities.GEC_PARAM_VALID_TRUE);
				logger.debug("[EsgCardInquiryAction:unspecified]Digital Card Flag : TRUE ");
			} else {
				logger.debug("[EsgCardInquiryAction:unspecified]Digital Card Flag : FALSE");
			}
		}
		

		logger.debug("[EsgCardOpIssueConfirmAction - confirmGetData] ---- END ----");
		return forward;
	}

	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward issueConfirmUpdate(ActionMapping mapping,
											ActionForm form,
											HttpServletRequest request,
											HttpServletResponse response) throws java.lang.Exception {

		logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate] ---- INIT ----");

		String exPlasticCardActive = request.getParameter("exPlasticCardActiveChoice");
		boolean isPlasticCardNoSelected = "N".equalsIgnoreCase(exPlasticCardActive);
		
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		EsgCardOperationsResponseClass classReturn = new EsgCardOperationsResponseClass();
		EsgCardOperationsResponseClass classReturnDelivery = new EsgCardOperationsResponseClass();
		GaussResponse gaussResponse = null;
		EsgCardOpConfirmAuthInOut paramsIn = new EsgCardOpConfirmAuthInOut();
		EsgCardOpRequestDeliveryInOut expressDeliveryIn = actionForm.getRequestDeliveryInOut();
		actionForm.setCountryCode(EsgCountryCode.getEnvironmentCountry());

		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		String ndg = (String) actionForm.getAddFunctionsInOut().getNdgCardHolder().getValue();
		String clientDescription = (String) actionForm.getAddFunctionsInOut().getNdgCardHolder().getValue();
		String choiceCode = (String) actionForm.getConfirmAuthInOut().getChoiceCode().getValue();

		logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate] ndg: " + ndg);
		logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate] clientDescription: " + clientDescription);
		logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate] choiceCode: " + choiceCode);

		//[INIT] Call Limits Change Service Manager
		paramsIn = actionForm.getConfirmAuthInOut();
		if (EsgCountryCode.isItalianCountry()){
			paramsIn.setPlasticCardActive(exPlasticCardActive);
		}

		try {
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			try {
				IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
				try {
					classReturn = serviceF.esgCardOpIssueConfirmUpdate(paramsIn);
					gaussResponse = classReturn.getGaussResponse();
				} finally {
					serviceFactory.dispose(serviceF);
				}
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}

		String urlServiceCallOK = "";
		String urlServiceCallKO = "";

		if (this.isGaussResponseError(classReturn.getGaussResponse())) {
			// service error
			urlServiceCallKO = this.urlAfterUpdateError(request);
			logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate - esgCardOpIssueConfirmUpdate] error url: " + urlServiceCallKO);
		} else {
			urlServiceCallOK = this.urlAfterUpdateSuccess(request);
			logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate - esgCardOpIssueConfirmUpdate] url ok: " + urlServiceCallOK);
			
			String usersChoisePlasticSupport = (String) request.getAttribute("UsersChoisePlasticSupport");
			
			if(actionForm.getConfirmAuthInOut().isFlagExpressDelivery()
				&& "AUC".equalsIgnoreCase(choiceCode) && (EsgCountryCode.isItalianCountry() && "Y".equalsIgnoreCase(usersChoisePlasticSupport))) {
				// Postalizzazione [init]
				try {
					GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
					try {
						IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
						try {
							expressDeliveryIn.setService("EsgCardIssueConfirmUpdate");
							classReturnDelivery = serviceF.esgCardOpRequestDeliveryUpdate(expressDeliveryIn);
							gaussResponse = classReturnDelivery.getGaussResponse();
						} finally {
							serviceFactory.dispose(serviceF);
						}
					} catch (Exception e) {
						throw e;
					}
				} catch (Exception e) {
					throw e;
				}
				
				if (this.isGaussResponseError(classReturnDelivery.getGaussResponse())) {
					// service error
					urlServiceCallKO = this.urlAfterUpdateError(request);
					logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate - esgCardOpRequestDeliveryUpdate] error url: " + urlServiceCallKO);
				}
				// Postalizzazione [end]
			}
			// gestione stampe automatiche
			//EE29052 - FirmaMia - Problemi con il popup, quindi imposto il parametro 
			request.getSession().setAttribute("storedOkAndNoTabletIssues", "false");
			boolean isPaper = "".equalsIgnoreCase(request.getParameter("tabletStatusKo"));
			if(!isPaper && !(request.getParameter("tabletStatusKo") != null && "true".equalsIgnoreCase(request.getParameter("tabletStatusKo")))){
				logger.info("SETTO storedOkAndNoTabletIssues TO TRUE");
				request.getSession().setAttribute("storedOkAndNoTabletIssues", "true");
			}
			this.managePrintInformation(request, classReturn.getPrintManager());
			
			/* EE29570 - Garante2 start */
			if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){
				Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(18, it.usi.warranter.Utils.REQUEST_TYPE_DISPOSITIVE, request); 				
				if (warranty2 != null) {
					this.logGarante2(warranty2, form);
				} else {
					logger.debug("[EsgCardOpBlockAction:Block] Errore nella richiesta Garante2");
				}
			}
			/* Garante2 end */
		}
		
		// radio di conferma
		if (EsgCountryCode.isItalianCountry() && "AUC".equalsIgnoreCase(choiceCode)){
			if (gaussResponse == null || (gaussResponse != null && gaussResponse.isNotifyFlag())) {
				if (gaussResponse == null) {
					gaussResponse = new GaussResponse();
				}
				String productCode = actionForm.getCardInquiry().getProductData().getProductCode().getValue().toString();
			
					if ("D".equals(productCode.substring(1, 2))) {
						//String pan = actionForm.getCardInquiry().getCardSpecificData().getInterApplIdentifier().getValue().toString();
						//GecUtilities.retrievesWarningMsgWithParam(gaussResponse, GecUtilities.MSG_1532, pan);
						GecUtilities.retrievesWarningMsg(gaussResponse,	GecUtilities.MSG_1532);
					} else if ("C".equals(productCode.substring(1, 2)) || "P".equals(productCode.substring(1, 2))) {
						GecUtilities.retrievesWarningMsg(gaussResponse,	GecUtilities.MSG_1530);
					}
			}
		}
	
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, gaussResponse);
		complexPopUpParams.setActionBackError(urlServiceCallKO);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setActionBackMessage(urlServiceCallOK);
		complexPopUpParams.setForward("esgCardRefresh");
		complexPopUpParams.setReturnBackMessage(true);
		forward = Utl.createComplexPopUp(complexPopUpParams);
		
		logger.debug("[EsgCardOpIssueConfirmAction - issueConfirmUpdate] ---- END ----");
		return forward;
	}
	
	public ActionForward normalizeAddress(ActionMapping mapping,
			ActionForm form,
			HttpServletRequest request,
			HttpServletResponse response) 
	throws Exception {
		
		logger.info("normalizeAddress --- start");
		EsgCardInquiryActionForm oForm = (EsgCardInquiryActionForm)form;
		
		String jsonResult = GecUtilities.afaNormalizeAddress((String) oForm.getRequestDeliveryInOut().getNormAddressUrl().getValue(),
										 (String) oForm.getRequestDeliveryInOut().getAddressChoice().getAddressRow02().getValue(),
										 (String) oForm.getRequestDeliveryInOut().getAddressChoice().getAddressRow04().getValue(),
										 (String) oForm.getRequestDeliveryInOut().getAddressChoice().getAddressRow05Cap().getValue(),
										 (String) oForm.getRequestDeliveryInOut().getAddressChoice().getAddressRow05Pv().getValue(),
										 (String) oForm.getRequestDeliveryInOut().getAddressChoice().getAddressRow05Naz().getValue());
		
		response.setHeader("Content-Type", "application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.write(jsonResult);
		out.flush();
		out.close();
		logger.info("normalizeAddress --- end");
		return null;
	}

	// EE29052 - Firmamia - stored to determine whether the print is digital
	public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
		return GecUtilities.checkStoredFirmaMia(request, response);
	}

	public boolean xpiCheck(XDocument[] module){
		UserData dataInfo;
		try {
			dataInfo = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
		} catch (ServiceFactoryException e) {
			logger.error("Error while retrieving user info ", e);
			return false;
		} catch (RemoteException e) {
			logger.error("Error while retrieving user info ", e);
			return false;
		} catch (HostUserInfoException e) {
			logger.error("Error while retrieving user info ", e);
			return false;
		}
		String filialeOperatore = dataInfo.getFilialeOperatore();
		boolean xpiPaperlessFeasibilityResult;
		try {
			xpiPaperlessFeasibilityResult = checkBranch(filialeOperatore) && checkModule(module);
		} catch (Exception e) {
			logger.error("Error when checking module and branch paperless feasibility for FirmaMia ", e);
			return false;
		}
		if(xpiPaperlessFeasibilityResult){
			logger.info("PRINTCHECK - VADO IN DIGITALE");
		} else {
			logger.info("PRINTCHECK - VADO SU CARTA");
		}
		
		return xpiPaperlessFeasibilityResult;
	}

	private boolean checkBranch(String branch) throws Exception {
		logger.info("[EsgCardInquiryAction] - [checkBranch] - START");
		String paperlessFunction = XPIConstants.PAPERLESS_CHECK_BRANCH;
		boolean risultato = false;
		try {
			SignpadInOut signpadInOut = new SignpadInOut();
			signpadInOut.getFunction().setValue(paperlessFunction);
			signpadInOut.getOperatingBranch().setValue(branch);
			SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
			risultato = signpadResponseClass.isSignpadFeasibility();
			logger.info("***************** [EsgCardInquiryAction] - [checkBranch] filialeEvoluta: " + risultato);
		} catch (Exception e) {
			throw e;
		}
		return risultato;
	}

	private boolean checkModule(XDocument[] module) throws Exception {
		logger.info("[EsgCardInquiryAction] - [checkModule] - START");
		String paperlessFunction = XPIConstants.PAPERLESS_CHECK_MODULE;
		boolean risultato = false;
		try {
			SignpadInOut signpadInOut = new SignpadInOut();
			signpadInOut.getFunction().setValue(paperlessFunction);
			signpadInOut.setXDocs(module);
			SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
			risultato = signpadResponseClass.isSignpadFeasibility();
			logger.info("***************** [EsgCardInquiryAction] - [checkModule] modulo evoluto: " + risultato);
		} catch (Exception e) {
			throw e;
		}
		return risultato;
	}
	// EE29052 - Firmamia - END
}
