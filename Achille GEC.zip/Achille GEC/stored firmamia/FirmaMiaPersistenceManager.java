/*
 * Created on Jan 11, 2011
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package it.usi.xframe.gec.bfimpl.eurosig.firmamia;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import it.usi.xframe.gec.bfimpl.general.GecPersistenceManager;
import it.usi.xframe.gec.bfimpl.holo.Util;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckInput;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOM;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOutput;
import it.usi.xframe.system.errors.XFRException;

/**
 * @author us02160
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class FirmaMiaPersistenceManager extends GecPersistenceManager {

	static Log logger = LogFactory.getLog(FirmaMiaPersistenceManager.class);
	private static FirmaMiaPersistenceManager instance = null;

	/**
	 * 
	 * @return singleton
	 */
	public static FirmaMiaPersistenceManager getInstance() {
		if (instance == null)
			instance = new FirmaMiaPersistenceManager();

		return instance;
	}
	
	public PaperlessCheckOutput retrievePaperlessCheck(PaperlessCheckInput input) throws XFRException {
		
		logger.info("[FirmaMiaPersistenceManager - GECKSFM2] --- init ---");
		
		PaperlessCheckOutput output = new PaperlessCheckOutput();
		
		Connection connection = null;
		CallableStatement callStmt = null;
		
		try {
			logger.info("[FirmaMiaPersistenceManager - GECKSFMR] preparing input for DB2C.GECKSFM2...");
			
			connection = this.getConnection();
			String sql = "CALL DB2C.GECKSFM2( ?, ?)";
			callStmt = connection.prepareCall(sql);
			
			String paramInput1 = UtilMultiChannel.addSpaceChar(input.getModulo(), 6);
			String paramInput2 = UtilMultiChannel.addZeroChar(input.getFiliale(), 5);
			String paramInput3 = UtilMultiChannel.addSpaceChar(input.getEvento(), 12);
			String paramInput4 = UtilMultiChannel.addSpaceChar(input.getProdotto(), 9);
			
			callStmt.setString(1, paramInput1+paramInput2+paramInput3+paramInput4);
			
			logger.info("input   0---------1---------2---------3");
			logger.info("length  0123456789012345678901234567890");
			logger.info("INPUT_01:" + paramInput1 + "#"); 		// LK-IN-MODULO
			logger.info("INPUT_02:" + paramInput2 + "#"); 		// LK-IN-FILIALE
			logger.info("INPUT_03:" + paramInput3 + "#"); 		// LK-IN-EVENTO ??
			logger.info("INPUT_04:" + paramInput4 + "#"); 		// LK-IN-PRODOTTO
			
			// output declaration
			callStmt.registerOutParameter(2, Types.VARCHAR);	//KCFMR-RET-RC

			
			// call stored procedure
			logger.info("[FirmaMiaPersistenceManager - GECKSFM2] calling DB2C.GECKSFM2...");
			callStmt.execute();
			
			logger.info("output   0---------1---------2---------3");
			logger.info("length   0123456789012345678901234567890");
			logger.info("OUTPUT_02:" + callStmt.getString(2) + "#"); 	
			
			String allOutput = callStmt.getString(2);
			
			Map outParam = ParserInOutSP.getOutputMap(allOutput, PaperlessCheckOM.class.getName());
			
			output = ParserInOutSP.checkRetCode(outParam, new PaperlessCheckOutput());
				
			if (output.getReturnCode() == 0l) {
				output.setFlagRetry(Util.toString(outParam.get(PaperlessCheckOM.NAME_FLAG_RETRY)));
			}
			
			logger.info("[FirmaMiaPersistenceManager - GECKSFM2] -- END --");
			return output;
			
		} catch (Exception e) {
			logger.error("[FirmaMiaPersistenceManager - GECKSFM2] error ... ", e);
			throw new XFRException(e.getMessage());
		} finally {
			try {
				if (callStmt != null) {
					callStmt.close();
					callStmt = null;
				}
				if (connection != null) {
					connection.close();
					connection = null;
				}
			} catch (Exception e) {
				logger.error("[FirmaMiaPersistenceManager - GECKSFM2] Error in finally: ", e);
			}
		}
	}

}
