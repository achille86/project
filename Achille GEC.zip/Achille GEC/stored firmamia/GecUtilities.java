package it.usi.xframe.gec.bfutil.utilities;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.MessageResources;

import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckInput;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOutput;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.barraFor.EsgBCardsListResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.barraFor.EsgBCardsListTableOut;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryResponseClass;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.normalizeAddress.NormalizeAddressRequest;
import it.usi.xframe.gec.bfutil.normalizeAddress.NormalizeAddressResponse;
import it.usi.xframe.ifg.bfutil.HostUserInfoException;
import it.usi.xframe.ifg.bfutil.IfgServiceFactory;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.system.bfutil.map.XfrEnvironmentPropertiesFactoryCacher;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.system.eservice.ServiceFactoryException;
import it.usi.xframe.system.ifutils.EnvironmentLoader;
import it.usi.xframe.system.ifutils.IEnvironment;
import it.usi.xframe.system.pfutil.struts.errors.XfrMessage;
import it.usi.xframe.system.pfutil.tags.xfr.QuickHelpTagSupport;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.DataValue;
import it.usi.xframe.utl.bfutil.GaussResponse;
import it.usi.xframe.utl.bfutil.HostResponse;
import it.usi.xframe.utl.bfutil.HostResponseMessage;
import it.usi.xframe.utl.bfutil.HostResponseParams;
import it.usi.xframe.utl.bfutil.UTLServiceFactory;
import it.usi.xframe.utl.bfutil.Utl;
import it.usi.xframe.utl.bfutil.XfrDynamicMessage;
import it.usi.xframe.utl.bfutil.XfrDynamicMessageCodeParams;
import it.usi.xframe.utl.bfutil.XlcConstantTag;
import it.usi.xframe.utl.bfutil.XlcPageField;
import it.usi.xframe.utl.bfutil.general.UTLConstants;
import it.usi.xframe.xpi.bfutil.XDocument;

/**
 * 
 * @author ee00988
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class GecUtilities {

	static Logger logger = Logger.getLogger(GecUtilities.class);
	//MESSAGE TYPE
	public static final String ST_ERROR    = "E";
	public static final String ST_EMPTY    = "N";
	public static final String ST_WARNING  = "W";
	public static final String ST_NOTIFY   = "M";
	public static final String ST_CONFIRM  = "C";
	
	public static final String Italian = "IT";
	public static final String English = "EN";
	//public static final String Czech = "CS";
	public static final String Czech = "CZ";
	public static final String German = "DE";
	
	public static final String GEC_COMBO_BUNDLE_PATH = "it.usi.xframe.gec.bfutil.resources.";
	
	public static final String GEC_PARAMETRI	= "GECKPARAMETRI";
	public static final String GEC_PARAM_KEY	= "GECEPARAM_CHIAVE";
	public static final String GEC_PARAM_VALUE	= "GECEPARAM_PARAMETRO";
	public static final String GEC_PARAM_VALID	= "GECEPARAM_VALIDO";
	public static final String GEC_PARAM_AREA	= "GECEPARAM_AREA_PARAM";
	public static final String GEC_PARAM_VALID_TRUE		= "S";
	public static final String GEC_PARAM_VALID_FALSE	= "N";
	
	public static  int MAX_ROWS_FOR_ADDRESS = 6;


	public static final String UNDERWRITINGFLAG_CACHE 	 				= "Underwriting";
	public static final String FLAG_CACHE_SEPAHVB 		 				= "IbanBicManager"; 
	public static final String FLAG_CACHE_GARANTE2 		 				= "Garante2";   
	public static final String FLAG_CACHE_POST_INT 		 				= "PostalizzazioneInterna";
	public static final String FLAG_CACHE_PRINT_ARCHIVE  				= "ArchivioStampa";
	public static final String FLAG_CACHE_ARCHIVE_MODULE 				= "ArchivioModuliStampa";
	public static final String FLAG_CACHE_INQ_MAXI 		 				= "InquiryMaxi";
	public static final String FLAG_CACHE_DIGITAL_CARD 	 				= "DigitalCard";
	public static final String FLAG_CACHE_MISSING_CONTRACT 				= "MissingContract";
	public static final String FLAG_CACHE_FIRMAMIA_SKIP_TABLET_CHECK 	= "FirmaMiaSkipTabletCheck";
	public static final String FLAG_CACHE_FIRMAMIA_SKIP_XPI_CHECK 		= "FirmaMiaSkipXpiCheck";
	public static final String FLAG_CACHE_DIGITAL_MAIL_BOX 				= "DigitalMailBox";
	public static final String FLAG_CACHE_DIGITAL_MAIL_BOX_OLD 			= "DigitalMailBoxOld";
	public static final String FLAG_CACHE_DMB_PILOT_BRANCH 				= "DMBPilotBranch";
	public static final String FLAG_CACHE_BM_CRUSCOTTO 					= "BMCruscotto";

	public static final String QHELP_JNDI = "rep/qhelp";
	public static final String URL_PROPERTY = "refURL";
	
	public static final String MSG_1500 = "GEC01500";
	public static final String MSG_1501 = "GEC01501";
	public static final String MSG_1502 = "GEC01502";
	public static final String MSG_1503 = "GEC01503";
	public static final String MSG_1509 = "GEC01509";
	public static final String MSG_1530 = "GEC01530";
	public static final String MSG_1531 = "GEC01531";
	public static final String MSG_1532 = "GEC01532";
	
	/**
	 * 
	 * @param mapping
	 * @param request
	 * @param gaussResponse
	 * @param actionBackConfirm
	 * @param actionBackError
	 * @param actionBackMessage
	 * @param actionConfirm
	 * @param errorForward
	 * @param forward
	 * @param forwardBackError
	 * @param returnBackError
	 * @param returnBackMessage
	 * @param severeError
	 * @return
	 */
	public static ActionForward createComplexPopUp(
		ActionMapping mapping,
		HttpServletRequest request,
		HostResponse hostResponse,
		String actionBackConfirm,
		String actionBackError,
		String actionBackMessage,
		String actionConfirm,
		String errorForward,
		String forward,
		boolean forwardBackError,
		boolean returnBackError,
		boolean returnBackMessage,
		boolean severeError,
		boolean fullPageMessage) throws Exception
	{
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping,request,hostResponse);
		complexPopUpParams.setActionBackConfirm(actionBackConfirm);
		complexPopUpParams.setActionBackError(actionBackError);
		complexPopUpParams.setActionBackMessage(actionBackMessage);
		complexPopUpParams.setActionConfirm(actionConfirm);
		complexPopUpParams.setErrorForward(errorForward);
		complexPopUpParams.setForward(forward);
		complexPopUpParams.setForwardBackError(forwardBackError);
		complexPopUpParams.setReturnBackError(returnBackError);
		complexPopUpParams.setReturnBackMessage(returnBackMessage);
		complexPopUpParams.setSevereError(severeError);
		complexPopUpParams.setFullPageMessage(fullPageMessage);
		
		return Utl.createComplexPopUp(complexPopUpParams);
	}
	
	/**
	 * 
	 * @param request
	 * @param attributeName
	 * @return
	 */	
	public static String getAttributeInRequest(
		HttpServletRequest request,
		String attributeName) 
		{

		String attribute;

		attribute = (String) request.getAttribute(attributeName);
		if (attribute == null)
			attribute = request.getParameter(attributeName);
		
		return attribute;
	}
	
	/**
	 * 
	 * @param dateToConvert
	 * @return
	 */
	public static java.sql.Date convertDateForDb(java.util.Date dateToConvert)
	{
		java.sql.Date dateToDb = new java.sql.Date(dateToConvert.getTime());
		return dateToDb;
	}

	/**
	 * 
	 * @param dateToConvert
	 * @return
	 */
	public static java.sql.Date convertDateForDb(Calendar dateToConvert)
	{
		java.sql.Date dateToDb = new java.sql.Date(dateToConvert.getTime().getTime());
		return dateToDb;
	}
	
	/**
	 * 
	 * @param request
	 * @param key
	 * @param messageResources
	 * @return
	 * @throws Exception
	 */
	public static String getValuefromResourceBundle(HttpServletRequest request, String key, MessageResources messageResources) throws Exception 
	{
		
		Locale locale = (Locale) request.getSession().getAttribute(Globals.LOCALE_KEY);
		String messageKey = null;
		try{
			messageKey = messageResources.getMessage(locale, key);
		}catch (MissingResourceException e){
			logger.error("GecUtilities.getValuefromResourceBundle " + e.getMessage());
			messageKey = null;
		}			
		
		return messageKey;  
	}
	
	
	

	
	


	// ********************************************* //
	// ************* MANAGE ERROR MESSAGE ********** //
	// ********************************************* //
	
	/**
	 * 
	 * @param type
	 * @return
	 */
	private static boolean isError(String type) {
		return (type.equalsIgnoreCase(ST_ERROR) ? true : false);
	}

	/**
	 * 
	 * @param type
	 * @return
	 */
	private static boolean isWarning(String type) {
		return (type.equalsIgnoreCase(ST_WARNING) ? true : false);
	}

	/**
	 * 
	 * @param type
	 * @return
	 */
	private static boolean isEmpty(String type) {
		return (type.equalsIgnoreCase(ST_EMPTY) ? true : false);
	}

	/**
	 * 
	 * @param type
	 * @return
	 */
	private static boolean isNotify(String type) {
		return (type.equalsIgnoreCase(ST_NOTIFY) ? true : false);
	}

	/**
	 * 
	 * @param type
	 * @return
	 */
	private static boolean isConfirm(String type) {
		return (type.equalsIgnoreCase(ST_CONFIRM) ? true : false);
	}

	public static HostResponse getHostResponse(String description, Object[] params, String className, String messageDetails, String type)
	{
		HostResponse hostResponse = new HostResponse();
		HostResponseMessage[] hrm = new HostResponseMessage[1];
		hrm[0] = new HostResponseMessage();
		HostResponseParams[] hrpArray;
		
		if (isError(type))
			hostResponse.setErrorFlag(true);
		else if (isEmpty(type))
			hostResponse.setEmptyFlag(true);
		else if (isWarning(type))
			hostResponse.setWarningFlag(true);
		else if (isNotify(type))
			hostResponse.setNotifyFlag(true);
		else if (isConfirm(type))
			hostResponse.setConfirmFlag(true);
		
		hrm[0].setMessage(description);
		hrm[0].setProgramName(className);
		hrm[0].setNotes(messageDetails);
		
		if (params != null)
		{
			hrpArray = new HostResponseParams[params.length];
			for (int i=0; i < params.length; i++)
			{
				HostResponseParams hrp = new HostResponseParams();
				hrp.setParam(params[i]);
				hrpArray[i] = hrp; 
			}
			hrm[0].setHostResponseParams(hrpArray);
		}
		
		hostResponse.setHostResponseMessage(hrm);		
		
		return hostResponse;
	}
	// MANAGE MODIFY
	
	public static String getEnvironmentCountry() {

		String environmentCountry = EnvironmentLoader.getDefault().get(IEnvironment.COUNTRY);
		if (environmentCountry != null && ( environmentCountry.equalsIgnoreCase("CZ") || environmentCountry.equalsIgnoreCase("CS")   ))
			environmentCountry = GecUtilities.Czech;
		return environmentCountry;

	}
	
	/**
	 * Makes an ArrayList for a combo given an ApplicationResurces bundle
	 * @param String language, ApplicationResources bundle, boolean for empty field, String emptyCode, String emptyValue
	 * 
	 * @return ArrayList
	 */
	public static ArrayList getArrayListFromResourceBundle(String language, String bundle, boolean addEmptyElement, String emptyCode, String emptyValue) {
		Locale locale = new Locale(language);
		ResourceBundle myResources = ResourceBundle.getBundle(bundle, locale);
		Enumeration myResourcesEnum = myResources.getKeys();
		ArrayList collection  = new ArrayList();

		if (addEmptyElement) { // to add an empty element
			DataValue dataValue = new DataValue();
			emptyCode = (emptyCode == null) ? " " : emptyCode;
			emptyValue = (emptyValue == null) ? "" : emptyValue;
			dataValue.setCode(emptyCode);
			dataValue.setDescription(emptyValue);
			collection.add(dataValue);
		}

		while (myResourcesEnum.hasMoreElements()) {
			String key = (String) myResourcesEnum.nextElement();
			DataValue description = new DataValue();
			description.setCode(key);
			description.setDescriptionNoUC(myResources.getString(key)); // ee13331 - rimossa la forzatura uppercase
			collection.add(description);
		}
		
		return collection;
	}
	
	/**
	 * Makes an ArrayList for a combo given an ApplicationResurces bundle
	 * @param Locale locale, ApplicationResources bundle, boolean for empty field, String emptyCode, String emptyValue
	 * 
	 * EE3415: Questo metodo � analogo a getArrayListFromResourceBundle(String language, ...) ma anzich� avere in input la lingua scelta dall'operatore
	 * prende l'intera classe Locale - che quindi non viene rigenerata all'inizio del metodo.
	 * In questo modo non vengono persi altri attributi, su tutti il codice Paese, fondamentale per le label il Austriaco (de_AT).
	 * 
	 * @return ArrayList
	 */
	public static ArrayList getArrayListFromResourceBundle(Locale locale, String bundle, boolean addEmptyElement, String emptyCode, String emptyValue) {
		ResourceBundle myResources = ResourceBundle.getBundle(bundle, locale);
		Enumeration myResourcesEnum = myResources.getKeys();
		ArrayList collection  = new ArrayList();

		if (addEmptyElement) { // to add an empty element
			DataValue dataValue = new DataValue();
			emptyCode = (emptyCode == null) ? " " : emptyCode;
			emptyValue = (emptyValue == null) ? "" : emptyValue;
			dataValue.setCode(emptyCode);
			dataValue.setDescription(emptyValue);
			collection.add(dataValue);
		}

		while (myResourcesEnum.hasMoreElements()) {
			String key = (String) myResourcesEnum.nextElement();
			DataValue description = new DataValue();
			description.setCode(key);
			description.setDescriptionNoUC(myResources.getString(key)); // ee13331 - rimossa la forzatura uppercase
			collection.add(description);
		}
		
		return collection;
	}
	
	/**
	 * @param stringToStrip
	 * @param delimiter
	 * @return
	 *
	 * stripString("00000", "0") = "";
	 * stripString("00000", "0", "0") = "0";
	 * stripString("00012", "0") = stripString("00012", "0", "0") = "12";
	*/
	public static String stripString(String stringToStrip, String delimiter, String flagDelimiter) {
		while (stringToStrip.startsWith(delimiter) && !stringToStrip.equals(flagDelimiter))
			stringToStrip = stringToStrip.substring(1, stringToStrip.length());
		return (stringToStrip);
	}
	
	
	/**
	 * Returns a string representation of the specified array of strings.
	 * Note: is derived from java.util.Arrays.deepToString(Object[] obj) of JDK 5
	 * 
	 * @param array
	 * @return
	 */
	public static String deepToString(String[] array) {
		if (array == null) {
			return null;
		}
		String result = "";
		for (int i = 0; i < array.length; i++) {
			result += (result.length() > 0) ? ", " : "";
			result += array[i];
		}
		return "[" + result + "]";
	}
	
	/**
	 * Returns a string representation of the specified ArrayList of strings.
	 * Note: is derived from java.util.Arrays.deepToString(Object[] obj) of JDK 5
	 * 
	 * @param array
	 * @return
	 */
	public static String deepToString(ArrayList array) {
		if (array == null) {
			return null;
		}
		String result = "";
		for (int i = 0; i < array.size(); i++) {
			result += (result.length() > 0) ? ", " : "";
			result += (String) array.get(i);
		}
		return "[" + result + "]";
	}
	/**
	 * Check the parameter of XDocument needed to call XPI.
	 * Project PaperLess.
	 * @author ee29570
	 * @param documents
	 */
	public static void setupXDocumentWithSignedPad(XDocument[] documents) {
		if (documents != null) {
			StringBuffer debugLog = new StringBuffer(500); 
			debugLog.append("[GecUtilities - setupXDocument]\n");

			for ( int i = 0; i < documents.length; i++ ) {
				if (documents[i] != null) {
					// E' Obbligatorio; il nome del documento fa si che,
					// in Visualizzazione Documenti elettronici, il documento risulti 
					// gratuito e senza fincatura.
					documents[i].setDocILC(documents[i].getFormName());
					// Imposto la data da lato server.
					documents[i].setDocumentDate(new Date());
					logFieldsDocumentSignedPad(documents[i]);
				}
			}
			debugLog.append("+++++++++++++++++++++++++");
			logger.info(debugLog);
		}
	}
	
	
	/**
	 * Check the parameter of XDocument needed to call XPI.
	 * Project PaperLess.
	 * @author ee29570
	 * @param documents
	 */
	public static void setupXDocumentWithArchiveFlag(XDocument[] documents) {
		logger.debug("[GecUtilities - setupXDocumentWithArchiveFlag]");
		if (documents == null) {
			logger.debug("[GecUtilities - setupXDocumentWithArchiveFlag] list is null");
			return ;
		}
		String msg = "";
		XDocument xDoc = null;
		for ( int i = 0; i < documents.length; i++ ) {
			if (documents[i] != null) {
				xDoc = documents[i];
				if (xDoc.getAbiCode()       == null ||
				    xDoc.getDocumentCode()  == null ||
					xDoc.getDocumentDate()  == null ||
					xDoc.getAccountNumber() == null ||
					xDoc.getBranch()        == null) {

					msg = "GeCa UNABLE TO CALL ARCHIVE SERVICE: One or more mandatory field is null for document " + xDoc.getFormName();
					msg += "\nxDoc.getAbiCode() is " +  xDoc.getAbiCode() != null ? xDoc.getAbiCode() : " null";
					msg += "\nxDoc.getDocumentCode() is " +  xDoc.getDocumentCode() != null ? xDoc.getDocumentCode() : " null";
					msg += "\nxDoc.getDocumentDate() is " +  xDoc.getDocumentDate() != null ? xDoc.getDocumentDate().toString() : " null";
					msg += "\nxDoc.getAccountNumber() is " +  xDoc.getAccountNumber() != null ? xDoc.getAccountNumber() : " null";
					msg += "\nxDoc.getBranch() is " +  xDoc.getBranch() != null ? xDoc.getBranch() : " null";
					logger.info(msg);
				} else {
					// Imposto il flag per l'archiviazione
					documents[i].setDocumentArchivingFlag("1");
				}
			}
		}
	}
	
	/**
	 * Log the parameters to pass to XDocument
	 * Project PaperLess.
	 * @author ee29570
	 * @param document XDocument to retrive information for log
	 */
	public static void logFieldsDocumentSignedPad(XDocument document) {
		final String[] labels = {"Branch", "AccountNumber", "DocumentCode", 
						"DocILC", "DocumentNumber2", "NDG", "DocumentDate", "AccountType"};
		StringBuffer debugLog = new StringBuffer(500); 
		if (document != null) {
			String[] values = new String[8]; 
			values[0] = document.getBranch();
			values[1] = document.getAccountNumber();
			values[2] = document.getDocumentCode();
			values[3] = document.getDocILC();
			values[4] = document.getDocumentNumber2();
			values[5] = document.getNdg();
			values[6] = document.getDocumentDate().toString();
			values[7] = document.getAccountType();
	
			for (int j = 0; j < 8; j++){
				debugLog.append(labels[j]);
				debugLog.append(" : ");
				debugLog.append(values[j]);
				debugLog.append("\n");
			}
			logger.info(debugLog);
		}
	}
	/**
		 * Create manually a GaussMessage.
		 * Project MARS.
		 * @author ee29570
		 * @param message 
		 * @param programName
		 * @param messageDetails
		 * @param params (HashMap monodim of ordered (Param - ParamType)
		 * @param type  
		 */
	public static GaussResponse makeGaussResponse(String message, String programName, String messageDetails, HostResponseParams[] params, String type) {
			
		GaussResponse gaussResponse = new GaussResponse();
			
		if (isError(type))
			gaussResponse.setErrorFlag(true);
		else if (isEmpty(type))
			gaussResponse.setEmptyFlag(true);
		else if (isWarning(type))
			gaussResponse.setWarningFlag(true);
		else if (isNotify(type))
			gaussResponse.setNotifyFlag(true);
		else if (isConfirm(type))
			gaussResponse.setConfirmFlag(true);
			
			
		HostResponseMessage[] hostResponseMessages = new HostResponseMessage[1];

		HostResponseMessage hostMessage = new HostResponseMessage(); 
		
		hostMessage.setMessage(message);
		hostMessage.setProgramName(programName);
		hostMessage.setNotes(messageDetails);
		
		if (params != null) {
			hostMessage.setHostResponseParams(params);
		}
		
		hostResponseMessages[0] = hostMessage;
		
		gaussResponse.setHostResponseMessage(hostResponseMessages);		
		
		return gaussResponse;
	}
	/**
	 * Decode html simbol in html format1
	 * @author ee29570
	 * @param string
	 * @return
	 */
	public static String escapeHtml(Object string) {
		if (string != null){
			return escapeHtml(string.toString());
		}
		return "";
	}
	
	/**
	 * Decode html simbol in html format
	 * @author ee29570
	 * @param string
	 * @return
	 */
	public static String escapeHtml(String string) {
		if (string == null) {
			return "";
		}
		StringBuffer result = new StringBuffer(string.length() * 4);
		for (int i = 0; i < string.length(); i++) {
			char current = string.charAt(i);
			switch (current) {
				case '&' : result.append("&amp;");  break;
				case '"' : result.append("&quot;"); break;
				case '>' : result.append("&gt;");   break;
				case '<' : result.append("&lt;");   break;
				case '\'': result.append("&#39;");  break;
				default :  result.append(current); 	break;
			}
		}
		return result.toString();
	}

	/**
	 * Returns a single parameter from table GECKPARAMETRI if exists; otherwise return null
	 * 
	 * @param key the name of the key in GECKPARAMETRI (GECEPARAM_CHIAVE)
	 * @param param the name of the parameter in GECKPARAMETRI (GECEPARAM_PARAMETRO)
	 * @param area the area of the parameter in GECKPARAMETRI (GECEPARAM_AREA_PARAM)
	 * @param valid if valid is true then find GEC_PARAM_VALID_TRUE("S"), else GEC_PARAM_VALID_FALSE("N") in GECKPARAMETRI (GECEPARAM_VALIDO)
	 * @return TRUE if the parameter exists, null otherwise; 
	 */
	public static boolean isGecParameterSet(String key, String param, String area, boolean valid) {
		HashMap whereClause = new HashMap();
		whereClause.put(GecUtilities.GEC_PARAM_KEY, "'" + key + "'");
		whereClause.put(GecUtilities.GEC_PARAM_VALUE, "'" + param + "'");
		whereClause.put(GecUtilities.GEC_PARAM_AREA, "'" + area + "'");
		whereClause.put(GecUtilities.GEC_PARAM_VALID, "'" + ((valid)? GEC_PARAM_VALID_TRUE : GEC_PARAM_VALID_FALSE) + "'");
		HashMap result = null;
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			result = serviceF.retrieveTableRecord("DB2C", GEC_PARAMETRI, whereClause, null, false);
		} catch(Exception e) {
			logger.error("[GecWebUtilities - retrievePrintMode] error while retrieving data value: " + e.getMessage());
		} finally {
			if (serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		return (result != null && result.size() > 0 && result.containsKey("values"));
	}
	
	/**
	 * Returns a single parameter from table GECKPARAMETRI if exists; otherwise return null
	 * 
	 * @param key the name of the key in GECKPARAMETRI (GECEPARAM_CHIAVE)
	 * @param param the name of the parameter in GECKPARAMETRI (GECEPARAM_PARAMETRO)
	 * @param valid if valid is true then find GEC_PARAM_VALID_TRUE("S"), else GEC_PARAM_VALID_FALSE("N") in GECKPARAMETRI (GECEPARAM_VALIDO)
	 * @return TRUE if the parameter exists, null otherwise; 
	 */
	public static boolean isGecParameterSet(String key, String param, boolean valid) {
		HashMap whereClause = new HashMap();
		whereClause.put(GecUtilities.GEC_PARAM_KEY, "'" + key + "'");
		whereClause.put(GecUtilities.GEC_PARAM_VALUE, "'" + param + "'");
		whereClause.put(GecUtilities.GEC_PARAM_VALID, "'" + ((valid)? GEC_PARAM_VALID_TRUE : GEC_PARAM_VALID_FALSE) + "'");
		HashMap result = null;
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			result = serviceF.retrieveTableRecord("DB2C", GEC_PARAMETRI, whereClause, null, false);
		} catch(Exception e) {
			logger.error("[GecWebUtilities - isGecParameterSet] error while retrieving data value: " + e.getMessage());
		} finally {
			if (serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		return (result != null && result.size() > 0 && result.containsKey("values"));
	}
	
	/**
	 * Returns a single parameter from table GECKPARAMETRI if exists; otherwise return null
	 * 
	 * @param key the name of the key in GECKPARAMETRI (GECEPARAM_CHIAVE)
	 * @param param the name of the parameter in GECKPARAMETRI (GECEPARAM_PARAMETRO)
	 * @return String of AreaParametro; 
	 */
	public static String getGecParameterArea(String key, String param) {
		String result = null;
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			result = serviceF.retrieveParameter(param, key);
		} catch(Exception e) {
			logger.error("[GecWebUtilities - getGecParameterArea] error while retrieving data value: " + e.getMessage());
		} finally {
			if (serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		return result;
	}

	/**
	 * if the parameter is cached, retrive the value from cache, else return a single parameter 
	 * from table GECKPARAMETRI if exists and save the object in cache; otherwise return null;
	 * @param paramFlag the parameter name to retrive
	 * @param key the name of the key in GECKPARAMETRI (GECEPARAM_CHIAVE)
	 * @param param the name of the parameter in GECKPARAMETRI (GECEPARAM_PARAMETRO)
	 * @param area the area of the parameter in GECKPARAMETRI (GECEPARAM_AREA_PARAM)
	 * @author ee29570
	 * @return GEC_PARAM_VALID_TRUE if the flag is enabled, GEC_PARAM_VALID_FALSE otherwise
	*/
	public static String retriveParameterChached(String paramFlag, String key, String param, String area) {
		String flag = GEC_PARAM_VALID_FALSE;
		try {
			GecMessageCacher cacher = GecMessageCacher.getInstance();
			Object UWflag = cacher.getFromCache(paramFlag);
			if (UWflag != null) {
				 flag = UWflag.toString();
			} else { 
				 flag = (isGecParameterSet(key, param, area, true))? GEC_PARAM_VALID_TRUE : GEC_PARAM_VALID_FALSE;
				 cacher.addToCache(paramFlag, flag);
			}
		} catch(Exception e) {
			logger.error("[GecWebUtilities - retriveParameterChached] error while retrieving data value: " + e.getMessage());
		}
		return flag;
	}
	
	/**
	 * if the parameter is cached, retrive the value from cache, else return a single parameter 
	 * from table GECKPARAMETRI if exists and save the object in cache; otherwise return null;
	 * @param paramFlag the parameter name to retrive
	 * @param key the name of the key in GECKPARAMETRI (GECEPARAM_CHIAVE)
	 * @param param the name of the parameter in GECKPARAMETRI (GECEPARAM_PARAMETRO)
	 * @author ee29570
	 * @return GEC_PARAM_VALID_TRUE if the flag is enabled, GEC_PARAM_VALID_FALSE otherwise
	*/
	public static String retriveParameterChached(String paramFlag, String key, String param) {
		String flag = GEC_PARAM_VALID_FALSE;
		try {
			GecMessageCacher cacher = GecMessageCacher.getInstance();
			Object UWflag = cacher.getFromCache(paramFlag);
			if (UWflag != null) {
				 flag = UWflag.toString();
			} else { 
				 flag = (isGecParameterSet(key, param, true))? GEC_PARAM_VALID_TRUE : GEC_PARAM_VALID_FALSE;
				 cacher.addToCache(paramFlag, flag);
			}
		} catch(Exception e) {
			logger.error("[GecWebUtilities - retriveParameterChached] error while retrieving data value: " + e.getMessage());
		}
		return flag;
	}

	/**
	 * if the parameter is cached, retrive the value from cache, else return a single parameter 
	 * from table GECKPARAMETRI if exists and save the object in cache; otherwise return null;
	 * @param paramFlag the parameter name to retrive
	 * @param key the name of the key in GECKPARAMETRI (GECEPARAM_CHIAVE)
	 * @param param the name of the parameter in GECKPARAMETRI (GECEPARAM_PARAMETRO)
	 * @param area the area of the parameter in GECKPARAMETRI (GECEPARAM_AREA_PARAM)
	 * @author ee29570
	 * @return GEC_PARAM_VALID_TRUE if the flag is enabled, GEC_PARAM_VALID_FALSE otherwise
	*/
	public static String retriveParameterAreaChached(String paramFlag, String key, String param) {
		String value = "";
		try {
			GecMessageCacher cacher = GecMessageCacher.getInstance();
			Object UWflag = cacher.getFromCache(paramFlag);
			if (UWflag != null) {
				 value = UWflag.toString();
			} else { 
				 value = getGecParameterArea(key, param);
				 cacher.addToCache(paramFlag, value);
			}
		} catch(Exception e) {
			logger.error("[GecWebUtilities - retriveParameterChached] error while retrieving data value: " + e.getMessage());
		}
		return value;
	}
	
	/**
	 * it checks if for the parameter is enabled into specified table;
	 * @author ee29570
	 * #Project MARS
	 * @return true if is enables flag to display UWManager
	*/
	public static boolean isCommittedCreditLineSet() {
		HashMap whereClause = new HashMap();
		whereClause.put(GecUtilities.GEC_PARAM_KEY, "'PJ132011'");
		whereClause.put(GecUtilities.GEC_PARAM_VALUE, "'DEVELOP'");
		whereClause.put(GecUtilities.GEC_PARAM_AREA, "'MARS'");
		whereClause.put(GecUtilities.GEC_PARAM_VALID, "'S'");
		HashMap result = null;
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			result = serviceF.retrieveTableRecord("DB2C", GEC_PARAMETRI, whereClause, null, false);
		} catch(Exception e) {
			logger.error("[GecWebUtilities - retrievePrintMode] error while retrieving print mode...");
			e.printStackTrace();
		} finally {
			if (serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		return (result != null && result.size() > 0 && result.containsKey("values"));
	}
	
	/**
	 * it checks if the parameter "SEPA-HVB" is enabled into GECKPARAMETRI table;
	 * @author ee29570
	 * #Project SEPA-HVB
	 * @return true if FLAG_CACHE_SEPAHVB is enabled
	*/
	public static boolean isIbanBicManagerSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_SEPAHVB, "SEPA-HVB", "DEVELOP", "SEPA-HVB"); 
		logger.debug("[GecWebUtilities:isIbanBicManagerSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "MAXI" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_INQ_MAXI is enabled
	*/
	public static boolean isInquiryMaxiSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_INQ_MAXI, "MAXI", "DEVELOP", "Y"); 
		logger.debug("[GecWebUtilities:isInquiryMaxiSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "DIGITALCARD" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_DIGITAL_CARD is enabled
	*/
	public static boolean isDigitalCardSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_DIGITAL_CARD, "DIGITALCARD", "DEVELOP", "Y"); 
		logger.debug("[GecWebUtilities:isDigitalCardSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "MISSING_CONTRACT" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_MISSING_CONTRACT is enabled
	*/
	public static boolean isMissingContractSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_MISSING_CONTRACT, "MISSING_CONTRACT", "DEVELOP"); 
		logger.debug("[GecWebUtilities:isDigitalCardSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "DIGITAL_MAIL_BOX" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_DIGITAL_MAIL_BOX is enabled
	*/
	public static boolean isDigitalMailBoxSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_DIGITAL_MAIL_BOX, "DIGITAL_MAIL_BOX", "DEVELOP", "Y"); 
		logger.debug("[GecWebUtilities:isDigitalMailBoxSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "DIGITAL_MAIL_BOXOLD" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_DIGITAL_MAIL_BOX_OLD is enabled
	*/
	public static boolean isDigitalMailBoxOldSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_DIGITAL_MAIL_BOX_OLD, "DIGITAL_MAIL_BOXOLD", "DEVELOP", "Y"); 
		logger.debug("[GecWebUtilities:isDigitalMailBoxOldSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "DIGITALMAILBOX" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_DMB_PILOT_BRANCH is enabled
	*/
	public static boolean isDmbPilotBranchSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_DMB_PILOT_BRANCH, "DIGITALMAILBOX", "FILPILOT"); 
		logger.debug("[GecWebUtilities:isDmbPilotBranchSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "DIGITALMAILBOX" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_DMB_PILOT_BRANCH is enabled
	*/
	public static boolean isBMCruscottoSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_BM_CRUSCOTTO, "CRUSCOTTO", "DEVELOP", "Y"); 
		logger.debug("[GecWebUtilities:isDmbCruscottoSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "FORZATURA_TABLET" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_FIRMAMIA_SKIP_TABLET_CHECK is enabled
	*/
	public static boolean isFirmaMiaSkipTabletCheckSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_FIRMAMIA_SKIP_TABLET_CHECK, "FORZATURA_TABLET", "FIRMAMIA"); 
		logger.debug("[GecWebUtilities:isFirmaMiaSkipTabletCheckSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "FORZATURA_XPI" is enabled into GECKPARAMETRI table;
	 * @author EE55826
	 * @return true if FLAG_CACHE_FIRMAMIA_SKIP_XPI_CHECK is enabled
	*/
	public static boolean isFirmaMiaSkipXpiCheckSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_FIRMAMIA_SKIP_XPI_CHECK, "FORZATURA_XPI", "FIRMAMIA"); 
		logger.debug("[GecWebUtilities:isFirmaMiaSkipXpiCheckSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "GARANTE2" is enabled into GECKPARAMETRI table;
	 * @author ee29570
	 * #Project GARANTE2
	 * @return true if FLAG_CACHE_GARANTE2 is enabled
	*/
	public static boolean isGarante2Set() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_GARANTE2, "GARANTE2", "DEVELOP", "GARANTE2"); 
		logger.debug("[GecWebUtilities:isGarante2Set] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	
	/**
	 * it checks if the parameter "POST_INT2013" is enabled into GECKPARAMETRI table;
	 * @author ee29570
	 * #Project Postalizzazione Interna
	 * @return true if FLAG_CACHE_POST_INT is enabled
	*/
	public static boolean isPostIntSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_POST_INT, "POST_INT2013", "DEVELOP", "POST_INT2013"); 
		logger.debug("[GecWebUtilities:isPostIntSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "PRINT_ARCHIVE" is enabled into GECKPARAMETRI table;
	 * @author ee29570
	 * #Project Archivazione della Stampa
	 * @return true if FLAG_CACHE_PRINT_ARCHIVE is enabled
	*/
	public static boolean isPrintArchiveSet() {
		String flag = (String)retriveParameterChached(FLAG_CACHE_PRINT_ARCHIVE, "PRINT_ARCHIVE", "DEVELOP", "PRINT_ARCHIVE"); 
		logger.debug("[GecWebUtilities:isPrintArchiveSet] Parameter : " + flag);
		return flag != null && GEC_PARAM_VALID_TRUE.equals(flag);
	}
	
	/**
	 * it checks if the parameter "PRINT_ARCHIVE_MOD" is enabled into GECKPARAMETRI table;
	 * @author ee29570
	 * #Project Archivazione della Stampa
	 * @return true if Module is containt into Area Parameter
	*/
	public static boolean getPrintArchiveSet(String module) {
		if (module == null || module.length() == 0){
			return false;
		}
		String value = retriveParameterAreaChached(FLAG_CACHE_ARCHIVE_MODULE, "PRINT_ARCHIVE_MOD", "DEVELOP");
		boolean flag = (value == null || value.length() == 0)? false : (value.indexOf(module)) >= 0;
		logger.debug("[GecWebUtilities:getPrintArchiveSet] Parameter : " + value + " : " + flag);
		return flag;
	}
	
	/**
	 * Insert into request of page the developer flag
	 * @author ee29570
	 * @param request HttpRequest to insert the developer flag
	 * 
	*/
	public static void setDevelopFlag(HttpServletRequest request) {
		if (request == null) {
			logger.debug("[GecWebUtilities:setDevelopFlag] request is NULL !!! ");
			return;
		}
		//	Progetto HVB SEPA - IBAN/BIC Man. (July 2013) - ee29570
		if (EsgCountryCode.isGermanCountry() ){ 
			// TODO : IBAN/BIC Man. EE29570 - Remove this control after enabled in production
			// Inserisco il controllo del flag per la linea di credito in Germania
			if (GecUtilities.isIbanBicManagerSet()){
				request.setAttribute(GecUtilities.FLAG_CACHE_SEPAHVB, GecUtilities.GEC_PARAM_VALID_TRUE);
				logger.debug("[GecWebUtilities:setDevelopFlag]IBAN-BIC Manager Flag : TRUE ");
			} else {
				logger.debug("[GecWebUtilities:setDevelopFlag]IBAN-BIC Manager Flag : FALSE");
			}
		}
		
		//Flag di visualizzazione dati Linea Premium
		if (GecUtilities.isInquiryMaxiSet()){
			request.setAttribute(GecUtilities.FLAG_CACHE_INQ_MAXI, GecUtilities.GEC_PARAM_VALID_TRUE);
			logger.debug("[GecWebUtilities:setDevelopFlag]Inquiry Maxi Flag : TRUE ");
		} else {
			logger.debug("[GecWebUtilities:setDevelopFlag]Inquiry Maxi Flag : FALSE");
		}
		
		//Flag di visualizzazione Supporto Plastico
		if (GecUtilities.isDigitalCardSet()){
			request.setAttribute(GecUtilities.FLAG_CACHE_DIGITAL_CARD, GecUtilities.GEC_PARAM_VALID_TRUE);
			logger.debug("[GecWebUtilities:setDevelopFlag]Digital Card Flag : TRUE ");
		} else {
			logger.debug("[GecWebUtilities:setDevelopFlag]Digital Card Flag : FALSE");
		}
		
		//Flag di visualizzazione Ristampa contratto
		if (GecUtilities.isMissingContractSet()){
			request.setAttribute(GecUtilities.FLAG_CACHE_MISSING_CONTRACT, GecUtilities.GEC_PARAM_VALID_TRUE);
			logger.debug("[GecWebUtilities:setDevelopFlag]Missing Contract Flag : TRUE ");
		} else {
			logger.debug("[GecWebUtilities:setDevelopFlag]Missing Contract Flag : FALSE");
		}
		
		//Flag per Digital Mail Box
		if (GecUtilities.isDigitalMailBoxSet()){
			request.setAttribute(GecUtilities.FLAG_CACHE_DIGITAL_MAIL_BOX, GecUtilities.GEC_PARAM_VALID_TRUE);
			logger.debug("[GecWebUtilities:setDevelopFlag]Digital Mail Box Flag : TRUE ");
		} else {
			logger.debug("[GecWebUtilities:setDevelopFlag]Digital Mail Box Flag : FALSE");
		}
		
		//Flag per Pilot Branch DMB
		if (GecUtilities.isDmbPilotBranchSet()){
			request.setAttribute(GecUtilities.FLAG_CACHE_DMB_PILOT_BRANCH, GecUtilities.GEC_PARAM_VALID_TRUE);
			logger.debug("[GecWebUtilities:setDevelopFlag]Pilot Branch DMB Flag : TRUE ");
		} else {
			logger.debug("[GecWebUtilities:setDevelopFlag]Pilot Branch DMB Flag : FALSE");
		}
		
	}
	
	public static ActionForward createCustomComplexPopUp(ComplexPopUpParams complexPopUpParams) throws Exception 
	{
		String[] arrayString = new String[1];
		arrayString[0] = "";
		HostResponse hostResponse = complexPopUpParams.getHostResponse();
		
		logger.debug("createComplexPopUp - START");

		String mes="Attenzione il duplicato carta che stai richiedendo avr� l'obbligo dell'utilizzo con PIN per confermare le transazioni sui terminali POS."+
		"Chiedi al Cliente se � in possesso della busta PIN, in caso contrario procedi, prima alla selezione  rigenerazione PIN e, una volta confermata, alla richiesta del duplicato selezionando la relativa opzione."+
		"Nel caso in cui si scelga fin da subito l'opzione duplicato (e la si confermi), la richiesta di rigenerazione PIN potr� essere effettuata solo dopo l'attivazione del duplicato";

		if (hostResponse != null) //Check if there are a messages
		{
			logger.debug("createComplexPopUp - 1");
			String[] arrayResponse = hostResponse.getResponseMessage(); //Array that contains all messages withoput params (old version)
			String details = mes; //possible details
			XfrDynamicMessageCodeParams[] xfrDynamicMessageCodeParams = new XfrDynamicMessageCodeParams[hostResponse.getHostResponseMessage().length]; //New implementation  
			
			//Create message for old implementation
			for (int i=0; i < arrayResponse.length; i++)
				arrayString[0] = arrayString[0] + arrayResponse[i] + "<br>";
			
			for (int i = 0; i < hostResponse.getHostResponseMessage().length; i++) //Create message
			{			
				logger.debug("createComplexPopUp - 2 " + i);
				Object[] objParam;
				String detail = "";
				String progName = "";
				String notes = "";
				String currentDate = "";
				String userId = "";
				String messageCode = "";
				if (hostResponse.getHostResponseMessage()[i] != null)
				{
					//Check for params
					if (hostResponse.getHostResponseMessage()[i].getHostResponseParams() != null)
					{
						objParam = new Object[hostResponse.getHostResponseMessage()[i].getHostResponseParams().length];
						for (int j = 0; j < hostResponse.getHostResponseMessage()[i].getHostResponseParams().length; j++)
							objParam[j] =  hostResponse.getHostResponseMessage()[i].getHostResponseParams()[j].getParam();
							
					}
					else
						objParam = null;
					
					//Check for notes
					progName = hostResponse.getHostResponseMessage()[i].getProgramName();
					notes = hostResponse.getHostResponseMessage()[i].getNotes();
					userId = complexPopUpParams.getRequest().getUserPrincipal().toString();
					Calendar cal = Calendar.getInstance();
					currentDate = cal.getTime().toString();
					messageCode = hostResponse.getHostResponseMessage()[i].getMessage();			
					detail = ((progName!=null)?progName.trim():"")  + ": " + ((notes!=null)?notes.trim():"");
					if (!detail.trim().equals(":"))
						details += currentDate + ": User -"+userId+"- have a message code -" + messageCode + "- in program: " + detail + "\n"; 
						
					//Set new message										
					xfrDynamicMessageCodeParams[i] = new XfrDynamicMessageCodeParams(); 
					xfrDynamicMessageCodeParams[i].setCode(hostResponse.getHostResponseMessage()[i].getMessage());
					// to test
					//xfrDynamicMessageCodeParams[i].setCode("GEC00592");
					// end test
					xfrDynamicMessageCodeParams[i].setDescription(hostResponse.getHostResponseMessage()[i].getDescription());
					
					// to test
					xfrDynamicMessageCodeParams[i].setDescription(mes);
					// end test
					
					xfrDynamicMessageCodeParams[i].setParams(objParam);
					//xfrDynamicMessageCodeParams[i].setQHelpURL(getQHelpURL(complexPopUpParams, messageCode, hostResponse.getFlagCode()));
					
					logger.debug("createComplexPopUp - 3 " + xfrDynamicMessageCodeParams[i].getQHelpURL());
				}
				else
				{
					xfrDynamicMessageCodeParams[i] = new XfrDynamicMessageCodeParams(); 
					xfrDynamicMessageCodeParams[i].setCode("");
					xfrDynamicMessageCodeParams[i].setParams(null);
				}
			}

			if (details.trim().equals(""))
				details = null;
			
			if (hostResponse.isNotifyFlag()) //For notify (information message)
			{
				if (complexPopUpParams.isFullPageMessage())
				{
					logger.debug("createComplexPopUp - isNotifyFlag.isFullPageMessage");
					//OLD
					complexPopUpParams.getRequest().setAttribute("errorMessage", arrayString[0]);
					//NEW
					complexPopUpParams.getRequest().setAttribute("dynamicErrorMessage", xfrDynamicMessageCodeParams);
					
					//Set details
					complexPopUpParams.getRequest().setAttribute("messageDetails", details);
		
					logger.debug("createComplexPopUp - END generalMessage");
					return complexPopUpParams.getMapping().findForward("generalMessage");
				}
				else
				{
					logger.debug("createComplexPopUp - isNotifyFlag");
					//OLD
					XfrMessage.showInformationMessage(complexPopUpParams.getRequest(), "general.message.text", arrayString, null, complexPopUpParams.getActionOkNotify());
					//NEW
					XfrDynamicMessage.showInformationMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, complexPopUpParams.getActionOkNotify());
					if (complexPopUpParams.isReturnBackMessage()){
						logger.debug("createComplexPopUp - END ActionBackMessage");
						return new ActionForward(complexPopUpParams.getActionBackMessage());
					}
				}
			}
/*			else if (hostResponse.isWarningFlag()) //For warning (warning message)
			{
				if (complexPopUpParams.isFullPageMessage())
				{
					logger.debug("createComplexPopUp - isWarningFlag.isFullPageMessage");
					//OLD
					complexPopUpParams.getRequest().setAttribute("errorMessage", arrayString[0]);
					//NEW
					complexPopUpParams.getRequest().setAttribute("dynamicErrorMessage", xfrDynamicMessageCodeParams);
					
					//Set details
					complexPopUpParams.getRequest().setAttribute("messageDetails", details);

					logger.debug("createComplexPopUp - END generalWarning");
					return complexPopUpParams.getMapping().findForward("generalWarning");
				}
				else
				{
					logger.debug("createComplexPopUp - isWarningFlag");
					//OLD
					XfrMessage.showWarningMessage(complexPopUpParams.getRequest(), "general.message.text", arrayString, null, complexPopUpParams.getActionOkWarning());
					//NEW
					XfrDynamicMessage.showWarningMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, complexPopUpParams.getActionOkWarning());
				}
			}*/
			else if (hostResponse.isWarningFlag()) //For custom warning (with confirmation message)
			{
				logger.debug("createComplexPopUp - isConfirmFlag");
				if (complexPopUpParams.getActionConfirm() != null)
					if (!complexPopUpParams.getActionConfirm().equals(""))
					{
						logger.debug("createComplexPopUp - isConfirmFlag 1");
						GecMessage.showWarningConfirmationMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, complexPopUpParams.getActionConfirm(), complexPopUpParams.getActionBackConfirm() );
					}
					else
					{
						logger.debug("createComplexPopUp - isConfirmFlag 2");
						GecMessage.showWarningConfirmationMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, null, complexPopUpParams.getActionBackConfirm() );
					}
				else
				{
					logger.debug("createComplexPopUp - isConfirmFlag 3");
					GecMessage.showWarningConfirmationMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, null, complexPopUpParams.getActionBackConfirm() );
				}
			}
			else if (hostResponse.isConfirmFlag()) //For confirm (confirmation message)
			{
				logger.debug("createComplexPopUp - isConfirmFlag");
				if (complexPopUpParams.getActionConfirm() != null)
					if (!complexPopUpParams.getActionConfirm().equals(""))
					{
						logger.debug("createComplexPopUp - isConfirmFlag 1");
						//OLD
						XfrMessage.showConfirmationMessage(complexPopUpParams.getRequest(), "general.message.text", arrayString, null, complexPopUpParams.getActionConfirm(), complexPopUpParams.getActionBackConfirm() );
						//NEW
						XfrDynamicMessage.showConfirmationMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, complexPopUpParams.getActionConfirm(), complexPopUpParams.getActionBackConfirm() );
					}
					else
					{
						logger.debug("createComplexPopUp - isConfirmFlag 2");
						//OLD
						XfrMessage.showConfirmationMessage(complexPopUpParams.getRequest(), "general.message.text", arrayString, null, null, complexPopUpParams.getActionBackConfirm() );
						//NEW
						XfrDynamicMessage.showConfirmationMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, null, complexPopUpParams.getActionBackConfirm() );
					}
				else
				{
					logger.debug("createComplexPopUp - isConfirmFlag 3");
					//OLD
					XfrMessage.showConfirmationMessage(complexPopUpParams.getRequest(), "general.message.text", arrayString, null, null, complexPopUpParams.getActionBackConfirm() );
					//NEW
					XfrDynamicMessage.showConfirmationMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, null, complexPopUpParams.getActionBackConfirm() );
				}
			}
			else if (hostResponse.isErrorFlag()) //For error (error message)
			{
				if (complexPopUpParams.isSevereError())
				{
					logger.debug("createComplexPopUp - isErrorFlag.isSevereError");
					//OLD
					complexPopUpParams.getRequest().setAttribute("errorMessage", arrayString[0]);
					//NEW
					complexPopUpParams.getRequest().setAttribute("dynamicErrorMessage", xfrDynamicMessageCodeParams);
					
					//Set details
					complexPopUpParams.getRequest().setAttribute("messageDetails", details);
					
					logger.debug("createComplexPopUp - END generalError");
					return complexPopUpParams.getMapping().findForward("generalError");
				}
				else
				{
					logger.debug("createComplexPopUp - isErrorFlag");
					//OLD
					XfrMessage.showErrorMessage(complexPopUpParams.getRequest(), "general.message.text", arrayString, null, complexPopUpParams.getActionOkError());
					//NEW
					XfrDynamicMessage.showErrorMessage(complexPopUpParams.getRequest(), xfrDynamicMessageCodeParams, details, complexPopUpParams.getActionOkError());
					
					if (complexPopUpParams.isReturnBackError()) { //Action back error
						logger.debug("createComplexPopUp - END Action back error");
						return new ActionForward(complexPopUpParams.getActionBackError());
					} else if (complexPopUpParams.isForwardBackError()) { //Forward back error
						logger.debug("createComplexPopUp - END Forward back error");
						return complexPopUpParams.getMapping().findForward(complexPopUpParams.getErrorForward());
					}
				}
			}
			
		}
		
		logger.debug("createComplexPopUp - END");
		
		return complexPopUpParams.getMapping().findForward(complexPopUpParams.getForward());
	}	
	
	private static String getQHelpURL(ComplexPopUpParams complexPopUpParams, String messageCode, String messageType){

		String qhelp_url = "";

		if (messageCode != null && messageCode.length() == 8){
			String isQuicklyOnMessageActive = "";
			String QuicklyMessageTypeList = "";
			String QuicklyInclusionList = "";
			String QuicklyExclusionList = "";
			String applicationCode = messageCode.substring(0, 3);
		
			try {
				isQuicklyOnMessageActive = UTLServiceFactory.getInstance().getUTLServiceFacade().getUTLProperty(UTLConstants.QUICKLY_HELP_ON_MESSAGE_ACTIVE);
			} catch (Exception e1) {
				logger.error(e1.getMessage());
			}
		
			try {
				QuicklyMessageTypeList = UTLServiceFactory.getInstance().getUTLServiceFacade().getUTLProperty(UTLConstants.QUICKLY_HELP_ON_MESSAGE_TYPELIST);
			} catch (Exception e1) {
				logger.error(e1.getMessage());
			}
		
			try {
				QuicklyInclusionList = UTLServiceFactory.getInstance().getUTLServiceFacade().getUTLProperty(UTLConstants.QUICKLY_HELP_ON_MESSAGE_INCLUSIONLIST);
			} catch (Exception e1) {
				logger.error(e1.getMessage());
			}
		
			try {
				QuicklyExclusionList = UTLServiceFactory.getInstance().getUTLServiceFacade().getUTLProperty(UTLConstants.QUICKLY_HELP_ON_MESSAGE_EXCLUSIONLIST);
			} catch (Exception e1) {
				logger.error(e1.getMessage());
			}

			if (isQuicklyOnMessageActive == null) isQuicklyOnMessageActive = "false";
			if (QuicklyMessageTypeList == null) QuicklyMessageTypeList = "";
			if (QuicklyInclusionList == null) QuicklyInclusionList = "";
			if (QuicklyExclusionList == null) QuicklyExclusionList = "";

			logger.debug("isQuicklyOnMessageActive [" + ("true".equalsIgnoreCase(isQuicklyOnMessageActive)) + "]");
			logger.debug("isInMessageTypeList      [" + (QuicklyMessageTypeList.indexOf(messageType+"+") != -1) + "]");
			logger.debug("isInInclusionList        [" + (QuicklyInclusionList.indexOf(applicationCode) != -1 || "".equals(QuicklyInclusionList)) + "]");
			logger.debug("isNotInExclusionList     [" + (QuicklyExclusionList.indexOf(applicationCode) == -1) + "]");

			if (("true".equalsIgnoreCase(isQuicklyOnMessageActive)) &&
				(QuicklyMessageTypeList.indexOf(messageType+"+") != -1) &&
				(QuicklyInclusionList.indexOf(applicationCode) != -1 || "".equals(QuicklyInclusionList)) &&
				(QuicklyExclusionList.indexOf(applicationCode) == -1)){
				String qkb = applicationCode; 
				String qcase = messageCode;
				
				String principal = complexPopUpParams.getRequest().getUserPrincipal().getName();
					
				try {
					String base_url = (String) ((HashMap)XfrEnvironmentPropertiesFactoryCacher.getInstance().getResources(QHELP_JNDI)).get(URL_PROPERTY);
			
					Locale currentLocale = (Locale) (complexPopUpParams.getRequest().getSession().getAttribute(Globals.LOCALE_KEY));
					String encoding = complexPopUpParams.getRequest().getCharacterEncoding();
			
					qhelp_url = QuickHelpTagSupport.getInstance().retrieveUrl(base_url, principal, currentLocale, qcase, qkb, encoding);
				} catch (Exception e2) {
					try {
						String QuicklyDefaultUrl = UTLServiceFactory.getInstance().getUTLServiceFacade().getUTLProperty(UTLConstants.QUICKLY_NOTFOUND_ERR_URL);

						logger.debug("QuicklyDefaultUrl [" + QuicklyDefaultUrl + "]");
				
						if (QuicklyDefaultUrl != null && !"".equals(QuicklyDefaultUrl)){
							QuicklyDefaultUrl = strReplace(QuicklyDefaultUrl, "[userId]",          principal);
							QuicklyDefaultUrl = strReplace(QuicklyDefaultUrl, "[messageCode]",     messageCode);
							QuicklyDefaultUrl = strReplace(QuicklyDefaultUrl, "[applicationCode]", applicationCode);
				
							logger.debug("QuicklyDefaultUrl [" + QuicklyDefaultUrl + "]");
				
							qhelp_url = QuicklyDefaultUrl;			
						} else {
							logger.error("QuicklyDefaultUrl NOT FOUND!");
						}
					} catch (Exception e3) {
						logger.error(e3.getMessage());
					}
				}
			}
		}
			
		return qhelp_url;	
	}
	/**
	 * "Safe" string replacement (same to String.ReplaceAll() but "safer").
	 * 
	 * @param source		the input string (to change)
	 * @param regex			the regular expression to which the input string is to be matched
	 * @param replacement	the string to use for substitution
	 * @return 				the resulting string 
	 */
	public static String strReplace(String source, String regex, String replacement) {

		if (source==null)		return "";
		if (regex==null)		return source;
		if (replacement==null)	return source;

		String ret = source;
		String app;
		int i = ret.indexOf(regex);
		
		while (i >= 0 && i < ret.length()) {
			app = ret.substring(0,i);
			app += replacement;
			app += ret.substring(i+regex.length()); 
			ret = app;
			i = ret.indexOf(regex);
		}

		return ret;
	}
	
    public static void printStackTrace(Throwable e)
	{
		StackTraceElement[] stackTrace = e.getStackTrace();
		logger.info(Arrays.asList(stackTrace).getClass());
		List stackTraces = (List) Arrays.asList(stackTrace);
		StringBuffer errorBuffer = new StringBuffer();
		errorBuffer.append("ERRORE GEC\n");
		errorBuffer.append(e.getMessage() + "\n");
		errorBuffer.append(e.getClass() + "\n");
		for (Iterator iter = stackTraces.iterator(); iter.hasNext();)
		{
			StackTraceElement element = (StackTraceElement) iter.next();
			errorBuffer.append(element.toString() + "\n");
		}
		logger.error(errorBuffer.toString());
		//return errorBuffer.toString();
	} 
    
    
    public static String  getStackTrace(Throwable e)
	{
		StackTraceElement[] stackTrace = e.getStackTrace();
		logger.info(Arrays.asList(stackTrace).getClass());
		List stackTraces = (List) Arrays.asList(stackTrace);
		StringBuffer errorBuffer = new StringBuffer();
		errorBuffer.append("INIZIO STACK TRACE\n");
		errorBuffer.append(e.getMessage() + "\n");
		errorBuffer.append(e.getClass() + "\n");
		for (Iterator iter = stackTraces.iterator(); iter.hasNext();)
		{
			StackTraceElement element = (StackTraceElement) iter.next();
			errorBuffer.append(element.toString()+ "\n");
		}
		errorBuffer.append("FINE STACK TRACE\n");
		//logger.error(errorBuffer.toString());
		return errorBuffer.toString();
	}
    
    public static void manageActivateSendSmsPinWarining(GaussResponse gauss, String message, boolean concatMessage) {
    	
    	if(gauss != null) {
    		if(concatMessage) {
    			HostResponseMessage[] newMessage = new HostResponseMessage[2];
    	    	HostResponseMessage msg = new HostResponseMessage();
    	    	msg.setMessage(message);
    	    	
    	    	newMessage[0] = gauss.getHostResponseMessage()[0];
    	    	newMessage[1] = msg;
    	    	gauss.setFlagCode("W");
    	    	gauss.setHostResponseMessage(newMessage);
    		} else {
		    	HostResponseMessage[] newMessage = new HostResponseMessage[1];
		    	
		    	HostResponseMessage msg = new HostResponseMessage();
		    	msg.setMessage(message);
		    	
		    	newMessage[0] = msg;
		    	gauss.setFlagCode("W");
		    	gauss.setHostResponseMessage(newMessage);
    		}
    	}
    }
    
    public static void manageActivateSendSmsPinWariningMess1530(GaussResponse gauss, String message, boolean concatMessage) {
    	
    	if(gauss != null) {
    		if(concatMessage) {
    			HostResponseMessage[] newMessage = new HostResponseMessage[2];
    	    	HostResponseMessage msg = new HostResponseMessage();
    	    	HostResponseMessage msg1530 = new HostResponseMessage();
    	    	msg.setMessage(message);
    	    	msg1530.setMessage(GecUtilities.MSG_1530);
    	    	
    	    	newMessage[0] = msg1530;
    	    	newMessage[1] = msg;
    	    	gauss.setFlagCode("W");
    	    	gauss.setHostResponseMessage(newMessage);
    		} else {
		    	HostResponseMessage[] newMessage = new HostResponseMessage[1];
		    	
		    	HostResponseMessage msg = new HostResponseMessage();
		    	msg.setMessage(message);
		    	
		    	newMessage[0] = msg;
		    	gauss.setFlagCode("W");
		    	gauss.setHostResponseMessage(newMessage);
    		}
    	}
    }

    public static EsgBCardsListResponseClass anonymouseContractHeadin(EsgBCardsListResponseClass esgBCardsListResponseClass){
    	
		XlcPageField anonymouse = new XlcPageField(XlcConstantTag.STRING, XlcConstantTag.OUT);
		if (esgBCardsListResponseClass.getEsgCardsListTableInOut() != null) {
			try {
				anonymouse.setValue("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
				EsgBCardsListTableOut esgBCardsListTableOut = new EsgBCardsListTableOut();
				ArrayList temp = new ArrayList();

				for (int i = 0; i < esgBCardsListResponseClass.getEsgCardsListTableInOut().size(); i++) {
					
					esgBCardsListTableOut = (EsgBCardsListTableOut) esgBCardsListResponseClass.getEsgCardsListTableInOut().get(i);
					if ("Y".equalsIgnoreCase(esgBCardsListTableOut.getFlagAnonymous())){
						esgBCardsListTableOut.setHolder(anonymouse);
						 //lo sposto fuori perch� mq deve mostrare i risultati anche senza anonimizzarli
						//temp.add(esgBCardsListTableOut);
						}
					temp.add(esgBCardsListTableOut);
				}
					if (temp.size() != 0){
						esgBCardsListResponseClass.setEsgCardsListTableInOut(temp);
					}
			} catch (XFRException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    	return esgBCardsListResponseClass;
    }
    
    public static EsgCardInquiryResponseClass anonymouseInquiryResponseClass(EsgCardInquiryResponseClass inquiryResponseClass){
    	XlcPageField anonymouse = new XlcPageField(XlcConstantTag.STRING, XlcConstantTag.OUT);
    	try {
			anonymouse.setValue("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
			

			if (inquiryResponseClass != null){
				if ("Y".equalsIgnoreCase(inquiryResponseClass.getFlagLayout().getFlagAnonymous())){
				
					if (inquiryResponseClass.getCardInquiryData() != null) {
							if (inquiryResponseClass.getCardInquiryData().getMainContract() != null){
								if (inquiryResponseClass.getCardInquiryData().getMainContract().getContractHeading().getValue() != null)
									inquiryResponseClass.getCardInquiryData().getMainContract().setContractHeading(anonymouse);
							}
						if (inquiryResponseClass.getCardInquiryData().getCardSpecificData() != null){
							if (inquiryResponseClass.getCardInquiryData().getCardSpecificData().getEmbossedName()!= null){
								
								if (inquiryResponseClass.getCardInquiryData().getCardSpecificData().getEmbossedName().getFirstEmbLine().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getCardSpecificData().getEmbossedName().setFirstEmbLine(anonymouse);
								
								if (inquiryResponseClass.getCardInquiryData().getCardSpecificData().getEmbossedName().getSecondEmbLine().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getCardSpecificData().getEmbossedName().setSecondEmbLine(anonymouse);
								
								if (inquiryResponseClass.getCardInquiryData().getCardSpecificData().getEmbossedName().getThirdEmbLine().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getCardSpecificData().getEmbossedName().setThirdEmbLine(anonymouse);
							}
						}

						//AI smfrMobileNo-inquiryResponseClass.getCardInquiryData().getAddFuncList().getSmfrMobileNo();
							if (inquiryResponseClass.getCardInquiryData().getAddFuncList() != null){
								if (inquiryResponseClass.getCardInquiryData().getAddFuncList().getSmfrMobileNo().getValue() != null)
									inquiryResponseClass.getCardInquiryData().getAddFuncList().setSmfrMobileNo(anonymouse);
							}
							
						if (inquiryResponseClass.getCardInquiryData().getPaymentsData() != null){
							if (inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount() != null){
								if (inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().getAccountHeading().getValue() != null)
									inquiryResponseClass.getCardInquiryData().getPaymentsData().getMainAccount().setAccountHeading(anonymouse);
								}
						}
						if (inquiryResponseClass.getCardInquiryData().getStandardContract() != null) {
							if (inquiryResponseClass.getCardInquiryData().getStandardContract().getContractHeading().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getStandardContract().setContractHeading(anonymouse);
						}
						if (inquiryResponseClass.getCardInquiryData().getExpeditionData() != null) {
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedNameR01().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedNameR01(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedNameR02().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedNameR02(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedNameR03().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedNameR03(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedNameR04().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedNameR04(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedAddrR01().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedAddrR01(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedAddrR02().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedAddrR02(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedAddrR03().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedAddrR03(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedAddrR04().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedAddrR04(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getCardExpedAddrR05().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setCardExpedAddrR05(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedNameR01().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedNameR01(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedNameR02().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedNameR02(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedNameR03().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedNameR03(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedNameR04().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedNameR04(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedAddrR01().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedAddrR01(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedAddrR02().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedAddrR02(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedAddrR03().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedAddrR03(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedAddrR04().getValue() != null)
								inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedAddrR04(anonymouse);
							
							if (inquiryResponseClass.getCardInquiryData().getExpeditionData().getDocumentExpedAddrR05().getValue() != null)
							inquiryResponseClass.getCardInquiryData().getExpeditionData().setDocumentExpedAddrR05(anonymouse);
						}
					}
				}
			}
    	} catch (XFRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	
    	return inquiryResponseClass;
    }
    
    public static void manageActivateSendSmsPinError(GaussResponse gauss, String message) {
    	
    	if(gauss != null) {
	    	HostResponseMessage[] newMessage = new HostResponseMessage[1];
	    	
	    	HostResponseMessage msg = new HostResponseMessage();
	    	msg.setMessage(message);
	    	
	    	newMessage[0] = msg;
	    	gauss.setFlagCode("E");
	    	gauss.setHostResponseMessage(newMessage);
    	}
    }
    
    public static void retrievesWarningMsg(GaussResponse gauss, String message) {
    	
    	if(gauss != null) {
	    	HostResponseMessage[] newMessage = new HostResponseMessage[1];
	    	
	    	HostResponseMessage msg = new HostResponseMessage();
	    	msg.setMessage(message);
	    	newMessage[0] = msg;
	    	gauss.setFlagCode("W");
	    	gauss.setHostResponseMessage(newMessage);
    	}
    }

	public static void retrievesWarningMsgWithParam(GaussResponse gauss, String message, String Param) {

		HostResponseParams hostResponseParamTemp = new HostResponseParams();
		HostResponseMessage hostResponseMessageTemp = new HostResponseMessage();
		HostResponseMessage[] hostResponseMessageArray = new HostResponseMessage[1];
		HostResponseParams[] hostResponseParamsArray = new HostResponseParams[1];
		
		hostResponseParamTemp.setParam(Param);
		hostResponseParamsArray[0] = hostResponseParamTemp;
		hostResponseMessageTemp.setHostResponseParams(hostResponseParamsArray);
		hostResponseMessageArray[0]= hostResponseMessageTemp;
		
		if (gauss != null) {
			HostResponseMessage[] newMessage = new HostResponseMessage[1];

			HostResponseMessage msg = new HostResponseMessage();
			msg.setMessage(message);
			newMessage[0] = msg;
			gauss.setFlagCode("W");
			gauss.setHostResponseMessage(newMessage);
		}
		if (gauss.getHostResponseMessage() != null){
			hostResponseMessageArray[0].setMessage(gauss.getHostResponseMessage()[0].getMessage());
			hostResponseMessageArray[0].setDescription(gauss.getHostResponseMessage()[0].getDescription());
		}
		gauss.setHostResponseMessage(hostResponseMessageArray);
	}
	
    public static String manageRcMessage(long rc) {
    	String message = "";
    	if(rc == 213) {
    		// Errore ritornato da CMC - : Attendere tre minuti dall'ultima richiesta prima di riproporre la rigenerazione del PIN
			message = MSG_1509;
		} else if(rc == 224) {
			// Errore ritornato da CMC - : Raggiunto il limite massimo giornaliero di richieste (5)
			message = MSG_1501;
		} else {
			message = MSG_1502;
		}
    	return message;
    }

    public static String afaNormalizeAddress(String afaEndPoint, String address, String city, String postCode, String province, String country) {
    	logger.info("normalizeAddress --- start");
    	logger.info("normalizeAddress --- afaEndPoint [" + afaEndPoint + "]");
    	String jsonResult = "{ \"result\" : \"KO\" }";
    	try {
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			try {
				IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
				try {
					String errorCode = "";
					NormalizeAddressRequest requestAddress = new NormalizeAddressRequest();
					requestAddress.setAfaEndPoint(afaEndPoint);
					requestAddress.setFunction(NormalizeAddressRequest.NORMALIZE_ADDRESS_FUNCTION);
					requestAddress.setLanguage("IT");
					requestAddress.setFieldsLength(30);
					requestAddress.setCountry(country);
					requestAddress.setProvince(province);
					requestAddress.setCity(city);
					requestAddress.setPostCode(postCode);
					requestAddress.setStreetAddress(address);
					requestAddress.setHamlet("");
					requestAddress.setLocality("");
					requestAddress.setStreetNumberAndExponent("");
					
					NormalizeAddressResponse responseAddress = serviceF.retrieveNormalizeAddress(requestAddress);
					
					errorCode = responseAddress.getErrorCode();
					
					if(("").equals(errorCode)) {
						if(responseAddress.getProvince() != null 
								&& !"".equalsIgnoreCase(responseAddress.getProvince().trim())
								&& !requestAddress.getProvince().equalsIgnoreCase(responseAddress.getProvince().trim())){
							responseAddress.setErrorType("W");
							jsonResult = "{ \"result\" : \"" + responseAddress.getErrorCode().trim() + 
										"\", \"type\" : \"" + responseAddress.getErrorType().trim() + 
										"\", \"desc\" : \"" + responseAddress.getErrorDescription().trim() +
										"\", \"address\" : \"" + responseAddress.getAddress().trim() +
										"\", \"province\" : \"" + responseAddress.getProvince().trim() +
										"\", \"postalCode\" : \"" + responseAddress.getPostalCode().trim() +
										"\", \"city\" : \"" + responseAddress.getCity().trim() +
										"\", \"country\" : \"" + responseAddress.getCountry().trim() +
										"\", \"isWsUnhandledCase\" : \"true\"}";
						} else {
							jsonResult = "{ \"result\" : \"OK\" }";
						}
					} else {
						jsonResult = "{ \"result\" : \"" + responseAddress.getErrorCode().trim() + 
										"\", \"type\" : \"" + responseAddress.getErrorType().trim() + 
										"\", \"desc\" : \"" + responseAddress.getErrorDescription().trim() +
										"\", \"address\" : \"" + responseAddress.getAddress().trim() +
										"\", \"province\" : \"" + responseAddress.getProvince().trim() +
										"\", \"postalCode\" : \"" + responseAddress.getPostalCode().trim() +
										"\", \"city\" : \"" + responseAddress.getCity().trim() +
										"\", \"country\" : \"" + responseAddress.getCountry().trim() +
										"\"}";
					}
				} finally {
					serviceFactory.dispose(serviceF);
				}
			} catch (Exception e) {
				logger.error("Error 1: " + e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Error 2: " + e.getMessage());
		}
		logger.info("normalizeAddress --- end");
		
		return jsonResult;
    }
    
    public static String getMaskedPan(String value) {
    	if (value == null)
    		return "";

    	if (value.matches("^[0-9]*$") == false && value.length() > 2){
    		return value;
    	}

    	int l = value.length();

    	if (l <= 10)
    		return value;
    	else {
    		int numAster = l - 10;
    		return value.substring(0, 6) + (new String(new char[numAster]).replace('\0', '*')) + value.substring(l - 4);
    	}
    }
    
    public static XDocument getXDocumentCopy(XDocument item) throws IOException, ClassNotFoundException  {
		ByteArrayOutputStream bos = null;
		ObjectOutputStream out = null;
		ByteArrayInputStream bis = null;
		ObjectInputStream in = null;
		bos = new ByteArrayOutputStream();
		out = new ObjectOutputStream(bos);
		out.writeObject(item);
		out.flush();
		out.close();
		
		bis = new ByteArrayInputStream(bos.toByteArray());
		in = new ObjectInputStream(bis);
		XDocument newItem = (XDocument) in.readObject();
		in.close();
		return newItem;
	}

    public static ActionForward checkStoredFirmaMia(HttpServletRequest request, HttpServletResponse response)
			throws RemoteException, HostUserInfoException, ServiceFactoryException, XFRException, IOException {
		logger.info("GecUtilities.checkStoredFirmaMia --- start");
		
		String toReturn = "KO";
		
		if(EsgCountryCode.isItalianCountry()){
			if(isFirmaMiaSkipTabletCheckSet()){
				logger.info("SKIPPING STORED CHECK");
				toReturn = "OK";
			} else {
				String prodotto = request.getParameter("productCode");
				String evento = request.getParameter("event") == null ? "" : request.getParameter("event");
				logger.info("GecUtilities.checkStoredFirmaMia --- prodotto: " + prodotto);
				logger.info("GecUtilities.checkStoredFirmaMia --- evento: " + evento);
				
				UserData userData = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
				String branch = userData.getFilialeOperatore() != null ? userData.getFilialeOperatore() : "";
				
				PaperlessCheckInput input = new PaperlessCheckInput();
				input.setFiliale(branch);
				input.setProdotto(prodotto.trim());
				input.setEvento(evento);
				
				logger.info("PILOTBRANCHCHECK - BRANCH: " + branch + " PRODOTTO: " + prodotto + " EVENTO: " + evento);
				
				// -- 3 -- chiamata al servizio -----------------------------------------------------------------------------------------------------
				
				PaperlessCheckOutput output = new PaperlessCheckOutput();		
				GecServiceFactory serviceF = GecServiceFactory.getInstance();
				IGecServiceFacade serv = serviceF.getGecServiceFacade();
				try {
					// service call
					output = serv.retrievePaperlessCheck(input);
				} finally {
					serviceF.dispose(serv);
				}
				
				if (output.getReturnCode() == 0) { // service call OK
					logger.info("GECKSFMR RESPONSE OK. flagRetry = " + output.getFlagRetry());
					if("[Y]".equalsIgnoreCase(output.getFlagRetry().trim())) {
						toReturn = "OK";
					}
				} else {
					logger.info("GECKSFMR RESPONSE KO");
					toReturn = "KO";
				}
			}
		}
		
		String jsonResult = "{\"result\" : \"" + toReturn + "\"}";
		logger.info("JSONRESULT = " + jsonResult);
		
		response.setHeader("Content-Type", "application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.write(jsonResult);
		out.flush();
		out.close();
		logger.info("GecUtilities.checkStoredFirmaMia --- end");
		return null;
	}
    
    public static String retrieveFirmaMiaTabletScriptAddress() {
    	logger.info("GecUtilities.retrieveFirmaMiaTabletScriptAddress --- start");
		String signpadVerifyURL = "";
		IEnvironment environment = EnvironmentLoader.getDefault();
		String tower = environment.get(IEnvironment.TOWER, "");
		logger.info("GecUtilities.retrieveFirmaMiaTabletScriptAddress --- tower = " + tower);
		
		if("UJ".equalsIgnoreCase(tower)){
			signpadVerifyURL = "https://usjetdw002.sd01.unicreditgroup.eu/";
		} else if ("Q0".equalsIgnoreCase(tower)){
			signpadVerifyURL = "https://usjetdw002.sd01.unicreditgroup.eu/";
		} else if("C0".equalsIgnoreCase(tower)){
			signpadVerifyURL = "https://signpad.intranet.unicredit.it/";
		}
		logger.info("GecUtilities.retrieveFirmaMiaTabletScriptAddress --- signpadVerifyUrl = " + signpadVerifyURL);
		logger.info("GecUtilities.retrieveFirmaMiaTabletScriptAddress --- end");
		return signpadVerifyURL;
	}

    public static String setSignpadVerifyURL(HttpServletRequest request) {
    	logger.info("GecUtilities.setSignpadVerifyURL --- start");
		String signpadVerifyURL = retrieveFirmaMiaTabletScriptAddress();
		request.setAttribute("signpadVerifyURL", signpadVerifyURL);
		logger.info("GecUtilities.setSignpadVerifyURL --- setting signpadVerifyUrl = " + signpadVerifyURL);
		logger.info("GecUtilities.setSignpadVerifyURL --- end");
		return signpadVerifyURL;
	}
    
    public static void printParamsAndAttrs(HttpServletRequest request) {
		printParamsAndAttrs(request, true, true, true);
	}

	public static void printParamsAndAttrs(HttpServletRequest request, boolean printParameters, boolean printRequestAttributes, boolean printSessionAttributes) {
		if(request == null){
			logger.info("GecUtilities.printParamsAndAttrs - Request is null, can't print parameters");
		} else {
			if(printParameters){
				Enumeration params = request.getParameterNames(); 
				while(params.hasMoreElements()){
					String paramName = (String) params.nextElement();
					logger.info("GecUtilities.printParamsAndAttrs - PARAMETER: " + paramName + ", VALUE: " + request.getParameter(paramName));
				}
			}
			
			if(printRequestAttributes){
				Enumeration attributes = request.getAttributeNames();
				while(attributes.hasMoreElements()){
					String attributeName = (String) attributes.nextElement();
					logger.info("GecUtilities.printParamsAndAttrs - ATTRIBUTE: " + attributeName + ", VALUE: " + request.getAttribute(attributeName));
				}
			}
			
			if(printSessionAttributes){
				if (request.getSession() == null) {
					logger.info("GecUtilities.printParamsAndAttrs - Session is null, can't print session attributes");
				} else {
					Enumeration sessionAttributes = request.getSession().getAttributeNames();
					while(sessionAttributes.hasMoreElements()){
						String sessionAttributeName = (String) sessionAttributes.nextElement();
						logger.info("GecUtilities.printParamsAndAttrs - SESSION ATTRIBUTE: " + sessionAttributeName + ", VALUE: " + request.getSession().getAttribute(sessionAttributeName));
					}
				}
			}
		}
	}
}