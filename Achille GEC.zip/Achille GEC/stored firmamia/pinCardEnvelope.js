/*
*	Author: EE29570
*	Created : 	04-11-2013
*	Modified:	06-12-2013
*/

/********************************************************************************************
* ###########################    VARIABILI GLOBALI  ####################################### *
*********************************************************************************************/

var dateCalendarFrom = null;
var dateCalendarTo 	= null;
var onlyOneTime 	= false;
var confirmExit 	= false;
var submitted 		= false;

/********************************************************************************************
* ###########################    		MAIN  		####################################### *
*********************************************************************************************/
/*
* Caricamento delle funzioni all'avvio.	
*/
function onLoadPageManagement() {

	// gestione stampa automatica
	manageAutomaticPrint();

	// Controllo sulla compatibilit�	
	if(window.jQuery) {
		// Disabilita la selezione dei campi
		//$( "#bodyFrame TR.rowHeader *" ).disableSelection();
	
		$("#bodyFrame TR.rowHeader").mouseenter(function() {
			if(!$(this).hasClass('selectedRow')){
				$(this).addClass("rowSelected");
			}
		}).mouseleave(function() {
			$(this).removeClass("rowSelected");
		});
	
		// Aggiunge un link al riferimento della label
		// Questo codice funziona se per ogni label � associato un solo oggetto.
		//var labels = document.getElementsByTagName('LABEL');
		//for (var i = 0; i < labels.length; i++) {
		//    if (labels[i].htmlFor != '') {
		//         var elem = document.getElementById(labels[i].htmlFor);
		//        if (elem){ elem.label = labels[i];	}		
		//    }
		//}
		
		// Cambia il colore alla label del radio button
		switchLabels(document.getElementById('headerRadioSet'));

		// Resetta tutti i tipi checked
		$( "#rowBody TR.radioRow INPUT:checked").attr('checked', false);
	
		var dateFrom = document.getElementById("datepickerFrom");
		var dateTo = document.getElementById("datepickerTo");

		if (dateFrom != null && dateTo != null) {
			
			dateCalendarFrom 	= parseDate(dateFrom.value);
			dateCalendarTo 		= parseDate(dateTo.value);
		
			// Datepicker From
			Calendar.setup( {
				ifFormat : "%d.%m.%Y",
				inputField : "datepickerFrom",
				button: "datepickerFromImg",
				onUpdate: function (calendar) {
					dateCalendarFrom = calendar.date || null;
					updateDatePicker(dateFrom, dateTo);
				},
				dateStatusFunc : function (date) {
					if (	dateCalendarTo != null && 
							date != null && 
							dateCalendarTo < date) {
						return true;
					}
					return false;
				}
			});
	
			// Datepicker To
			Calendar.setup( {
				ifFormat : "%d.%m.%Y",
				inputField : "datepickerTo",
				button: "datepickerToImg",
				onUpdate: function (calendar) {
					dateCalendarTo = calendar.date || null;
					updateDatePicker(dateFrom, dateTo);
				},
				dateStatusFunc : function (date) {
					if (	dateCalendarFrom != null && 
							date != null && 
							dateCalendarFrom > date) {
						return true;
					}
					return false;
				}
			});
			
			updateDatePicker(dateFrom, dateTo);
		}
	}
}

// parse a date in dd.mm.yyyy format
function parseDate(input) {
  if (typeof input === 'string' &&  input.match("^[0-9]{2}.[0-9]{2}.[0-9]{4}")) {
	  var parts = input.split('.');
	  // new Date(year, month [, date [, hours[, minutes[, seconds[, ms]]]]])
	  return new Date(parts[2], parts[1]-1, parts[0]); // months are 0-based
  }
  return null;
}


function updateDatePicker(dateFrom, dateTo) {

	if(dateFrom == undefined || dateTo === undefined){
		dateFrom = document.getElementById("datepickerFrom");
		dateTo = document.getElementById("datepickerTo");
	}

	var dateFromImg = document.getElementById("datepickerFromImg");
	var dateToImg = document.getElementById("datepickerToImg");
	
	if (dateFrom.value !== undefined) {
		if (dateFrom.value.match("^[0-9]{2}.[0-9]{2}.[0-9]{4}")){
			dateTo.disabled 	= false;
			dateToImg.disabled 	= false;
			dateTo.className = dateTo.className.replace(/ disabled /g, "");
			dateToImg.className = dateToImg.className.replace(/ disabled /g, "");
		} else {
			dateFrom.value 		= ''; 	
			dateTo.value 		= ''; 	
			dateTo.disabled 	= true;
			dateToImg.disabled 	= true;
			if (!dateTo.className.match(" disabled ")){
				dateTo.className += " disabled ";
				dateToImg.className += " disabled ";
			}
			
		}	
	}
}

/*
*  Seleziona imposta tutte le buste all'interno di un lotto.
*/
function selectAll(opt) {
	var opt = {C:1, X:2, D:3}[opt];
	onlyOneTime = true;
	if (opt) {
		if(window.jQuery) {
			$( "#rowBody INPUT[id$='-" + opt + "']").attr('checked', true).change();
		} else {
			var rowBody = document.getElementById("rowBody");
			var inputs = rowBody.getElementsByTagName("INPUT");
			if (inputs && inputs.length){	
				for( var i = 0; i < inputs.length; i++){ 
					if (inputs[i].type == 'radio' && inputs[i].id.indexOf("-" + opt) >= 0) {
						inputs[i].checked = true;
						onChangeEvent(inputs[i]);
					}
				}
			}
		}
	}
	if (opt == 2) {
	  callWarning(WARNING_LOST, "");
	} else if (opt == 3) {
	  callWarning(WARNING_DAMAGED, "");
	}
	onlyOneTime = false;
}

var $rows = null;
/*
* Verifica che tutte le righe abbiamo una selezione.
*/
function checkOneSelected(element) {
	if ($rows == null) {
		$rows = $("#rowBody TD.iconSet");
	}
	// Resetta tutti i tipi checked
	$rows.find("INPUT:checked").attr('checked', false);
	element.checked = true;	

	$rows.each( function () {
		switchLabels(this);
	});
	return true;	 
}/*
* Verifica che tutte le righe abbiamo una selezione.
*/
function checkAllSelected() {
	if ($rows == null) {
		$rows = $("#rowBody TD.iconSet");
	}
	var nSel = $rows.find("INPUT[type='radio']:checked").length;
	if (nSel == $rows.length)
		return true;
	return false;	 
}
/*
* Al cambiamento dello stato del radio button, cambia anche la label associata.
*/
function onChangeEvent(element, submitOnly) {
	if (element) {
		var parent = element.parentNode.parentNode;
		switchLabels(parent);
		
		if (element.value == 'KD' && !onlyOneTime) {
			  callWarning(WARNING_DAMAGED, "");
		}
		
		if (element.value == 'KM' && !onlyOneTime) {
			  callWarning(WARNING_LOST, "");
		}
		
		if ((submitOnly == true && checkOneSelected(element)) || checkAllSelected()) {
			document.getElementById("submitButton").disabled = false;
		}
	}
}
/*
* Cambia lo sfondo per la sezione selezionata
*/
function switchLabels(parent){
	var radios = parent.getElementsByTagName("INPUT");
	if (radios && radios.length){
		for (var i = 0; i < radios.length; i++) {
			//if (radios[i].label) {
				if (radios[i].checked) {
					$(radios[i]).parent().addClass('enabledLabel');
				} else {
					$(radios[i]).parent().removeClass('enabledLabel');
				}		
			//}
		}
	}
}

/*
* Seleziona un nuovo lotto dalla lista.
*/
function selectLot(date) {
	if (!submitted) {
		if (date) {
			var currentBatch = document.getElementById("in.currentBatchDate.value");
			if (currentBatch.value != date ) {
				var temp = currentBatch.value;
				currentBatch.value = date;
				document.getElementById('method').value = 'retrieveCardsLot';
				onSubmitEvent();
				if (!submitted) {
					currentBatch.value = temp;
				}
			}else {
				$('#rowTable, #rowBody').toggle();
			};
		}
	}
}

//FirmaMia
function checkStored(callback){
	var selectedElementOperId = $("#rowBody TD.iconSet").find("INPUT:checked").attr("id");
	var selectedElementProductCodeName = selectedElementOperId.split("-")[0] + '-ProductCode';
	var productCode = $("input[type='hidden'][name='" + selectedElementProductCodeName + "']").val();
	var event = 'RIT AGEN';
	//var module = 'BU1214';
	var urlCall = 'esgPinCardEnvelope.do?method=checkStored&productCode=' +  productCode + '&event=' + event;
	//var urlCall = 'esgPinCardEnvelope.do?method=checkStored&module=' +  module;
	$.ajax({ url: urlCall,
		dataType: "json",
		type: "POST",
		success: function(data) {
			if("OK" === data.result) {
				callback(true);
			} else {
				callback(false);
			}
		},
		error: function() {
			callback(false);
		}
	});

}

function isSignPadConnected() {
    var response = {};
    try {
    	var s = getXPDEuronovateTabletStatus();
        eval("response = " + s + ";"); // testSignpad.js
    } catch (err) {
        response = response = {Euronovate_pluginInUse: false, Euronovate_plugin_ok: true, Euronovate_tablet_online: true, XPD_tablet_available: false, XPD_tablet_busy: false,XPD_tablet_service_online: false};
    }

	var res = true;

	if(response.Euronovate_pluginInUse === true || response.XPD_tablet_busy === true ) {
		tabletKoMsg = "Tablet impegnato con altro processo. Per proseguire con stampa cartacea premere OK. Per interrompere premere CANCEL e ricercare codice errore XPD00002 in UniContact.";
		res = false
	}
	if(response.XPD_tablet_available === false || response.XPD_tablet_service_online === false ) {
		tabletKoMsg = "Tablet non funzionante o non collegato. Per proseguire con stampa cartacea premere OK. Per interrompere premere CANCEL e ricercare codice errore XPD00003 in UniContact.";
		res = false;
	}
	if(response.Euronovate_plugin_ok === false || response.Euronovate_tablet_online === false ) {
		tabletKoMsg = "Tablet Plugin in Errore. Per proseguire con stampa cartacea premere OK. Per interrompere premere CANCEL e ricercare codice errore XPD00001 in UniContact.";
		res = false;
	}

	return res;
}
// EE29052 - Firmamia - END


/*
* Funzione per l'invio all host delle carte appartenti al lotto. 
*/
function submitLot() {
	checkStored(function(data) { // EE29052 - Firmamia - stored to determine whether the print is digital
			var askConfirmation = data;
			var signPadConnected;
			if(askConfirmation){
				signPadConnected = isSignPadConnected();
				if(signPadConnected){
					$("#tabletStatusKo").val("false");
				} else {
					$("#tabletStatusKo").val("true");
				}
			} else {
				$("#tabletStatusKo").val("");
			}
			
			if(askConfirmation && !signPadConnected) {
				if(!openModalPopupWinPers(tabletKoMsg, "")) {
					return;
				}
			}
			document.getElementById('method').value = 'updateCardsLot';
			document.forms['esgPinCardEnvelopeForm'].submit();
			submitted = true;
	});
}

/*
* Funzione per il ripristino del lotto. 
*/
function restoreLot(data) {
	document.getElementById('currentBatch').value = data;
	document.getElementById('method').value = 'restoreCardLot';
	var dataFrom = document.getElementById('datepickerFrom');
	var dataTo = document.getElementById('datepickerTo');
	if (dataTo != null) {
		dataTo.value = '';
	}
	if (dataFrom != null) {
		dataFrom.value = '';
	}
	onSubmitEvent();
}


/*
* Al cambiamento dello stato del radio button, cambia anche la label associata.
*/
function onChangeView() {
	switchLabels(document.getElementById('headerRadioSet'));

	document.getElementById('row').value = '0';
	document.getElementById('currentBatch').value = '';
	document.getElementById('method').value = 'retrieveCardsLot';
	
	if (document.getElementById('tbcDeliverView').checked == true) {
		var dataFrom = document.getElementById('datepickerFrom');
		var dataTo = document.getElementById('datepickerTo');
		if (dataTo != null) {
			dataTo.value = '';
		}
		if (dataFrom != null) {
			dataFrom.value = '';
		}
	}
	onSubmitEvent();
}

function onSubmitEvent(){
	if (!submitted) {
		var submitButton = document.getElementById("submitButton");
		if (submitButton != null && submitButton.disabled == false && confirmExit == false) {
			callWarning(WARNING_MESSAGE , ""); 
			confirmExit = true;
			return;
		}
		showMessage();
		document.forms['esgPinCardEnvelopeForm'].submit();
		submitted = true;
	}
}

function showMessage(){
	showWaitDiv(WAITING_LABEL, '#FDC059');
}


