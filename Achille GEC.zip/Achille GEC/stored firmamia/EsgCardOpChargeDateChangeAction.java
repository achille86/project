package it.usi.xframe.gec.pfstruts.actions.eurosig.cardOperations;

import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckInput;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOutput;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpChargeDateChangeInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOperationsResponseClass;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.pfstruts.forms.eurosig.cardInquiry.EsgCardInquiryActionForm;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.ifg.bfutil.IfgServiceFactory;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.system.ifutils.EnvironmentLoader;
import it.usi.xframe.system.ifutils.IEnvironment;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.Utl;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class EsgCardOpChargeDateChangeAction extends EsgCardOperationsGeneralAction {

	private Log logger = LogFactory.getLog(this.getClass());
	
	
	/**
	 * recupera i dati relativi alla conferma
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */ 
	public ActionForward chargeDateChangeInquiry(ActionMapping mapping,
									  ActionForm form,
									  HttpServletRequest request,
									  HttpServletResponse response) throws java.lang.Exception {
		
		logger.debug("*********  [EsgCardOpChargeDateChangeAction:chargeDateChangeInquiry] *******START*****");

		//Metto in request alcuni parametri tipici
		this.setRequestParams(form, request);
		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		//EE29052 - FirmaMia - XPI tablet check
		GecUtilities.setSignpadVerifyURL(request);
		//EE29052 - FirmaMia - END

		
		//Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		//[INIT]Call to inquiry service management
		EsgCardInquiryResponseClass inquiryResponseClass = new EsgCardInquiryResponseClass();

		EsgCardInquiryInOut paramsIn = new EsgCardInquiryInOut();
		EsgCardOpChargeDateChangeInOut authoInOut = new EsgCardOpChargeDateChangeInOut();
		//Definizione dei parametri di input al servizio
		paramsIn = this.retrieveInquiryInput(request, actionForm.getCardInquiryInOut());

		inquiryResponseClass = (EsgCardInquiryResponseClass) this.getInquiryData(paramsIn, request);

		if (this.isGaussResponseError(inquiryResponseClass.getGaussResponse())) { // errore inquiry
			logger.debug("##### [EsgCardOpChangeAuthorizationAction:chargeDateChangeInquiry] Chiamata servizio Inquiry KO");

			//Gestione del forward e del warning
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, inquiryResponseClass.getGaussResponse());
			complexPopUpParams.setSevereError(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;

		} else { // inquiry OK

			logger.debug("#### [EsgCardOpChargeDateChangeAction:chargeDateChangeInquiry] Chiamata al servizio Inquiry OK");
			actionForm.setCardInquiry(inquiryResponseClass.getCardInquiryData());
			actionForm.setVariations(inquiryResponseClass.getVariations());

			authoInOut.getContractNum().setValue(paramsIn.getContractNum().getValue());
			authoInOut.getCardSeqNumber().setValue(paramsIn.getCardSeqNumber().getValue());
			authoInOut.getNdgCardHolder().setValue(paramsIn.getNdgCardHolder().getValue());
			authoInOut.getCardHolder().setValue(paramsIn.getCardHolder().getValue());

			//Beans Directions definitions
			manageInquiryDataDirection(inquiryResponseClass);
		}
		
		logger.debug("[EsgCardOpChargeDateChangeAction:chargeDateChangeInquiry] Inquiry Service End");
		//[END]Call to inquiry service management Fine della gestione lettura dati di inquiry

		// Call Confirm Service Manager
		EsgCardOperationsResponseClass cardOperationsResponseClass = new EsgCardOperationsResponseClass();

		try {
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			try {
				IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
				try {
					cardOperationsResponseClass = serviceF.esgCardOpChargeDateChangeInquiry(authoInOut);
				} finally {
					serviceFactory.dispose(serviceF);
				}
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}
		
		if (!this.isGaussResponseError(cardOperationsResponseClass.getGaussResponse())) { // service ok
			actionForm.setChargeDateChangeInOut(cardOperationsResponseClass.getChargeDateChangeInOut());
			logger.debug(" *************** chargeDateChangeInOut.getChoiceCode  *************" + 
				cardOperationsResponseClass.getChargeDateChangeInOut().getChoiceCode());
			logger.debug(" *************** chargeDateChangeInOut.getDayOfMonthStandard  *************" + 
				cardOperationsResponseClass.getChargeDateChangeInOut().getDayOfMonthStandard());
			logger.debug(" *************** chargeDateChangeInOut.getDayOfMonthPostponed  *************" + 
				cardOperationsResponseClass.getChargeDateChangeInOut().getDayOfMonthPostponed());
			this.manageInformationBar(request, "menu.label.chargeDateChange.text", actionForm.getCardInquiry());
		}
		
		String urlAfterError = this.urlAfterRetrieveError(request);
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, cardOperationsResponseClass.getGaussResponse());
		complexPopUpParams.setActionBackError(urlAfterError);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_OP_CHARGE_DATE_CHANGE);
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.debug("*********  [esgCardOpChangeAuthoAction:chargeDateChangeInquiry] *******END*****");

		return forward;
	}
	
	
	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward chargeDateChangeUpdate(ActionMapping mapping,
										   ActionForm form,
										   HttpServletRequest request,
										   HttpServletResponse response) throws java.lang.Exception {

		logger.debug("[EsgCardOpChargeDateChangeAction:chargeDateChangeUpdate] *******START*****");

		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		EsgCardOperationsResponseClass classReturn = new EsgCardOperationsResponseClass();
		EsgCardOpChargeDateChangeInOut paramsIn = new EsgCardOpChargeDateChangeInOut();

		//Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		String ndg = (String) actionForm.getChargeDateChangeInOut().getNdgCardHolder().getValue();
		String clientDescription = (String) actionForm.getChargeDateChangeInOut().getNdgCardHolder().getValue();

		logger.debug("[EsgCardOpChargeDateChangeAction:chargeDateChangeUpdate] ndg: " + ndg);
		logger.debug("[EsgCardOpChargeDateChangeAction:chargeDateChangeUpdate] clientDescription: " + clientDescription);

		paramsIn = actionForm.getChargeDateChangeInOut();
		logger.debug("paramsIn.getChoiceCode" + paramsIn.getChoiceCode().getValue());
		logger.debug("paramsIn.getDayOfMonthStandard() " + paramsIn.getDayOfMonthStandard().getValue());
		logger.debug("paramsIn.getDayOfMonthPostponed() " + paramsIn.getDayOfMonthPostponed().getValue());

		try {
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			try {
				IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
				try {
					classReturn = serviceF.esgCardOpChargeDateChangeUpdate(paramsIn);
				} finally {
					serviceFactory.dispose(serviceF);
				}
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}

		String urlServiceCallOK = "";
		String urlServiceCallKO = "";
		
		if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
			urlServiceCallKO = this.urlAfterUpdateError(request);
			logger.debug("********* Update  ERRORE  ************" + urlServiceCallKO);
		} else {
			urlServiceCallOK = this.urlAfterUpdateSuccess(request);
			logger.debug("********* Update  MESSAGGIO  ************" + urlServiceCallOK);
			
			// gestione stampe automatiche
			this.managePrintInformation(request, classReturn.getPrintManager());
		}
		
		//EE29052 - FirmaMia - Problemi con il popup, quindi imposto il parametro 
		request.getSession().setAttribute("storedOkAndNoTabletIssues", "false");
		boolean isPaper = "".equalsIgnoreCase(request.getParameter("tabletStatusKo"));
		if(!isPaper && !(request.getParameter("tabletStatusKo") != null && "true".equalsIgnoreCase(request.getParameter("tabletStatusKo")))) {
			logger.info("SETTO storedOkAndNoTabletIssues TO TRUE");
			request.getSession().setAttribute("storedOkAndNoTabletIssues", "true");
		}
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
		complexPopUpParams.setActionBackError(urlServiceCallKO);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setActionBackMessage(urlServiceCallOK);
		complexPopUpParams.setReturnBackMessage(true);
		forward = Utl.createComplexPopUp(complexPopUpParams);
		return forward;
	}
	
	// EE29052 - Firmamia - stored to determine whether the print is digital
	public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
		return GecUtilities.checkStoredFirmaMia(request, response);
	}
	// EE29052 - Firmamia - END
}

