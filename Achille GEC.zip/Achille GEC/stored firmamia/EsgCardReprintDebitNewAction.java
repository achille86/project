/*
 * Created on Apr 4, 2008
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package it.usi.xframe.gec.pfstruts.actions.eurosig.cardReprintDebitNew;

import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import it.usi.xframe.afa.bfintf.IAfaBaseServiceFacade;
import it.usi.xframe.afa.bfutil.AFAServiceFactory;
import it.usi.xframe.afa.bfutil.Customer;
import it.usi.xframe.afa.bfutil.PfCustomer;
import it.usi.xframe.afa.bfutil.SearchCustomerParams;
import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckInput;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOutput;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryDataOut;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryVariationsOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOperationsResponseClass;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardPrintIn;
import it.usi.xframe.gec.bfutil.eurosig.print.EsgCardPrintResponseClass;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.pfstruts.actions.eurosig.cardOperations.EsgCardOperationsGeneralAction;
import it.usi.xframe.gec.pfstruts.forms.eurosig.cardInquiry.EsgCardInquiryActionForm;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.ifg.bfintf.IIfgServiceFacade;
import it.usi.xframe.ifg.bfutil.HostUserInfoException;
import it.usi.xframe.ifg.bfutil.IfgServiceFactory;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.pre.bfintf.IPreServiceFacade;
import it.usi.xframe.pre.bfutil.PreServiceFactory;
import it.usi.xframe.pre.tg0beans.TG0TB0224;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.system.eservice.ServiceFactoryException;
import it.usi.xframe.system.ifutils.EnvironmentLoader;
import it.usi.xframe.system.ifutils.IEnvironment;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.GaussResponse;
import it.usi.xframe.utl.bfutil.HostResponseMessage;
import it.usi.xframe.utl.bfutil.Utl;
import it.usi.xframe.utl.bfutil.general.MarkedSessionManager;
import it.usi.xframe.xpi.bfutil.XDocument;
import it.usi.xframe.xpi.bfutil.XPIConstants;
import it.usi.xframe.xpi.bfutil.signpad.SignpadInOut;
import it.usi.xframe.xpi.bfutil.signpad.SignpadResponseClass;
import it.usi.xframe.xpi.bfutil.signpad.SignpadUtilities;

/**
 * @author EE06077
 *
 * Questa action si occupa  di innescare le transazioni di stampa 
 * 
 */
public class EsgCardReprintDebitNewAction extends EsgCardOperationsGeneralAction {

	private Log logger = LogFactory.getLog(this.getClass());

	private static String COD_STAMPA_CONTRATTO = "01";
	private static String COD_STAMPA_MASSIMALI = "20";
	
	/**
	 * metodo di preparazione stampa per presentare all'untente eventuali parametri da settare prima di innescare 
	 * la stampa effettiva. Un parametro potrebbe essere la lingua del modulo. 
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */

	public ActionForward printPrepare(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws java.lang.Exception {

		logger.debug("[EsgCardReprintDebitNewAction - printPrepare] --- start ---");

		// gestione dei parametri e della paginazione
		this.setRequestParams(form, request);
		this.setPaginationParams(form, request);

		//EE29052 - FirmaMia - XPI tablet check
		GecUtilities.setSignpadVerifyURL(request);
		//EE29052 - FirmaMia - END
		
		// inizializzazione form e ResponseClass
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;
		EsgCardInquiryResponseClass inquiryResponseClass = new EsgCardInquiryResponseClass();
		EsgCardInquiryInOut paramsIn = new EsgCardInquiryInOut();
		EsgCardPrintIn cardPrintIn = new EsgCardPrintIn();
		
		// chiamata al servizio di inquiry
		paramsIn = this.retrieveInquiryInput(request, actionForm.getCardInquiryInOut());
		inquiryResponseClass = (EsgCardInquiryResponseClass) this.getInquiryData(paramsIn, request);

		if (inquiryResponseClass.getGaussResponse() != null && inquiryResponseClass.getGaussResponse().isErrorFlag()) { // errore chiamata servizio di inquiry
			logger.debug("[EsgCardReprintDebitNewAction - printPrepare] error retrieving inquiry information");
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, inquiryResponseClass.getGaussResponse());
			complexPopUpParams.setSevereError(true);
			forward = Utl.createComplexPopUp(complexPopUpParams);
			return forward;
		} else { // servizio di inquiry ok
			logger.debug("[EsgCardReprintDebitNewAction - printPrepare] inquiry service correctly performed");
			actionForm.setCardInquiry(inquiryResponseClass.getCardInquiryData());
			actionForm.setVariations(inquiryResponseClass.getVariations());
			
			// metto in sessione i dati di inquiry e quelli di variazione
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "cardInquiryData", inquiryResponseClass.getCardInquiryData());
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "cardInquiryVariationsData", inquiryResponseClass.getVariations());

			// setto nella classe di input per il servizio di stampa i dati di inquiry
			cardPrintIn.setContractNum(inquiryResponseClass.getCardInquiryData().getStandardContract().getContractNumber());
			cardPrintIn.setCardSeqNumber(paramsIn.getCardSeqNumber());
			cardPrintIn.setNdgCardHolder(inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg());
			cardPrintIn.setCardHolder(inquiryResponseClass.getCardInquiryData().getStandardContract().getContractHeading());
			
			// gestione di dati e direction nell'action form
			actionForm.setCardPrintIn(cardPrintIn);
			manageInquiryDataDirection(inquiryResponseClass);
		}

		// chiamata al servizio di stampa
		EsgCardPrintResponseClass cardPrintResponseClass = new EsgCardPrintResponseClass();
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			cardPrintResponseClass = serviceF.esgCardDebitNewRetrieveReprintLang(cardPrintIn);
		} catch (Exception e) {
			throw new XFRException(e);
		} finally {
			if (serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		
		if (cardPrintResponseClass.getGaussResponse() == null || !cardPrintResponseClass.getGaussResponse().isErrorFlag()) { // chiamata servizio ok
			
			GaussResponse gaussRes = new GaussResponse();
			cardPrintResponseClass.setGaussResponse(gaussRes);
//			if(EsgCountryCode.isItalianCountry())
//				GecUtilities.retrievesWarningMsg(cardPrintResponseClass.getGaussResponse(), GecUtilities.MSG_1531);
			
			// setto il risultato nell'action form
			actionForm.setCardPrintIn(cardPrintResponseClass.getPrintInOut());
			// mantengo nella form i valori di numero contratto, sequenziale, ndg e intestazione cardholder
			actionForm.getCardPrintIn().setContractNum(inquiryResponseClass.getCardInquiryData().getStandardContract().getContractNumber());
			actionForm.getCardPrintIn().setCardSeqNumber(paramsIn.getCardSeqNumber());
			actionForm.getCardPrintIn().setNdgCardHolder(inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg());
			actionForm.getCardPrintIn().setCardHolder(inquiryResponseClass.getCardInquiryData().getStandardContract().getContractHeading());
			
			// traduco i codici lingua della combo
			ArrayList toTranslate = translateLangCodes(cardPrintResponseClass.getPrintInOut().getCodLingua().getCollection(), request);
			actionForm.getCardPrintIn().getCodLingua().setCollection(toTranslate);
			
			// se presente, recupero la descrizione dell'informativa pre-contrattuale PSD da GEM
			// TODO: commento questo sezione in via temporanea, perch� al momento per le carte debitoNew
			// non � prevista l'informativa precontrattuale PSD
			
//			String tmpFlag = (String) actionForm.getCardPrintIn().getPsdPreContractLayoutFlag().getValue();
//			if (tmpFlag != null && tmpFlag != "2") {
//				if (actionForm.getCardPrintIn().getPsdPreContractCode().getValue() != null) {
//					String tmpDescr = GecWebUtilities.getXpiModuleDescription((String) actionForm.getCardPrintIn().getPsdPreContractCode().getValue(), request);
//					if (tmpDescr != null && tmpDescr.trim().length() > 0) {
//						tmpDescr += " (" + actionForm.getCardPrintIn().getPsdPreContractCode().getValue() + ")";
//					} else {
//						tmpDescr = (String) actionForm.getCardPrintIn().getPsdPreContractCode().getValue();
//					}
//					actionForm.getCardPrintIn().getPsdPreContractDescription().setValue(tmpDescr);
//					logger.debug("[EsgCardReprintDebitNewAction - printPrepare] psdPreContractDescription: " + tmpDescr);
//				}
//			}
			
			
			// se c'� il parametro printType=limits della request setto il tipo stampa a 20 (COD_STAMPA_MASSIMALI)
			// altrimenti utilizzo il tipo di stampa di default (COD_STAMPA_CONTRATTO)
			if ("limits".equalsIgnoreCase(request.getParameter("printType"))) {
				actionForm.getCardPrintIn().getTipoStampa().setValue(COD_STAMPA_MASSIMALI);
				logger.debug("*** tipo stampa: massimali (codice " + actionForm.getCardPrintIn().getTipoStampa().getValue() + ")");
				this.manageInformationBar(request, "menu.label.limitsPrint.text", actionForm.getCardInquiry());
			} else {
				actionForm.getCardPrintIn().getTipoStampa().setValue(COD_STAMPA_CONTRATTO);
				logger.debug("*** tipo stampa: contratto (codice " + actionForm.getCardPrintIn().getTipoStampa().getValue() + ")");
				this.manageInformationBar(request, "menu.label.reprintCard.text", actionForm.getCardInquiry());
			}
		}

		
		String urlAfterError = this.urlAfterRetrieveError(request);
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, cardPrintResponseClass.getGaussResponse());
		complexPopUpParams.setActionBackError(urlAfterError);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setForward(GecWebConstants.ESG_CARD_PRINT_PREPARE);
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.debug("[EsgCardReprintDebitNewAction - printPrepare] --- end ---");
		return forward;
	}

	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws java.lang.Exception
	 */
	public ActionForward printContract(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws java.lang.Exception {

		logger.debug("[EsgCardReprintDebitNewAction - printContract] --- start ---");

		// Forward and Form initialization
		ActionForward forward = new ActionForward();
		EsgCardInquiryActionForm actionForm = (EsgCardInquiryActionForm) form;

		String sessionMarker = MarkedSessionManager.getInstance().getSessionMarker(request);
		request.setAttribute("sessionMarker", sessionMarker);
		logger.debug("SessionMarker in request " + sessionMarker);

		// Inserisco nel form i parametri per la gestione della paginazione(lista barra for)
		this.setPaginationParams(form, request);

		// EE29570 - Inserisco i flag di sviluppo nella request
		GecUtilities.setDevelopFlag(request);

		EsgCardPrintResponseClass classReturn = new EsgCardPrintResponseClass();

		// Classe inOut per chiamare il servizio, popolata leggendo i dati da ActionForm
		EsgCardPrintIn cardPrintIn = new EsgCardPrintIn();
		cardPrintIn = actionForm.getCardPrintIn();

		String ndg = (String) actionForm.getCardPrintIn().getNdgCardHolder().getValue();
		String clientDescription = (String) actionForm.getCardPrintIn().getNdgCardHolder().getValue();

		logger.debug("[EsgCardReprintDebitNewAction - printContract] ndg: " + ndg);
		logger.debug("[EsgCardReprintDebitNewAction - printContract] clientDescription: " + clientDescription);
		logger.debug("[EsgCardReprintDebitNewAction - printContract] getCodLingua: " + cardPrintIn.getCodLingua().getValue());
		logger.debug("[EsgCardReprintDebitNewAction - printContract] getTipoStampa: " + cardPrintIn.getTipoStampa().getValue());
		logger.debug("[EsgCardReprintDebitNewAction - printContract] getMotivazione: " + cardPrintIn.getMotivazione().getValue());

		// discrimino sul tipo di stampa chiamato
		if (actionForm.getCardPrintIn().getTipoStampa().getValue().equals(EsgCardReprintDebitNewAction.COD_STAMPA_CONTRATTO)) {
			logger.debug("[EsgCardReprintDebitNewAction - printContract] calling getPrintContractDocument()...");
			classReturn = getPrintContractDocument(cardPrintIn);
			
			// EE29570 - Verifico il flag di sviluppo per l'archivazione delle stampe 
			if (EsgCountryCode.isItalianCountry() && GecUtilities.isPrintArchiveSet() && classReturn.getPrintDoc() != null){
				logger.debug("[EsgCardReprintDebitNewAction - printContract] classReturn.getPrintDoc().length..." + classReturn.getPrintDoc().length);
				GecUtilities.setupXDocumentWithArchiveFlag(classReturn.getPrintDoc());
			}
			// EE29570 - FINE 
			
		} else if (actionForm.getCardPrintIn().getTipoStampa().getValue().equals(EsgCardReprintDebitNewAction.COD_STAMPA_MASSIMALI)) {
			logger.debug("[EsgCardReprintDebitNewAction - printContract] calling loadPrintLimitDocument()...");
			classReturn = getBR0821Document(cardPrintIn, request);
		}

		String urlServiceCallOK = "";
		String urlServiceCallKO = "";

		if (classReturn.getGaussResponse() != null && classReturn.getGaussResponse().isErrorFlag()) {
			logger.debug("********* Update printContract ERRORE  ************");
			urlServiceCallKO = this.urlAfterUpdateError(request);
			EsgCardInquiryDataOut cardInquiryData = (EsgCardInquiryDataOut) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "cardInquiryData");
			MarkedSessionManager.getInstance().removeMarkedSessionAttribute(request, "cardInquiryData");
			EsgCardInquiryVariationsOut variations = (EsgCardInquiryVariationsOut) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "cardInquiryVariationsData");
			MarkedSessionManager.getInstance().removeMarkedSessionAttribute(request, "cardInquiryVariationsData");
			actionForm.setCardInquiry(cardInquiryData);
			actionForm.setVariations(variations);
			this.manageInformationBar(request, "card.label.cardInquiry.text", actionForm.getCardInquiry());

			logger.debug("********* Update printContract  ERRORE  ************" + urlServiceCallKO);
		} else {
			logger.debug("********* Update printContract  MESSAGGIO  ************");
			urlServiceCallOK = this.urlAfterUpdateSuccess(request);
			logger.debug("********* Update printContract  MESSAGGIO  ************" + urlServiceCallOK);

			//EE29052 - FirmaMia - Problemi con il popup, quindi imposto il parametro 
			// servizio stampa ok
			request.getSession().setAttribute("storedOkAndNoTabletIssues", "false");
			boolean isPaper = "".equalsIgnoreCase(request.getParameter("tabletStatusKo"));
			if(!isPaper && !(request.getParameter("tabletStatusKo") != null && "true".equalsIgnoreCase(request.getParameter("tabletStatusKo")))){
				logger.info("EsgCardInquiryAction - storedOkAndNoTabletIssues");
				//Chiamo controllo XPI su modulo e filiale e setto attributo in request
				
				boolean xpiCheck;
				if (GecUtilities.isFirmaMiaSkipXpiCheckSet()) {
					logger.info("SKIPPING XPI CHECK: TRUE");
					xpiCheck = true;
				} else {
					logger.info("SKIPPING XPI CHECK: FALSE");
					xpiCheck = xpiCheck(classReturn.getPrintDoc());
				}
				
				logger.info("XPI CHECK: " + xpiCheck);
				request.setAttribute("xpiCheck", xpiCheck ? "true" : "false");
			}
			// Setta in sessione l'oggetto di stampa
			logger.debug("[EsgCardReprintDebitNewAction - printContract] getPrintDoc() == null? " + (classReturn.getPrintDoc() == null));
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "printForm", classReturn.getPrintDoc());

			// Setto nel form i dati della carta leggendoli dalla sessione

			EsgCardInquiryDataOut cardInquiryData = (EsgCardInquiryDataOut) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "cardInquiryData");
			MarkedSessionManager.getInstance().removeMarkedSessionAttribute(request, "cardInquiryData");
			logger.debug("[EsgCardReprintDebitNewAction - printContract] cardInquiryData == null? " + (cardInquiryData == null));

			EsgCardInquiryVariationsOut variations = (EsgCardInquiryVariationsOut) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "cardInquiryVariationsData");
			MarkedSessionManager.getInstance().removeMarkedSessionAttribute(request, "cardInquiryVariationsData");
			logger.debug("[EsgCardReprintDebitNewAction - printContract] variations == null? " + (variations == null));

			actionForm.setCardInquiry(cardInquiryData);
			actionForm.setVariations(variations);
			request.setAttribute("okPrint", "true");

			this.manageInformationBar(request, "card.label.cardInquiry.text", actionForm.getCardInquiry());
		}

		String context = GecUtilities.getAttributeInRequest(request, "context");
		logger.debug("CONTESTO   **** " + context);

		if ("BF".equals(context))
			request.setAttribute("context", "BF");

		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
		//complexPopUpParams.setActionBackError(urlServiceCallKO);
		//complexPopUpParams.setReturnBackError(true);
		//complexPopUpParams.setActionBackMessage( urlServiceCallOK );
		//complexPopUpParams.setReturnBackMessage( true );
		complexPopUpParams.setForward("esgCardInquiry");
		complexPopUpParams.setForwardBackError(true);
		complexPopUpParams.setErrorForward("esgCardInquiry");
		forward = Utl.createComplexPopUp(complexPopUpParams);
	
		logger.debug("[EsgCardReprintDebitNewAction - printContract] --- end ---");
		return forward;
	}

	/**
	 * La funzione restituisce la response class contenente i documenti (XDocument[]) di stampa del contratto restituiti da host
	 * 
	 * @param cardPrintIn
	 * @return
	 * @throws Exception
	 */
	private EsgCardPrintResponseClass getPrintContractDocument(EsgCardPrintIn cardPrintIn) throws Exception {

		EsgCardPrintResponseClass responseClass = new EsgCardPrintResponseClass();
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			responseClass = serviceF.esgCardReprintDebitNew(cardPrintIn);
		} catch (Exception e) {
			throw new XFRException(e);
		} finally {
			if (serviceF != null) {
				serviceFactory.dispose(serviceF);
			}
		}

		return responseClass;
	}

	/**
	 * La funzione restituisce la response class contenente i documenti (XDocument[]) di stampa variazione massimali BR0821
	 * 
	 * @param cardPrintIn
	 * @return
	 * @throws Exception
	 */
	private EsgCardOperationsResponseClass getBR0821Document(EsgCardPrintIn cardPrintIn, HttpServletRequest request) throws Exception {

		EsgCardOperationsResponseClass responseClass = new EsgCardOperationsResponseClass();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		// XDocument general configuration
		XDocument printForm = new XDocument();
		XDocument[] printFormArray = new XDocument[1];

		IEnvironment environment = EnvironmentLoader.getDefault();
		String abi = environment.get("HOST-ABI");
		printForm.setFormName("BR0821");
		printForm.setAbiCode(abi);
		printForm.setPrinter("2");
		printForm.setInstantPrintOn();
		printForm.setModuleVersion("00");

		// inizializzo le variabili del modulo BR0821 da valorizzare
		// java variable				// module variable		// length
		String branchCode = ""; 		// MOD_CSTR = MODCSTR		  5
		String branchName = ""; 		// MOD_STRU = MODSTRU		 64
		String operatorId = ""; 		// MOD_MATR					 64
		String location = ""; 			// MOD_LUOG					 60
		String date = ""; 				// MOD_DATA					 10
		String heading = ""; 			// ANA_INTE11				 64
		String birthdate = ""; 			// ANA_DNAS01				 10
		String ndgCardholder = ""; 		// ANA_SGRI00				  9
		String fiscalCode = ""; 		// ANA_CFIS01				 16
		String branchManager = ""; 		// LAV01					255
		String cardType = ""; 			// LAV02					255
		String cardIdentifier = ""; 	// LAV03					255
		String cardRequestDate = ""; 	// LAV04					255
		String cardExpriryDate = ""; 	// LAV05					255
		String currentLimit = ""; 		// LAV06					255
		String newLimit = ""; 			// LAV07					255
		String notes = "";				// LAV08					255

		// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
		// [init] retrieve dei dati
		// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

		// data corrente
		java.util.Date currentDate = new java.util.Date();
		date = dateFormat.format(currentDate);

		// note (EE05064) 
		notes = (cardPrintIn.getMotivazione() != null && cardPrintIn.getMotivazione().getValue() != null) ? cardPrintIn.getMotivazione().getValue().toString() : "";

		// chiamata IFG per il retrieve dei dati utente (necessari anche alla chiamata AFA)
		UserData userInfo = null;
		try {
			IfgServiceFactory ifgServiceFactory = IfgServiceFactory.getInstance();
			try {
				IIfgServiceFacade ifgService = ifgServiceFactory.getIfgServiceFacade();
				try {
					userInfo = ifgService.getUserInfo();
					logger.debug("[EsgCardReprintDebitNewAction: getPrintLimitDocument] IFG call >> userInfo = " + userInfo);
				} finally {
					ifgServiceFactory.dispose(ifgService);
				}
			} catch (RemoteException e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}

		// chiamata AFA per il recupero dei dati cardholder
		PfCustomer customer = null;
		if (userInfo != null) { // chiamata ifg ok
			branchCode = userInfo.getCodFilNum();
			branchName = userInfo.getDescrizione();
			operatorId = userInfo.getCodOperatore();
			location = userInfo.getLuogo();

			// lingua ambiente
			Locale loc = (Locale) request.getSession().getAttribute(Globals.LOCALE_KEY);
			String language = loc.getLanguage().toUpperCase();
			logger.debug("[EsgCardReprintDebitNewAction: getPrintLimitDocument] AFA search param >> language = " + language);

			// chiamata AFA
			AFAServiceFactory afaFactory = AFAServiceFactory.getInstance();
			try {
				IAfaBaseServiceFacade afaService = afaFactory.getAfaBaseServiceFacade();

				try {
					// parametri ricerca customer
					SearchCustomerParams scp = new SearchCustomerParams(userInfo, language);
					scp.setNdg((String) cardPrintIn.getNdgCardHolder().getValue());
					logger.debug("[EsgCardReprintDebitNewAction: getPrintLimitDocument] AFA search param >> ndg = " + scp.getNdg());

					// retrieve customer
					Customer afaCustomer = afaService.getCustomer(scp);
					if (afaCustomer != null && afaCustomer.isPf())
						customer = (PfCustomer) afaCustomer;

					logger.debug("[EsgCardReprintDebitNewAction: getPrintLimitDocument] AFA call >> afaCustomer null ? " + (afaCustomer == null));
					logger.debug("[EsgCardReprintDebitNewAction: getPrintLimitDocument] AFA call >> customer null ? " + (customer == null));

				} finally {
					afaFactory.dispose(afaService);
				}
			} catch (Exception e) {
				throw e;
			}
		}

		if (customer != null) { // chiamata afa ok
			heading = customer.getHeading() == null ? "" : customer.getHeading();
			birthdate = customer.getBirthDate() == null ? "" : dateFormat.format(customer.getBirthDate());
			ndgCardholder = customer.getNdg() == null ? "0" : customer.getNdg();
			ndgCardholder = ndgCardholder + "00000"; // i campi numerici devono essere "moltiplicati" per 1000000
			fiscalCode = customer.getTaxNumber() == null ? "" : customer.getTaxNumber();
		}

		// chiamata PRE per nome responsabile filiale
		TG0TB0224 bdInfo = null;
		if (userInfo != null) { // chiamata ifg ok

			TG0TB0224 searchBD = new TG0TB0224();
			searchBD.setTg_cod_ist(userInfo.getCodIstituto());
			searchBD.setBranch(userInfo.getCodFilNum());

			PreServiceFactory preFactory = PreServiceFactory.getInstance();
			try {
				IPreServiceFacade preService = preFactory.getPreServiceFacade();
				try {
					bdInfo = preService.getBranchDirector(searchBD);
				} catch (Exception e) {
					// EE05064
					// rimossa la throw per evitare problemi di allineamento con la PRE (in caso di errore � stampato il campo vuoto)
					logger.debug("[EsgCardReprintDebitNewAction: getPrintLimitDocument] errore chiamata PRE");
					logger.debug(e.getMessage());
					//throw e;
				} finally {
					preFactory.dispose(preService);
				}
			} catch (Exception e) {
				throw e;
			}
		}

		if (bdInfo != null) { // chiamata pre ok
			logger.debug("chiamata alla PRE ok!");
			String cognome = bdInfo.getTg_cognome() == null ? "" : bdInfo.getTg_cognome();
			String nome = bdInfo.getTg_nome() == null ? "" : bdInfo.getTg_nome();
			branchManager = cognome + " " + nome;
		}

		// chiamata facade per il recupero dei dati della carta e della variazione
		HashMap result = null;
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		try {
			IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
			try {
				result = serviceF.esgRetrieveBR0821PrintData((String) cardPrintIn.getContractNum().getValue());
				//LimitsVariationPrintData
			} catch (Exception e) {
				throw e;
			} finally {
				serviceFactory.dispose(serviceF);
			}
		} catch (Exception e) {
			throw e;
		}

		if (result != null && result.size() > 0) {
			cardType = result.containsKey("TIPO_CARTA") ? (String) result.get("TIPO_CARTA") : "";
			cardIdentifier = result.containsKey("NUMERO_CARTA") ? (String) result.get("NUMERO_CARTA") : "";
			cardRequestDate = result.containsKey("DATA_RICHIESTA") ? (String) result.get("DATA_RICHIESTA") : "";
			cardExpriryDate = result.containsKey("DATA_SCADENZA") ? (String) result.get("DATA_SCADENZA") : "";
			currentLimit = result.containsKey("LIMITE_ATTUALE") ? (String) result.get("LIMITE_ATTUALE") : "";
			newLimit = result.containsKey("LIMITE_RICHIESTO") ? (String) result.get("LIMITE_RICHIESTO") : "";
		}

		// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
		// [end] retrieve dei dati
		// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

		// XDocument creation
		printForm.addPrintVar("MODCSTR", branchCode);
		printForm.addPrintVar("MODSTRU", branchName);
		printForm.addPrintVar("MOD_CSTR", branchCode);
		printForm.addPrintVar("MOD_STRU", branchName);
		printForm.addPrintVar("MOD_MATR", operatorId);
		printForm.addPrintVar("MOD_LUOG", location);
		printForm.addPrintVar("MOD_DATA", date);
		printForm.addPrintVar("ANA_INTE11", heading);
		printForm.addPrintVar("ANA_DNAS01", birthdate);
		printForm.addPrintVar("ANA_SGRI00", ndgCardholder);
		printForm.addPrintVar("ANA_CFIS01", fiscalCode);
		printForm.addPrintVar("LAV01", branchManager);
		printForm.addPrintVar("LAV02", cardType);
		printForm.addPrintVar("LAV03", cardIdentifier);
		printForm.addPrintVar("LAV04", cardRequestDate);
		printForm.addPrintVar("LAV05", cardExpriryDate);
		printForm.addPrintVar("LAV06", currentLimit);
		printForm.addPrintVar("LAV07", newLimit);
		printForm.addPrintVar("LAV08", notes);

		printFormArray[0] = printForm;

		// definizione GaussResponse
		GaussResponse gaussResponse = new GaussResponse();
		ArrayList list = new ArrayList();
		HostResponseMessage hostResponseMessage = new HostResponseMessage();
		hostResponseMessage.setMessage("");
		list.add(hostResponseMessage);
		gaussResponse.setHostResponseMessage((HostResponseMessage[]) list.toArray(new HostResponseMessage[0]));

		// aggiungo dati alla responseClass
		responseClass.setPrintDoc(printFormArray);
		responseClass.setGaussResponse(gaussResponse);

		return responseClass;
	}
	
	
	/**
	 * La funzione stampa nel log le informazioni del documento XDocument (incluse le coppie chiave-valore passate al modulo)
	 * 
	 * @param document Il documento da stampare
	 */
	protected void debugXDocument(XDocument document) {

		logger.debug("");
		logger.debug("*********** XDocument debugger ***********");
		logger.debug(" > getAbiCode: " + document.getAbiCode());
		logger.debug(" > getAccountNumber: " + document.getAccountNumber());
		logger.debug(" > getAccountType: " + document.getAccountType());
		logger.debug(" > getApplicationCode: " + document.getApplicationCode());
		logger.debug(" > getBranch: " + document.getBranch());
		//logger.debug(" > getCenteraArchive: " + document.getCenteraArchive()); ee13331_xpi
		logger.debug(" > getDocumentCode: " + document.getDocumentCode());
		logger.debug(" > getDocumentNumber1: " + document.getDocumentNumber1());
		logger.debug(" > getDocumentNumber2: " + document.getDocumentNumber2());
		logger.debug(" > getFormName: " + document.getFormName());
		logger.debug(" > getHandle: " + document.getHandle());
		logger.debug(" > getHistoryXMLArchive: " + document.getHistoryXMLArchive());
		logger.debug(" > getJFormDocType: " + document.getJFormDocType());
		logger.debug(" > getModuleVersion: " + document.getModuleVersion());
		logger.debug(" > getNdg: " + document.getNdg());
		logger.debug(" > getPrinter: " + document.getPrinter());
		logger.debug(" > getUserID: " + document.getUserID());
		logger.debug(" > getDocumentDate: " + document.getDocumentDate());
		logger.debug(" > isInstantPrintOn: " + document.isInstantPrintOn());
		logger.debug(" > isPrintPanelOn: " + document.isPrintPanelOn());
		logger.debug(" > isPrintPreviewOn: " + document.isPrintPreviewOn());

		//logger.debug(" > getArray: ");
		//ArrayList array = document.getArray();
		//for (int j=0; j<array.size(); j++)
		//logger.debug("    - array element (" + j + "): " + array.get(j));

		logger.debug(" > mapValues: ");
		Map map = document.getMapValues();
		Iterator it = map.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			logger.debug("    - map element: " + pairs.getKey() + " = " + pairs.getValue());
		}

		logger.debug("*********** ****************** ***********");
	}

	// EE29052 - Firmamia - stored to determine whether the print is digital
	public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
		return GecUtilities.checkStoredFirmaMia(request, response);
	}

	public boolean xpiCheck(XDocument[] module){
		UserData dataInfo;
		try {
			dataInfo = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
		} catch (ServiceFactoryException e) {
			logger.error("Error while retrieving user info ", e);
			return false;
		} catch (RemoteException e) {
			logger.error("Error while retrieving user info ", e);
			return false;
		} catch (HostUserInfoException e) {
			logger.error("Error while retrieving user info ", e);
			return false;
		}
		String filialeOperatore = dataInfo.getFilialeOperatore();
		boolean xpiPaperlessFeasibilityResult;
		try {
			xpiPaperlessFeasibilityResult = checkBranch(filialeOperatore) && checkModule(module);
		} catch (Exception e) {
			logger.error("Error when checking module and branch paperless feasibility for FirmaMia ", e);
			return false;
		}
		if(xpiPaperlessFeasibilityResult){
			logger.info("PRINTCHECK - VADO IN DIGITALE");
		} else {
			logger.info("PRINTCHECK - VADO SU CARTA");
		}
		
		return xpiPaperlessFeasibilityResult;
	}

	private boolean checkBranch(String branch) throws Exception {
		logger.info("[EsgCardInquiryAction] - [checkBranch] - START");
		String paperlessFunction = XPIConstants.PAPERLESS_CHECK_BRANCH;
		boolean risultato = false;
		try {
			SignpadInOut signpadInOut = new SignpadInOut();
			signpadInOut.getFunction().setValue(paperlessFunction);
			signpadInOut.getOperatingBranch().setValue(branch);
			SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
			risultato = signpadResponseClass.isSignpadFeasibility();
			logger.info("***************** [EsgCardInquiryAction] - [checkBranch] filialeEvoluta: " + risultato);
		} catch (Exception e) {
			throw e;
		}
		return risultato;
	}

	private boolean checkModule(XDocument[] module) throws Exception {
		logger.info("[EsgCardInquiryAction] - [checkModule] - START");
		String paperlessFunction = XPIConstants.PAPERLESS_CHECK_MODULE;
		boolean risultato = false;
		try {
			SignpadInOut signpadInOut = new SignpadInOut();
			signpadInOut.getFunction().setValue(paperlessFunction);
			signpadInOut.setXDocs(module);
			SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
			risultato = signpadResponseClass.isSignpadFeasibility();
			logger.info("***************** [EsgCardInquiryAction] - [checkModule] modulo evoluto: " + risultato);
		} catch (Exception e) {
			throw e;
		}
		return risultato;
	}
	// EE29052 - Firmamia - END
}
