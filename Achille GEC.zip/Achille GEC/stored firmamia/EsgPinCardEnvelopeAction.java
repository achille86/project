/*
 * Created on Oct 24, 2013
 * Last Modified on Oct 24, 2013
 * Author: ee29570
 *  
 */
package it.usi.xframe.gec.pfstruts.actions.eurosig.pinCardEnvelope;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckInput;
import it.usi.xframe.gec.bfutil.cardIssue.PaperlessCheckOutput;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardInquiry.EsgCardInquiryInOut;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgPrintManager;
import it.usi.xframe.gec.bfutil.eurosig.pinCardEnvelope.EsgPinCardEnvelope;
import it.usi.xframe.gec.bfutil.eurosig.pinCardEnvelope.EsgPinCardEnvelopeManagementIn;
import it.usi.xframe.gec.bfutil.eurosig.pinCardEnvelope.EsgPinCardEnvelopeManagementOut;
import it.usi.xframe.gec.bfutil.eurosig.pinCardEnvelope.EsgPinCardEnvelopeManagementResponseClass;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.pfstruts.forms.eurosig.pinCardEnvelope.EsgPinCardEnvelopeManagementForm;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.gec.pfstruts.utilities.GecWebUtilities;
import it.usi.xframe.ifg.bfutil.IfgServiceFactory;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.HostPaginationHandler;
import it.usi.xframe.utl.bfutil.Utl;

/**
 * 
 * @author ee29570
 */
public class EsgPinCardEnvelopeAction extends DispatchAction {


	private static final String TITLE_HEADER_LABEL = "card.label.pinCardEnvelope.text";
	
	//private static final String REQUEST_ELEMENT_CLUSTER = "cluster";
	//private static final String REQUEST_FILTERVIEW 		= "filterView";
	//private static final String REQUEST_CURRENT_BATCH 	= "currentBatch";
	private static final String REQUEST_ROW 	= "row";
	private static final String REQUEST_VIEW 	= "view";
	
	private static final int	CONSTANT_FIRST_ROW 			= 0;
	private static final int	CONSTANT_ROW_FOR_PAGE 		= 10;
	
	private static final String	PATTERN_REQUEST_ID 		= "^CARD([0-9]+)-Index$";
	
	private static final String REQUEST_PREFIX 				= "CARD";
	
	//private static final String REQUEST_SUFFIX_INDEX 		= "Index";
	private static final String REQUEST_SUFFIX_BATCH_DATE 	= "BatchDate";
	private static final String REQUEST_SUFFIX_BATCH_PROGID = "BatchProgID";
	private static final String REQUEST_SUFFIX_CARDNUMBER	= "CardNumber";
	private static final String REQUEST_SUFFIX_PINENVNUMB	= "PinEnvNumb";
	private static final String REQUEST_SUFFIX_ELEMTYPE 	= "ElemType";
	private static final String REQUEST_SUFFIX_CARDOPER 	= "CardOper";
	private static final String REQUEST_SUFFIX_CONTRNUMB 	= "ContrNumb";
	private static final String REQUEST_SUFFIX_CONTRPROG 	= "ContrProg";
	
		
	private static Log logger = LogFactory.getLog(EsgPinCardEnvelopeAction.class);
	
	
	protected ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return this.createFrameContainer(mapping, form, request, response);
	}
	
	public ActionForward createFrameContainer(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("[EsgPinCardEnvelopeAction:createFrameContainer] -- CREATE CONTAINER --");
		return mapping.findForward("pinCardEnvelopeContainer");
	}

	
	/**
	 * Action per il recupero delle informazioni del lotto
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward retrieveCardsLot(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.debug("[EsgPinCardEnvelopeAction:retrieveCardsLot] -- INIT --");
		
		ActionForward forward = new ActionForward();
		
		EsgPinCardEnvelopeManagementForm actionForm = (EsgPinCardEnvelopeManagementForm) form;

		// Gestisce il primo session marker
		GecWebUtilities.manageSessionMarker(request);

		// gestione titleHeader e button Quickly knowledge base
		GecWebUtilities.createTitleHeader(request, TITLE_HEADER_LABEL, this.getClass());

		UserData datiUtente = GecWebUtilities.getUserData(request);
		
		GecUtilities.setSignpadVerifyURL(request);
		
		// gestione direction parametri di ricerca
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;

		//	----  1. make input data  ---------------------------------------------------------------------------------------------------------------------------------------------------

		EsgPinCardEnvelopeManagementResponseClass responseClass = new EsgPinCardEnvelopeManagementResponseClass();

		GecWebUtilities.debugRequest(request);

		EsgPinCardEnvelopeManagementIn in = actionForm.getIn();
		
		//	gestione dei dati di paginazione (HostPaginationHandler, numero righe totali, numero pagina, righe per pagina)
		HostPaginationHandler pagination = new HostPaginationHandler();
		
		String rowNumber = GecWebUtilities.getRequestParameter(request, REQUEST_ROW, String.valueOf(CONSTANT_FIRST_ROW));
		
		String initView = GecWebUtilities.getRequestParameter(request, REQUEST_VIEW, null);
		if (in.getFilterView().getValue() == null && initView != null){
			in.getFilterView().setValue(initView);
		}
		
		String updateView = (String)request.getAttribute("updateRequest"); 
		if (updateView != null) {
			//in.getCurrentBatchDate().setValue(null);
			in.getFilterView().setValue(updateView);
		}
		
		int page = 1;
		int row = 0;
		try {
			row = Integer.parseInt(rowNumber);
			page = (row / CONSTANT_ROW_FOR_PAGE) + 1;
		} catch(Exception e){}
		
		in.getPageNumber().setValue(String.valueOf(page));
		in.getRowForPage().setValue(String.valueOf(CONSTANT_ROW_FOR_PAGE));
		in.getBranch().setValue(datiUtente.getFilialeOperatore());
		
		
		if (in.getElementCluster().getValue() == null ||
			in.getElementCluster().getValue().equals("") ){
			in.getElementCluster().setValue("CF");
		}
		
		if (in.getFilterView().getValue() == null||
			in.getFilterView().getValue().equals("")) {
			in.getFilterView().setValue("VS");
		}
		
		logger.debug(in.toString());

		//	----  2. gauss service  ---------------------------------------------------------------------------------------------------------------------------------------------------

		try {
			// inquiry service input
			service = serviceFactory.getGecServiceFacade();
			
			
			// inquiry service lotto
			responseClass = service.esgPinCardEnvelopeRetrieveLot(in);
				
			// Add the information into form
			if (responseClass.getGaussResponse() != null && responseClass.getGaussResponse().isErrorFlag()){
				
				logger.debug("[EsgPinCardEnvelopeAction:retrieveCardsLot] : error in gauss response ");
				
			} else {
				
				EsgPinCardEnvelopeManagementOut out = responseClass.getEsgPinCardEnvelopeManagementOut();
				
				try {
					int totaleLotti = ((Number) out.getTotalRow().getValue()).intValue();
					//int totalePagine = ((Number) out.getPageNumber().getValue()).intValue();
					String otherPage = (String) out.getMorePages().getValue();
					boolean lastPage = true;
					if ("S".equals(otherPage)){
						lastPage = false;
					}
					pagination.setLastFlag(lastPage);
					pagination.setCurrentRow(row);
					pagination.setRowSize(totaleLotti);
					pagination.setRowForPage(CONSTANT_ROW_FOR_PAGE);
					
					request.setAttribute("row", rowNumber);
					request.setAttribute("pagination", pagination);
				} catch(Exception e) {
					//e.printStackTrace();
				}				
				actionForm.setOut(out);	
				
				// Informazioni sulle carte del lotto
				if (in.getCurrentBatchDate().getValue() != null){
					
					// inquiry service dettagli carta
					responseClass = service.esgPinCardEnvelopeRetrieveLotDetails(in);
					 
					// Add the information into form
					if (responseClass.getGaussResponse() != null && responseClass.getGaussResponse().isErrorFlag()){
						logger.debug("[EsgPinCardEnvelopeAction:retrieveCardsLot] : error in gauss response ");
					} else {
						actionForm.getOut().setPinCardEnvelopes(responseClass.getEsgPinCardEnvelopeManagementOut().getPinCardEnvelopes());
					}
				}
				
				// Esecuzione della stampa automatica in caso di nessun errore
				if (responseClass.getGaussResponse() == null || !responseClass.getGaussResponse().isErrorFlag()){
					
					EsgCardInquiryInOut params = new EsgCardInquiryInOut();
					// Recupero informazioni per la stampa 
					params.getContractNum().setValue(request.getAttribute("contractNumber"));
					params.getCardSeqNumber().setValue(request.getAttribute("cardSeqNumber"));
					GecWebUtilities.sendPrintInformation(request, params);
				}
			}
		} catch (Exception e) {
			logger.debug("[EsgPinCardEnvelopeAction:retrieveCardsLot] exception while calling inquiry service: " + e.getMessage());
			e.printStackTrace();
			throw new XFRException(e);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
	
		actionForm.getIn().setUserInfo(datiUtente);
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, responseClass.getGaussResponse());
		//	Default forward
		complexPopUpParams.setForward("pinCardEnvelope"); 
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.info("[EsgPinCardEnvelopeAction:retrieveCardsLot] ****** END ****** ");
		return forward;

	}
	
	
	
	/**
	 * Action per il recupero delle informazioni del lotto
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward updateCardsLot(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.debug("[EsgPinCardEnvelopeAction:updateCardsLot] -- INIT --");
		
		ActionForward forward = new ActionForward();
		
		EsgPinCardEnvelopeManagementForm actionForm = (EsgPinCardEnvelopeManagementForm) form;

		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;

		//	----  1. make input data  ---------------------------------------------------------------------------------------------------------------------------------------------------

		EsgPinCardEnvelopeManagementResponseClass responseClass = new EsgPinCardEnvelopeManagementResponseClass();

		UserData datiUtente = GecWebUtilities.getUserData(request);

		EsgPinCardEnvelopeManagementIn in = actionForm.getIn();
		
		
		ArrayList cardsList = makeListFromRequest(request);
		in.setPinCardEnvelopesUpdate(cardsList);		
		in.getBranch().setValue(datiUtente.getFilialeOperatore());
		in.setUserInfo(datiUtente);
		
		//	----  2. gauss service  ---------------------------------------------------------------------------------------------------------------------------------------------------

		try {
			// inquiry service input
			service = serviceFactory.getGecServiceFacade();
				
			responseClass = service.esgPinCardEnvelopeUpdate(in);
			
			// Add the information into form
			 if (responseClass.getGaussResponse() != null && responseClass.getGaussResponse().isErrorFlag()){
				logger.debug("[EsgPinCardEnvelopeAction:updateCardsLot] : error in gauss response ");
			 } else {
				 actionForm.setIn(in);
				 actionForm.setOut(responseClass.getEsgPinCardEnvelopeManagementOut());	
			 }
			// Add the information into form
				
		} catch (Exception e) {
			logger.debug("[EsgPinCardEnvelopeAction:updateCardsLot] exception while calling inquiry service: " + e.getMessage());
			e.printStackTrace();
			throw new XFRException(e);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		// Stampe automatiche
		managePrintInformation(request, responseClass.getPrintManager());
		
		request.getSession().setAttribute("storedOkAndNoTabletIssues", "false");
		boolean isPaper = "".equalsIgnoreCase(request.getParameter("tabletStatusKo"));
		if(!isPaper && !(request.getParameter("tabletStatusKo") != null && "true".equalsIgnoreCase(request.getParameter("tabletStatusKo")))) {
			logger.info("SETTO storedOkAndNoTabletIssues TO TRUE");
			request.getSession().setAttribute("storedOkAndNoTabletIssues", "true");
		}
			
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, responseClass.getGaussResponse());
		//	Default forward
		
		request.setAttribute("updateRequest", getView(cardsList));
		request.setAttribute("method", "retrieveCardsLot");
		
		complexPopUpParams.setActionBackMessage("esgPinCardEnvelope.do?method=retrieveCardsLot");
		complexPopUpParams.setReturnBackMessage(true);
		complexPopUpParams.setForward("pinCardEnvelope"); 
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.info("[EsgPinCardEnvelopeAction:updateCardsLot] ****** END ****** ");
		
		return forward;
	}
	
	/**
	 * Action per il recupero delle informazioni del lotto
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward restoreCardLot(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.debug("[EsgPinCardEnvelopeAction:restoreCardLot] -- INIT --");
	
		ActionForward forward = new ActionForward();
	
		EsgPinCardEnvelopeManagementForm actionForm = (EsgPinCardEnvelopeManagementForm) form;

		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;

		//	----  1. make input data  ---------------------------------------------------------------------------------------------------------------------------------------------------

		EsgPinCardEnvelopeManagementResponseClass responseClass = new EsgPinCardEnvelopeManagementResponseClass();

		UserData datiUtente = GecWebUtilities.getUserData(request);

		EsgPinCardEnvelopeManagementIn in = actionForm.getIn();
	
		in.getBranch().setValue(datiUtente.getFilialeOperatore());
		in.setUserInfo(datiUtente);
	
		//	----  2. gauss service  ---------------------------------------------------------------------------------------------------------------------------------------------------

		try {
			// inquiry service input
			service = serviceFactory.getGecServiceFacade();
			
			responseClass = service.esgPinCardEnvelopeRestoreLot(in);
		
			// Add the information into form
			 if (responseClass.getGaussResponse() != null && responseClass.getGaussResponse().isErrorFlag()){
				logger.debug("[EsgPinCardEnvelopeAction:restoreCardLot] : error in gauss response ");
			 } else {
				 actionForm.setIn(in);
				 actionForm.setOut(responseClass.getEsgPinCardEnvelopeManagementOut());	
			 }
			// Add the information into form
			
		} catch (Exception e) {
			logger.debug("[EsgPinCardEnvelopeAction:restoreCardLot] exception while calling inquiry service: " + e.getMessage());
			e.printStackTrace();
			throw new XFRException(e);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, responseClass.getGaussResponse());
		//	Default forward
	
		request.setAttribute(REQUEST_ROW, String.valueOf(CONSTANT_FIRST_ROW));
		request.setAttribute("updateRequest", "VS");
		request.setAttribute("method", "retrieveCardsLot");
	
		complexPopUpParams.setActionBackMessage("esgPinCardEnvelope.do?method=retrieveCardsLot&row=0");
		complexPopUpParams.setReturnBackMessage(true);
		complexPopUpParams.setForward("pinCardEnvelope"); 
		forward = Utl.createComplexPopUp(complexPopUpParams);

		logger.info("[EsgPinCardEnvelopeAction:restoreCardLot] ****** END ****** ");
	
		return forward;
	}
	
	
	/**
	 * This function retrive parameter's request to inizialize "EsgPinCardEnvelope" field.   
	 * @param request
	 * @return
	 */
	private ArrayList makeListFromRequest(HttpServletRequest request) {
		ArrayList list = new ArrayList();

		Enumeration names = request.getParameterNames();
		logger.debug("##### PARAMETER NAMES #########>>>>");
		while(names.hasMoreElements()) {
			String name = (String)names.nextElement();
			if (name.matches(PATTERN_REQUEST_ID)) {
				EsgPinCardEnvelope card = new EsgPinCardEnvelope();
				String id = request.getParameter(name);
				if (id != null && id.length() > 0) {
					try {				
						String operation = request.getParameter(					REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_CARDOPER);
						card.getCardOperation().setValue(operation);
						// Check if a operation is selected 
						if (operation != null && operation.length() > 0) {
							card.getBatchDate().setValue(request.getParameter(			REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_BATCH_DATE));
							card.getBatchProgressiveID().setValue(request.getParameter(	REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_BATCH_PROGID));
							card.getCardNumber().setValue(request.getParameter(			REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_CARDNUMBER));
							card.getPinEnvelopeNumber().setValue(request.getParameter(	REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_PINENVNUMB));
							card.getElementType().setValue(request.getParameter(		REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_ELEMTYPE)); 	
							list.add(card);
							
							// In caso di consegna della carta si inserisco le informazioni in request per la stampa automatica
							if ("KC".equals(operation)){
								request.setAttribute("contractNumber", request.getParameter(	REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_CONTRNUMB));
								request.setAttribute("cardSeqNumber", request.getParameter(		REQUEST_PREFIX + id + "-" + REQUEST_SUFFIX_CONTRPROG));
							}
							
							
							logger.debug("##### CARD #########>>>> " + id + " : " + card.getCardNumber().getValue() + " : " + card.getCardOperation().getValue());			
						}
					} catch(Exception e) {} 			
				}
			}
		}
		logger.debug("##### END PARAMETER NAMES  #########<<<");
		return list;
	}
	
	/**
	 * This function retrive view from list of card to update.   
	 * @param cardsList
	 * @return Type of view : "VS","VC","VD","VM"
	 */
	private String getView(ArrayList cardsList) {
		if (cardsList != null){
			int damageCount = 0, missingCount = 0;
			for (int i = 0; i < cardsList.size(); i++) {
				EsgPinCardEnvelope card = (EsgPinCardEnvelope)cardsList.get(i);
				String oper = (String)card.getCardOperation().getValue();
				if ("KK".equals(oper)){
					return "VS";
				} else if ("KC".equals(oper)) {
					return "VC";				
				} else if ("KD".equals(oper)) {
					damageCount++;
				} else if ("KM".equals(oper)) {
					missingCount++;
				}
			}
			if (missingCount > 0){
				return "VM";
			} else if (damageCount > 0) {
				return "VD";
			}
		}
		return "VS";  
	}
	
	/**
	 * Gestisce in sessione l'informazione relativa alle stampe automatiche
	 * @param printManager
	 */
	protected void managePrintInformation(HttpServletRequest request, EsgPrintManager printManager) {
		
		logger.debug("[EsgPinCardEnvelopeAction - managePrintInformation] -- INIT --");
		logger.debug("[EsgPinCardEnvelopeAction - managePrintInformation]   printManager is null? " + (printManager == null));
		
		if (request != null && printManager != null) {
			request.getSession().setAttribute(GecWebConstants.ESG_PRINT_MANAGER, printManager);
			logger.debug("[EsgPinCardEnvelopeAction - managePrintInformation]   printManager in session (attribute name: " + GecWebConstants.ESG_PRINT_MANAGER + ")");
		}
		logger.debug("[EsgPinCardEnvelopeAction - managePrintInformation] -- END --");
	}
	
	
	// EE29052 - Firmamia - stored to determine whether the print is digital
	public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
		return GecUtilities.checkStoredFirmaMia(request, response);
	}
	// EE29052 - Firmamia - END
	
	
	// EE29052 - Firmamia - stored to determine whether the print is digital
		/*public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
			logger.info("EsgPinCardEnvelopeAction.checkStoredFirmaMia --- start");
			
			String toReturn = "KO";
			
			if(EsgCountryCode.isItalianCountry()){
				if(GecUtilities.isFirmaMiaSkipTabletCheckSet()){
					logger.info("SKIPPING STORED CHECK");
					toReturn = "OK";
				} else {
					String module = request.getParameter("module");
					logger.debug("EsgPinCardEnvelopeAction.checkStored --- module: " + module);
					
					UserData userData = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
					String branch = userData.getFilialeOperatore() != null ? userData.getFilialeOperatore() : "";
					
					PaperlessCheckInput input = new PaperlessCheckInput();
					input.setModulo(module);
					input.setFiliale(branch);
					
					logger.info("PILOTBRANCHCHECK - BRANCH: " + branch + " MODULE: " + module);
					
					// -- 3 -- chiamata al servizio -----------------------------------------------------------------------------------------------------
					
					PaperlessCheckOutput output = new PaperlessCheckOutput();		
					GecServiceFactory serviceF = GecServiceFactory.getInstance();
					IGecServiceFacade serv = serviceF.getGecServiceFacade();
					try {
						// service call
						output = serv.retrievePaperlessCheck(input);
					} finally {
						serviceF.dispose(serv);
					}
					
					if (output.getReturnCode() == 0) { // service call OK
						logger.info("GECKSFMR RESPONSE OK. flagRetry = " + output.getFlagRetry());
						if("[Y]".equalsIgnoreCase(output.getFlagRetry().trim())) {
							toReturn = "OK";
						}
					} else {
						logger.info("GECKSFMR RESPONSE KO");
						toReturn = "KO";
					}
				}
			}
			
			String jsonResult = "{\"result\" : \"" + toReturn + "\"}";
			logger.info("JSONRESULT = " + jsonResult);
			
			response.setHeader("Content-Type", "application/json; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.write(jsonResult);
			out.flush();
			out.close();
			logger.info("EsgPinCardEnvelopeAction.checkStoredFirmaMia --- end");
			return null;
		}*/
		// EE29052 - Firmamia - END

}
