 /*
 * Created on Nov 16, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package it.usi.xframe.gec.pfstruts.actions;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionRedirect;
import org.apache.struts.actions.LookupDispatchAction;

import eu.unicredit.xframe.ds2.ws.processtrack.ProcessTrackBean;
import eu.unicredit.xframe.ds2.ws.services.ArchiveModuleListDto;
import eu.unicredit.xframe.ds2.ws.services.ArchivingResult;
import eu.unicredit.xframe.ds2.ws.services.Field;
import eu.unicredit.xframe.ds2.ws.services.InputDataVO;
import eu.unicredit.xframe.ds2.ws.services.OutputResponse;
import eu.unicredit.xframe.dsi.ws.basket.CallbackParameter;
import eu.unicredit.xframe.dsi.ws.basket.Customer;
import eu.unicredit.xframe.dsi.ws.basket.CustomerMailNotificationSpecification;
import eu.unicredit.xframe.dsi.ws.basket.CustomerNotificationResponse;
import eu.unicredit.xframe.dsi.ws.basket.CustomerNotificationSpecification;
import eu.unicredit.xframe.dsi.ws.basket.CustomerNotificationTypeEnum;
import eu.unicredit.xframe.dsi.ws.basket.DocumentParameter;
import eu.unicredit.xframe.dsi.ws.basket.DossierData;
import eu.unicredit.xframe.dsi.ws.basket.DossierDocument;
import eu.unicredit.xframe.dsi.ws.basket.DossierDocumentInput;
import eu.unicredit.xframe.dsi.ws.basket.DossierDocumentOutput;
import eu.unicredit.xframe.dsi.ws.basket.DossierInput;
import eu.unicredit.xframe.dsi.ws.basket.DossierOutput;
import eu.unicredit.xframe.dsi.ws.basket.DossierParameter;
import eu.unicredit.xframe.dsi.ws.basket.FieldType;
import eu.unicredit.xframe.dsi.ws.basket.MailAttachmentSpecification;
import eu.unicredit.xframe.dsi.ws.basket.ProcessInfo;
import eu.unicredit.xframe.dsi.ws.basket.ProcessParams;
import eu.unicredit.xframe.dsi.ws.basket.RequestInfoSpecification;
import it.usi.warranter.Warranty2;
import it.usi.warranter.WarrantyTracer;
import it.usi.xframe.afa.bfutil.AFAServiceFactory;
import it.usi.xframe.afa.bfutil.SearchCustomerParams;
import it.usi.xframe.ctb.ws.agreedset.AgreedSetRequest;
import it.usi.xframe.ctb.ws.agreedset.AgreedSetRequestElement;
import it.usi.xframe.ctb.ws.agreedset.AgreedSetResponse;
import it.usi.xframe.ctb.ws.printout.CtbWsPrintDocument;
import it.usi.xframe.gec.bfintf.IGecServiceFacade;
import it.usi.xframe.gec.bfutil.cardIssue.Account;
import it.usi.xframe.gec.bfutil.cardIssue.CardIssueConfirmResponseClass;
import it.usi.xframe.gec.bfutil.cardIssue.CardIssueHolder;
import it.usi.xframe.gec.bfutil.cardIssue.CardIssueResponseClass;
import it.usi.xframe.gec.bfutil.cardIssue.CardType;
import it.usi.xframe.gec.bfutil.cardIssue.DebitCardIssueInOut;
import it.usi.xframe.gec.bfutil.eurosig.EsgCountryCode;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpAddressManagement;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpDeliveryManagement;
import it.usi.xframe.gec.bfutil.eurosig.cardOperations.EsgCardOpNdgConnectedRequestInOut;
import it.usi.xframe.gec.bfutil.general.GecConstants;
import it.usi.xframe.gec.bfutil.general.GecServiceFactory;
import it.usi.xframe.gec.bfutil.general.SessionData;
import it.usi.xframe.gec.bfutil.inquiryBancomat.DebitFastPayInOut;
import it.usi.xframe.gec.bfutil.inquiryBancomat.InquiryBancomatResponseClass;
import it.usi.xframe.gec.bfutil.smssend.SendSmsInput;
import it.usi.xframe.gec.bfutil.smssend.SendSmsOutput;
import it.usi.xframe.gec.bfutil.utilities.GecUtilities;
import it.usi.xframe.gec.ds2.DS2Config;
import it.usi.xframe.gec.pfstruts.forms.CardIssueForm;
import it.usi.xframe.gec.pfstruts.utilities.CardTypeConverter;
import it.usi.xframe.gec.pfstruts.utilities.GecWebConstants;
import it.usi.xframe.gec.pfstruts.utilities.GecWebUtilities;
import it.usi.xframe.gec.pfstruts.utilities.MarkedSessionManager;
import it.usi.xframe.ifg.bfutil.HostUserInfoException;
import it.usi.xframe.ifg.bfutil.IfgServiceFactory;
import it.usi.xframe.ifg.bfutil.wpro.UserData;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.system.eservice.ServiceFactoryException;
import it.usi.xframe.system.pfutil.struts.errors.XfrMessage;
import it.usi.xframe.utl.bfutil.ComplexPopUpParams;
import it.usi.xframe.utl.bfutil.FormatUtils;
import it.usi.xframe.utl.bfutil.GaussResponse;
import it.usi.xframe.utl.bfutil.HostResponse;
import it.usi.xframe.utl.bfutil.HostResponseMessage;
import it.usi.xframe.utl.bfutil.HostResponseParams;
import it.usi.xframe.utl.bfutil.Utl;
import it.usi.xframe.xpi.bfutil.Signer;
import it.usi.xframe.xpi.bfutil.XDocument;
import it.usi.xframe.xpi.bfutil.XPIConstants;
import it.usi.xframe.xpi.bfutil.XPrintUtilities;
import it.usi.xframe.xpi.bfutil.signpad.SignpadInOut;
import it.usi.xframe.xpi.bfutil.signpad.SignpadResponseClass;
import it.usi.xframe.xpi.bfutil.signpad.SignpadUtilities;


/**
 * @author EE01603
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CardIssueAction extends LookupDispatchAction{

	static Log logger = LogFactory.getLog(CardIssueAction.class);
	
	// Variabili controllo DS2
	private final String DS2_BVI = "N";
	private final String DS2_SELECTSIGNER = "N";
	private final String DS2_SHOWHTML="N";
	private final String DS2_SKIPSMS = "N";
	// Applico un default sulla gerarchia in quanto non riesco a recuperare il tipo di contratto per la sezione debito OLD
	private final String SP_DEFAULT_HIERARCHY="01";
	// Defaultizza il valore del flag front-end.
	// con FLAG_FE = "0" allora indico che l'origine della chiamata alla SP
	// proviene dal mondo Debito OLD
	private final String SP_DEFAULT_FLAG_FE="O";
	// Definizione della Action di Call Back per la 
	// chiamata a DS2	
	// TODO - Da Rimuovere
	private final String CALL_BACK_ACTION = "/XA-GEC-PF/callBackAction.do";
	//FIRMAMIA EE57985
	private static final String MODULE = "BU1077";
	
	// DMB constants
//	private final String CARD_ISSUE_RESPONSE_CLASS = "CARD_ISSUE_RESPONSE_CLASS";
//	private final String CARD_ISSUE_FORM_CLASS = "CARD_ISSUE_FORM_CLASS";
	private final String DEBIT_CARD_ISSUE_IN_OUT = "DEBIT_CARD_ISSUE_IN_OUT";
	public static final String SP_DMB_FLAG_FE = "O_DMB"; // Emissione Old for MBE MAES, MBE MVAP, MBV TEEN (modules BU0323 or BR0646)
	public static final String SP_DMB_V_FLAG_FE = "V_DMB"; // Emissione Old for CC  VERN, CC  VERP (module BR0605)
	public static final String NO_DMB = "noDMB";
	private static final String ISSUE_FUNCTION = "Emissione";
	private static final String GEC_APPLICATION = "GEC";
	private static final String EXPIRATION_TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	private static final String DMB_REMOTE_CHANNEL = "DMB_REMOTO";
	
	// Card Type
	private static final String CARD_TYPE_MBV_TEEN = "MBV TEEN";
	private static final String CARD_TYPE_MBE_MAES = "MBE MAES";
	private static final String CARD_TYPE_MBV_MVAP = "MBE MVAP";
	private static final String CARD_TYPE_CC_VERN = "CC  VERN";
	private static final String CARD_TYPE_CC_VERP = "CC  VERP";
	
	// Module Codes
	private static final String BR0646 = "BR0646";
	private static final String BR0605 = "BR0605";
	private static final String BU0323 = "BU0323";

	private Map map = new HashMap();

	protected Map getKeyMethodMap() {
		return map;
	}
	
	/**
	 *
	 */
	public CardIssueAction() {
		Map map = this.getKeyMethodMap();
		map.put("mapping.cardIssue.cardIssueConfirm", "cardIssueConfirm");
		map.put("mapping.cardIssue.cardIssueBMConfirm", "cardIssueBMConfirm");
		map.put("mapping.cardIssue.cardIssueVRConfirm", "cardIssueVRConfirm");
		map.put("mapping.cardIssue.cardIssueBMVRConfirm", "cardIssueBMVRConfirm");
		map.put("mapping.cardIssue.cardIssueRefresh", "cardIssueRefresh");
		map.put("mapping.cardIssue.cardIssueVRRefresh", "cardIssueVRRefresh");
		map.put("mapping.cardIssue.cardIssueUpdateFastPay", "cardIssueUpdateFastPay");
		map.put("mapping.cardIssue.normalizeAddress", "normalizeAddress");
		map.put("mapping.cardIssue.cardIssuePrintPrepare", "cardIssuePrintPrepare");
		map.put("mapping.cardIssue.checkSignatureProcessOutcome", "checkSignatureProcessOutcome");
		map.put("mapping.cardIssue.checkStored", "checkStored");
		map.put("mapping.cardIssue.verify", "verify");
	}

	
	/**
	 * 
	 */
	protected ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.info("[CardIssueAction - unspecified] --- init ---");
		
		//parametro per carte versamento
		String kind=request.getParameter("kind");
		ActionForward forward=new ActionForward();
		//call prepare for cardIssueVR or cardIssue
		if(kind!=null && kind.equals("5V"))
	     forward= cardIssueVRPrepareEmisAction(forward,mapping, request,kind);
		else
		 forward= cardIssuePrepareEmisAction(forward,mapping, form, request,kind);
		logger.info("[CardIssueAction - unspecified] --- end ---");
		return forward;
	}

	private ActionForward cardIssuePrepareEmisAction(ActionForward forward,ActionMapping mapping, ActionForm form,
			HttpServletRequest request, String kind) throws XFRException,
			Exception {
		
		CardIssueForm cardIssueForm = (CardIssueForm) form;
		
		GecUtilities.setSignpadVerifyURL(request);
		
		logger.info("[CardIssueAction - cardIssuePrepareEmisAction] --- init ---");
		MarkedSessionManager.getInstance().removeMarkedSessionAttribute(request, "sessionData");
		String sessionMarker = request.getParameter("sessionMarker");

		if (sessionMarker == null || sessionMarker.equals("")) {
			sessionMarker = request.getParameter("ndg");
		}
		request.setAttribute("sessionMarker", sessionMarker);

		String printFlag = request.getParameter("printFlag");
		if (printFlag == null || printFlag.equals("")) {
			printFlag = "false";
		}
		request.setAttribute("printFlag", printFlag);
		
		/*** BUSTAPINOLD ***
		 * Y: Input Busta Pin Digitabile dall'operatore per i tipi carte non 'LL  LIBR'
		 * N: Input Busta Pin non visualizzato per i tipi carte non 'LL  LIBR'
		 *******************/
		request.setAttribute("bustaPinOld", GecUtilities.isGecParameterSet(GecConstants.BUSTAPINOLD_PARAM, "DEVELOP", "Y", true) ? "Y" : "N");
		
		/*** LIBRPINOLD ***
		 * Y: Input Busta Pin Digitabile dall'operatore per i tipi carte 'LL  LIBR'
		 * N: Input Busta Pin non visualizzato per i tipi carte 'LL  LIBR'
		 *******************/
		request.setAttribute("librPinOld", GecUtilities.isGecParameterSet(GecConstants.LIBRPINOLD_PARAM, "DEVELOP", "Y", true) ? "Y" : "N");

		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");
		MarkedSessionManager markedSessionManager = new MarkedSessionManager();

		if (sessionData == null) {
			logger.info("[CardIssueAction - cardIssuePrepareEmisAction] session data is null");
			sessionData = new SessionData();
			sessionData.setNdg(request.getParameter("ndg"));
			markedSessionManager.setMarkedSessionAttribute(request, "sessionData", sessionData);
		}

		// gauss service input definition
		DebitCardIssueInOut inputParams = new DebitCardIssueInOut();
		inputParams.setCustomerNdg(request.getParameter("ndg"));
		logger.info("[CardIssueAction - cardIssuePrepareEmisAction] inputParams: " + inputParams.toJson());
		
		// gauss service call
		CardIssueResponseClass responseClass = new CardIssueResponseClass();
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;

		try {
			service = serviceFactory.getGecServiceFacade();
			responseClass = service.debitCardIssueRetrieve(inputParams);
			
			

			if (responseClass.getGaussResponse() == null || !responseClass.getGaussResponse().isErrorFlag()) { // gauss service ok
				
				cardIssueForm.getDebitFastPayInOut().getNormAddressUrl().setValue(responseClass.getNormUrl());
				
				cardIssueForm.getDebitFastPayInOut().getShowShipmentFeeFlag().setValue("Y");
				cardIssueForm.getDebitFastPayInOut().getNormAddressFlag().setValue("Y");
				
				HashMap deliveriesMap = new HashMap();
				
				for(int i = 0; i < responseClass.getCardType().length; i++){
					CardType ct = responseClass.getCardType()[i];
					deliveriesMap.put(ct.getCardType(), (ct.getFlagSpedStandard() + ct.getFlagSpedBranch() + ct.getFlagSpedOther()).trim());
					ArrayList deliveries = (ArrayList) cardIssueForm.getDebitFastPayInOut().getDeliveries();
					EsgCardOpDeliveryManagement delivery = new EsgCardOpDeliveryManagement();
					delivery.getEnabled().setValue("Y");
					delivery.getSelected().setValue("N");
					delivery.getFeeShipment().setValue("Y");
					delivery.getAddresses().setValue((ct.getFlagSpedStandard() + ct.getFlagSpedBranch() + ct.getFlagSpedOther()).trim());
					deliveries.add(delivery);
					cardIssueForm.getDebitFastPayInOut().setDeliveries(deliveries);
				}
				
				HashMap map = new HashMap();
				
				int ndgNumber = 0;
				String singleNDG = "";
				String firstNDG = "";
				
				for(int i = 0; i < responseClass.getCardIssueHolder().length; i++){
					CardIssueHolder holder = responseClass.getCardIssueHolder()[i];
					if(!"X".equalsIgnoreCase(holder.getFlagOrig())) {
						if("".equalsIgnoreCase(firstNDG)){
							firstNDG = holder.getClientId();
						}
						singleNDG = holder.getClientId();
					}
					ndgNumber = "X".equalsIgnoreCase(holder.getFlagOrig()) ? ndgNumber : ndgNumber + 1;
					for(int j = 0; j < holder.getAccountList().length; j++){
						
						Account account = holder.getAccountList()[j];						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_S_" + "ROW01", 
								account.getStandardAddress().getHolderName());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_S_" + "ROW02", 
								holder.getBranchDescription());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_S_" + "ROW03", 
								account.getStandardAddress().getAddress());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_S_" + "ROW04", 
								account.getStandardAddress().getCap() + " " + account.getStandardAddress().getLocality() + " " + account.getStandardAddress().getProvince());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_S_" + "ROW05", 
								" ");
						
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_B_" + "ROW01", 
								account.getBranch() + " " + account.getBranchAddress().getBranchDescr());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_B_" + "ROW02", 
								account.getBranchAddress().getAddress());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_B_" + "ROW03", 
								account.getBranchAddress().getCap() + " " + account.getBranchAddress().getLocality());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_B_" + "ROW04", 
								account.getBranchAddress().getTel());
						map.put(holder.getClientId() + "_" + account.getType() + "_" + account.getBranch() + "_" + account.getAccountId() + "_B_" + "ROW05", 
								" ");
						
						if(cardIssueForm.getDebitFastPayInOut().getAddresses().size() < 3){
							ArrayList addresses = (ArrayList) cardIssueForm.getDebitFastPayInOut().getAddresses();
							EsgCardOpAddressManagement addressS = new EsgCardOpAddressManagement();
							addressS.getTypeCode().setValue("S");
							addressS.getTypeDescription().setValue("Indirizzo standard");
							addressS.getEnabled().setValue("Y");
							addressS.getSelected().setValue("N");
							addressS.getAddressRow01().setValue(account.getStandardAddress().getHolderName());
							addressS.getAddressRow02().setValue(holder.getBranchDescription());
							addressS.getAddressRow03().setValue(account.getStandardAddress().getAddress());
							addressS.getAddressRow04().setValue(account.getStandardAddress().getCap() + " " + account.getStandardAddress().getLocality() + " " + account.getStandardAddress().getProvince());
							
							EsgCardOpAddressManagement addressB = new EsgCardOpAddressManagement();
							addressB.getTypeCode().setValue("B");
							addressB.getTypeDescription().setValue("Indirizzo filiale");
							addressB.getEnabled().setValue("Y");
							addressB.getSelected().setValue("N");
							addressB.getAddressRow01().setValue(account.getBranch() + " " + account.getBranchAddress().getBranchDescr());
							addressB.getAddressRow02().setValue(account.getBranchAddress().getAddress());
							addressB.getAddressRow03().setValue(account.getBranchAddress().getCap() + " " + account.getBranchAddress().getLocality());
							addressB.getAddressRow04().setValue(account.getBranchAddress().getTel());
							
							EsgCardOpAddressManagement addressO = new EsgCardOpAddressManagement();
							addressO.getTypeCode().setValue("O");
							addressO.getTypeDescription().setValue("Indirizzo alternativo");
							addressO.getEnabled().setValue("Y");
							addressO.getSelected().setValue("N");
							addressO.getAddressRow01().setValue(addressS.getAddressRow01().getValue());
							
							addresses.add(addressS);
							addresses.add(addressB);
							addresses.add(addressO);
							cardIssueForm.getDebitFastPayInOut().setAddresses(addresses);
						}
					}
				}
				
				if(responseClass.getCardIssueHolder().length == 1) {
					ndgNumber = 1;
					singleNDG = responseClass.getCardIssueHolder()[0].getClientId();
				}
				
				request.setAttribute("singleNDG", ndgNumber == 1 ? singleNDG : "false");
				request.setAttribute("addressesMap", map);
				request.setAttribute("deliveriesMap", deliveriesMap);
				request.setAttribute("prepareEmis", "true");
				request.setAttribute("firstNDG", firstNDG);
				
				logger.info("[CardIssueAction - cardIssuePrepareEmisAction] gauss service correctly performed");
				
				request.setAttribute("cardIssueArray", responseClass.getCardIssueHolder());
				sessionData.setCardIssueArray(responseClass.getCardIssueHolder());
				
				request.setAttribute("jsonAccountList", getJsonAccountList(responseClass.getCardIssueHolder()));
				
				request.setAttribute("cardTypeArray", responseClass.getCardType());
				sessionData.setCardType(responseClass.getCardType());
				
				String fastPayFlag = "";
				if(responseClass.getCardType() != null
					&& responseClass.getCardType().length > 0) {
					fastPayFlag = responseClass.getCardType()[0].getFlagArea();
					
				}
				request.setAttribute("fastPayFlag", fastPayFlag);
				
				/*** STOCKCARDTYPES ***
				 * AREA_PARAM from GECKPARAMETRI; compose:
				 * "Y,MBVSPAY,XXXXXXXX,"
				 *  | |_______________|
				 *  | |
				 *  | |_ Card stock types (comma "," as separator)
				 *  | 
				 *  |___Flag visible  Y: Envelope number box visible for the card stock types listed
				 *  |________________ N: Envelope number box disabled for all card types
				 *******************/
				String result = GecUtilities.getGecParameterArea(GecConstants.STOCKCARDTYPES_PARAM, "DEVELOP");
				if (StringUtils.isNotEmpty(result)) {
					String flagVisible = result.substring(0, 1);
					
					String[] stockCardTypes = result.substring(2).split(",");
					for (int j = 0; j < responseClass.getCardType().length; j++) {
						if (flagVisible.equals("Y")) {
							for (int k = 0; k< stockCardTypes.length; k++) {
								if (responseClass.getCardType()[j].getCardType().replaceAll("\\s+", "").equals(stockCardTypes[k])) {
									responseClass.getCardType()[j].setisStockCardType("Y");
								} // if stockCardTypes
							} // for j
						} else {
							responseClass.getCardType()[j].setisStockCardType("N");
						} // if else flagVisibile Y
					} // for i
				} // if isNotEmpty

				request.setAttribute("noteMarks", responseClass.getNoteMarks());
				sessionData.setNoteMarks(responseClass.getNoteMarks());

				for (int j = 0; j < responseClass.getCardIssueHolder().length; j++) {
					if (responseClass.getCardIssueHolder()[j].getFlagOrig().equalsIgnoreCase("X")) {
						sessionData.setClientDescription(responseClass.getCardIssueHolder()[j].getClientDescription());	
					}

					/* EE29570 - Garante2 start */
					if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){ 				
						log.debug("GARANTE2 LOG STARTS");
						try {
							Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(2, it.usi.warranter.Utils.REQUEST_TYPE_INQUIRY, request); 				
							if (warranty2 != null) {
								String accountNumber = "";
								String accountBranch = "";
								String ndgClientCode = "";
								String siaCode 	= "";
								String cidCode 	= "";
								String accountType 	= "";
								String accountIBAN 	= "";
								String accountABI 	= "";
								String accountCAB 	= "";
			
								Account[] accountListInOut = responseClass.getCardIssueHolder()[j].getAccountList();
								for(int k = 0; k< accountListInOut.length; ++k){
									accountNumber = FormatUtils.formatString(accountListInOut[k].getAccountId());
									ndgClientCode = FormatUtils.formatString(accountListInOut[k].getAccountNdg());
									accountBranch = FormatUtils.formatString(accountListInOut[k].getBranch());							
									accountType = FormatUtils.formatString(accountListInOut[k].getType());
									GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
									warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
								}
								if (warranty2.getParams().size() > 0)
									WarrantyTracer.trace(warranty2);
									
							}
							log.debug("GARANTE2 LOG ENDS");

						} catch (Exception e) {
							logger.info("[CardIssueAction: cardIssuePrepareEmisAction] GARANTE2 exception: " + e.getMessage(), e);
							throw new XFRException(e);
						}
					}
					/* Garante2 end	*/			
				}
			} else { // gauss service error
				logger.info("[CardIssueAction - cardIssuePrepareEmisAction] gauss service ended with errors");
			}
		} catch (Exception e) {
			throw new XFRException(e);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		
		// ee21246 leggo la sessione e verifivo se � stata gi� valorizzata nel giro di conferma con il messaggio di errore, per non sovrascriverla con il warning
		GaussResponse issueConfirmMessage = (GaussResponse) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "issueConfirmMessage");
		boolean severeError = true;
		if (issueConfirmMessage != null) {
			responseClass.setGaussResponse(issueConfirmMessage);
			severeError = false;
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "issueConfirmMessage", null);
		}
				
		// forward management
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, responseClass.getGaussResponse());
		complexPopUpParams.setActionBackError("");
		complexPopUpParams.setActionBackMessage("");
		complexPopUpParams.setActionBackConfirm("");
		complexPopUpParams.setActionConfirm("");
		complexPopUpParams.setErrorForward("");
		complexPopUpParams.setSevereError(severeError);
		complexPopUpParams.setReturnBackError(false);
		complexPopUpParams.setReturnBackMessage(false);
		complexPopUpParams.setForwardBackError(false);
		complexPopUpParams.setForward("cardIssueFirstPage");
		forward = Utl.createComplexPopUp(complexPopUpParams);
		
		// title header and quickly (knowledge base) button management
		GecWebUtilities.createTitleHeader(request, "menu.label.cardIssue.text", this.getClass());
		logger.info("[CardIssueAction - cardIssuePrepareEmisAction] --- end ---");
		return forward;
	}

	private ActionForward cardIssueVRPrepareEmisAction(ActionForward forward,ActionMapping mapping,
			HttpServletRequest request, String kind) throws XFRException,
			Exception {
		
		
		logger.info("[CardIssueAction - cardIssueVRPrepareEmisAction] --- init ---");
		MarkedSessionManager.getInstance().removeMarkedSessionAttribute(request, "sessionData");
		String sessionMarker = request.getParameter("sessionMarker");

		if (sessionMarker == null || sessionMarker.equals("")) {
			sessionMarker = request.getParameter("ndg");
		}
		request.setAttribute("sessionMarker", sessionMarker);

		String printFlag = request.getParameter("printFlag");
		if (printFlag == null || printFlag.equals("")) {
			printFlag = "false";
		}
		request.setAttribute("printFlag", printFlag);

		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");
		MarkedSessionManager markedSessionManager = new MarkedSessionManager();

		if (sessionData == null) {
			logger.info("[CardIssueAction - cardIssueVRPrepareEmisAction] session data is null");
			sessionData = new SessionData();
			sessionData.setNdg(request.getParameter("ndg"));
			
			markedSessionManager.setMarkedSessionAttribute(request, "sessionData", sessionData);
		}
		sessionData.setKind(request.getParameter("kind"));
		
		logger.info("[CardIssueAction - cardIssueVRPrepareEmisAction] sessionData: " + sessionData.getDebugString());

		// gauss service input definition
		DebitCardIssueInOut inputParams = new DebitCardIssueInOut();
		inputParams.setCustomerNdg(request.getParameter("ndg"));
		logger.info("[CardIssueAction - cardIssueVRPrepareEmisAction] inputParams: " + inputParams.toJson());
		
		// gaus service call
		CardIssueResponseClass responseClass = new CardIssueResponseClass();
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;

		try {
			service = serviceFactory.getGecServiceFacade();
		    responseClass = service.paymentCardIssueRetrieve(inputParams);
		    //responseClass = service.debitCardIssueRetrieve(inputParams);

			if (responseClass.getGaussResponse() == null || !responseClass.getGaussResponse().isErrorFlag()) { // gauss service ok
				logger.info("[CardIssueAction - cardIssueVRPrepareEmisAction] gauss service correctly performed");
				
				request.setAttribute("cardIssueArray", responseClass.getCardIssueHolder());
				sessionData.setCardIssueArray(responseClass.getCardIssueHolder());
				
				request.setAttribute("jsonAccountList", getJsonAccountList(responseClass.getCardIssueHolder()));
				
				request.setAttribute("cardTypeArray", responseClass.getCardType());
				sessionData.setCardType(responseClass.getCardType());

				request.setAttribute("noteMarks", responseClass.getNoteMarks());
				sessionData.setNoteMarks(responseClass.getNoteMarks());

				for (int i = 0; i < responseClass.getCardIssueHolder().length; i++) {
					if (responseClass.getCardIssueHolder()[i].getFlagOrig().equalsIgnoreCase("X")) {
						sessionData.setClientDescription(responseClass.getCardIssueHolder()[i].getClientDescription());	
					}

					/* EE29570 - Garante2 start */
					if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){ 				
						log.debug("GARANTE2 LOG STARTS");
						try {
							Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(2, it.usi.warranter.Utils.REQUEST_TYPE_INQUIRY, request); 				
							if (warranty2 != null) {
								String accountNumber = "";
								String accountBranch = "";
								String ndgClientCode = "";
								String siaCode 	= "";
								String cidCode 	= "";
								String accountType 	= "";
								String accountIBAN 	= "";
								String accountABI 	= "";
								String accountCAB 	= "";
			
								Account[] accountListInOut = responseClass.getCardIssueHolder()[i].getAccountList();
								for(int j = 0; j< accountListInOut.length; ++j){
									accountNumber = FormatUtils.formatString(accountListInOut[j].getAccountId());
									ndgClientCode = FormatUtils.formatString(accountListInOut[j].getAccountNdg());
									accountBranch = FormatUtils.formatString(accountListInOut[j].getBranch());							
									accountType = FormatUtils.formatString(accountListInOut[j].getType());
									GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
									warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
								}
								if (warranty2.getParams().size() > 0)
									WarrantyTracer.trace(warranty2);
									
							}
							log.debug("GARANTE2 LOG ENDS");

						} catch (Exception e) {
							logger.info("[CardIssueAction: cardIssueVRPrepareEmisAction] GARANTE2 exception: " + e.getMessage(), e);
							throw new XFRException(e);
						}
					}
					/* Garante2 end	*/			
				}
			} else { // gauss service error
				logger.info("[CardIssueAction - cardIssueVRPrepareEmisAction] gauss service ended with errors");
			}
		} catch (Exception e) {
			throw new XFRException(e);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		
		// ee21246 leggo la sessione e verifico se � stata gi� valorizzata nel giro di conferma con il messaggio di errore, per non sovrascriverla con il warning
		GaussResponse issueConfirmMessage = (GaussResponse) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "issueConfirmMessage");
		boolean severeError = true;
		//boolean severeError = false;
		if (issueConfirmMessage != null) {
			responseClass.setGaussResponse(issueConfirmMessage);
			severeError = false;
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "issueConfirmMessage", null);
		}
		
		
		// for test: non fa apparire popup
		//responseClass.getGaussResponse().setFlagCode("");
		
		// forward management
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, responseClass.getGaussResponse());
		complexPopUpParams.setActionBackError("");
		complexPopUpParams.setActionBackMessage("");
		complexPopUpParams.setActionBackConfirm("");
		complexPopUpParams.setActionConfirm("");
		complexPopUpParams.setErrorForward("");
		complexPopUpParams.setSevereError(severeError);
		complexPopUpParams.setReturnBackError(false);
		complexPopUpParams.setReturnBackMessage(false);
		complexPopUpParams.setForwardBackError(false);
		complexPopUpParams.setForward("cardIssueVRFirstPage");
		forward = Utl.createComplexPopUp(complexPopUpParams);
		
		
		//request.setAttribute("kind", kind);
	    GecWebUtilities.createTitleHeader(request, "menu.label.cardIssueVR.text", this.getClass());
		
		logger.info("[CardIssueAction - cardIssueVRPrepareEmisAction] --- end ---");
		return forward;
	}

	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward cardIssueConfirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
	
		logger.info("[CardIssueAction - cardIssueConfirm] --- init ---");

		ActionForward forward = new ActionForward();
		boolean isWarningPopupVisible = false;
		CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");
		
		// retrieve input parameters
		String clientIdCard = cardIssueForm.getNdgCard();
		String tmpAccount = cardIssueForm.getAccountBranch();
		boolean emptytmpacc = tmpAccount.equalsIgnoreCase("");
		String type = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(0, tmpAccount.indexOf("/")) :"";
		String branch = tmpAccount !=null && !emptytmpacc ? tmpAccount.substring(tmpAccount.indexOf("/") + 1, tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1)) : "";
		String account = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1) + 1):"";
		String clientIdAccount = sessionData.getNdg();

		String isStockCardType = cardIssueForm.getisStockCardType();
		String pinReferenceNumber = "";
		String cardEnvelopeNumber = "";
		
		if (isStockCardType.equals("Y")) {
			cardEnvelopeNumber = cardIssueForm.getPinReferenceNumber();
			pinReferenceNumber = FormatUtils.formatNumber("0", 8, 0, "N");
		} else {
			pinReferenceNumber = cardIssueForm.getPinReferenceNumber();
			cardEnvelopeNumber = FormatUtils.formatNumber("0", 8, 0, "N");
		} // if else isStockCardType
		
		String cardType = cardIssueForm.getCardType();
		String preContract = cardIssueForm.getPreContract();
		String freeOfCharge = cardIssueForm.getFreeOfChargeChoice();
		
		String typePrint = type;
		request.setAttribute("typePrint", typePrint);

		String selectedCardType = cardType;
		sessionData.setSelectedCardType(selectedCardType);
		logger.info("[CardIssueAction - cardIssueConfirm] selectedCardType: " + selectedCardType);

		
		// gauss service input definition
		DebitCardIssueInOut inputParams = new DebitCardIssueInOut();
		inputParams.setCustomerNdg(clientIdCard);
		inputParams.setAccountType(type);
		inputParams.setAccountBranch(branch);
		inputParams.setAccountNumber(account); 
		inputParams.setAccountNdg(clientIdAccount);
		inputParams.setPinReferenceNumber(pinReferenceNumber);
		inputParams.setCardEnvelopeNumber(cardEnvelopeNumber);
		inputParams.setCardType(cardType);
		inputParams.setPreContract(preContract);
		inputParams.setFreeOfCharge(freeOfCharge);
		String row01 = request.getParameter("_addressRow01");
		String row02 = request.getParameter("_addressRow02");
		String row03 = request.getParameter("_addressRow03");
		String row04 = request.getParameter("_addressRow04");
		String row05 = request.getParameter("_addressRow05");
		String addressType = request.getParameter("addressType");
		String branchReferent = request.getParameter("branchRef");
		String deliveryType = request.getParameter("delType");
		String row05Cap = "O".equalsIgnoreCase(addressType) ? request
				.getParameter("_addressRow05").split("_")[0] : "";
		String row05Pv = "O".equalsIgnoreCase(addressType) ? request
				.getParameter("_addressRow05").split("_")[1] : "";
		String row05Naz = "O".equalsIgnoreCase(addressType) ? request
				.getParameter("_addressRow05").split("_")[2] : "";

		inputParams.setAbi("02008");
		inputParams.setCardNumber("");
		inputParams.setAddressRow01(row01);
		inputParams.setAddressRow02(row02);
		inputParams.setAddressRow03(row03);
		inputParams.setAddressRow04(row04);
		inputParams.setAddressType(addressType);
		inputParams.setDeliveryType(deliveryType);
		if ("B".equalsIgnoreCase(addressType)) {
			inputParams.setBranchReferent(branchReferent);
		}
		if ("O".equalsIgnoreCase(addressType)) {
			inputParams.setAddressRow05(row05Cap + row05Pv + row05Naz);
		} else {
			inputParams.setAddressRow05(row05);
		}
		logger.info("[CardIssueAction - cardIssueConfirm] inputParams: " + inputParams.toJson());
		
		
		
		// Avvio integrazione DS2
		// ****************************************************************************************
		logger.info("[CardIssueAction - cardIssueConfirm] Chiamata DS2 - Start");
		boolean isFirmaMiaModule = "true".equalsIgnoreCase(request.getParameter("checkStoredResult"));
		logger.info("[CardIssueAction - cardIssueConfirm] isFirmaMiaModule: " + isFirmaMiaModule + " (param checkStoredResult: " + request.getParameter("checkStoredResult") + ") ");
		if(EsgCountryCode.isItalianCountry()){
			logger.info("cardIssueConfirm: selected card type: " + cardType);
			// Check DMB
			if(request.getAttribute(NO_DMB) == null && GecUtilities.isDigitalMailBoxOldSet()){
				if(!isFirmaMiaModule){
					// Save necessary data to use after Boost call
//					request.getSession().setAttribute(CARD_ISSUE_FORM_CLASS, cardIssueForm);
					request.getSession().setAttribute(DEBIT_CARD_ISSUE_IN_OUT, inputParams);
					
					ActionForward fwd = executeDSICall(request, 
							sessionData, 
							mapping, 
							clientIdCard, 
							branch, 
							type, 
							account, 
							cardType,
							SP_DMB_FLAG_FE);
					if(fwd!=null){
	
						// Avvio reindirizzamento verso DS2
						return fwd;
					}
				}
				
			}
			
//			// il trattamento � valido solo per l'italia
			ActionForward fwd = executeDs2Call(request, 
												sessionData, 
												mapping, 
												clientIdCard, 
												branch, 
												type, 
												account, 
												cardType);
			if(fwd!=null){
				
				// Avvio reindirizzamento verso DS2
				return fwd;
			}
		}
		
		logger.info("[CardIssueAction - cardIssueConfirm] Chiamata DS2 - End");
		// Fine integrazione DS2
		// ****************************************************************************************

		// gauss service call
		CardIssueConfirmResponseClass responseClass = new CardIssueConfirmResponseClass();
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;
		
		try {
			service = serviceFactory.getGecServiceFacade();
			responseClass = service.debitCardIssueConfirm(inputParams);
		} catch (Exception e) {
			throw new XFRException(e);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		CardIssueForm oForm = (CardIssueForm) form;
		
		boolean emptySped = request.getParameter(request.getParameter("selectedProd")).trim().length() == 0;
		
		// **************************************************************************************************************
		// !responseClass.getGaussResponse().isErrorFlag() va levato il test sul false per poter fare il test
		// a meno di non avere un caso di test reale...
		// **************************************************************************************************************
		// service response management
		if (responseClass.getGaussResponse() == null || !responseClass.getGaussResponse().isErrorFlag()) { // gauss service ok		
			
			if (!emptySped) {
				InquiryBancomatResponseClass updateResponse = new InquiryBancomatResponseClass();
				oForm.getDebitFastPayInOut().getAbi().setValue("2008");
				oForm.getDebitFastPayInOut().getCard().setValue(responseClass.getCardNumber());
				oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow01().setValue(row01);
				oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow02().setValue(row02);
				oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow03().setValue(row03);
				oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow04().setValue(row04);
				oForm.getDebitFastPayInOut().getDeliveryTypeChoice().setValue(deliveryType);
				if ("B".equalsIgnoreCase(addressType)) {
					oForm.getDebitFastPayInOut().getAddressChoice().getBranchReferent().setValue(branchReferent);
				}
				if ("O".equalsIgnoreCase(addressType)) {
					oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow05()
							.setValue(row05Cap + row05Pv + row05Naz);
				} else {
					oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow05().setValue(row05);
				}
				try {
					IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
					try {
						oForm.getDebitFastPayInOut().setService("esgRequestOldDeliveryConfirm");
						updateResponse = serviceF.updateFastPayInfo(oForm.getDebitFastPayInOut());
					} finally {
						serviceFactory.dispose(serviceF);
					}
				} catch (Exception e) {
					logger.error("CardIssueConfirm: updateFastPayInfo error ", e);
					throw e;
				}
			}
			sessionData.setFastPayFlag(responseClass.getReturnCode());
			
			logger.info("[CardIssueAction - cardIssueConfirm] Dematerializzaizone PIN - Start");
			
			boolean bustaDema = GecUtilities.isGecParameterSet(GecConstants.BUSTAPINOLD_PARAM,"DEVELOP","N",true);
			boolean librDema = GecUtilities.isGecParameterSet(GecConstants.LIBRPINOLD_PARAM,"DEVELOP","N",true);
			boolean checkDema = (!GecConstants.ESG_LIBR_CARD_TYPE.equalsIgnoreCase(cardType) && bustaDema) 
									|| (GecConstants.ESG_LIBR_CARD_TYPE.equalsIgnoreCase(cardType) && librDema);
			
			logger.info("[CardIssueAction - cardIssueConfirm] Dematerializzaizone PIN - CARD TYPE : [" + cardType + "]");
			logger.info("[CardIssueAction - cardIssueConfirm] Dematerializzaizone PIN - BUSTAPINO : [" + bustaDema + "]");
			logger.info("[CardIssueAction - cardIssueConfirm] Dematerializzaizone PIN - LIBRPINOL : [" + librDema + "]");
			logger.info("[CardIssueAction - cardIssueConfirm] Dematerializzaizone PIN - CHECKDEMA : [" + checkDema + "]");
			// Dematerializazione PIN
			if(EsgCountryCode.isItalianCountry()
				&& checkDema) {
				
				UserData userData = GecWebUtilities.getUserData(request);
				String torre = GecWebUtilities.getHostEnvironmentTower(request);
				SendSmsInput input = new SendSmsInput();
				input.setChannel("GEC");
				input.setUserId(userData.getCodOperatore());
				input.setLanguage("IT");
				input.setTorre(torre);
				input.setCardNumber(responseClass.getCardNumber());
				input.setAbi("02008");
				
				try {
					service = serviceFactory.getGecServiceFacade();
					SendSmsOutput outputWS = service.retrieveActivateSendSmsPin(input);
					if(outputWS.getRc() > 0) {
						GecUtilities.manageActivateSendSmsPinWarining(responseClass.getGaussResponse(), GecUtilities.MSG_1500, false);
						isWarningPopupVisible = true;
					}
					logger.info("[CardIssueAction - cardIssueConfirm] Dematerializzaizone PIN - End");
				} catch (Exception e) {
					//throw new XFRException(e);
					logger.error("[CardIssueAction - WS ActivateSendSmsPin] Error: ", e);
				} finally {
					if (service != null) {
						serviceFactory.dispose(service);
					}
				}
			}
			// Dematerializazione PIN
			
			logger.info("[CardIssueAction - cardIssueConfirm] gauss service correctly performed");
			
			sessionData.setAbi("02008");
			sessionData.setPreContract(preContract);
			sessionData.setSelectedCardType(selectedCardType);
			sessionData.setClientIdCard(clientIdCard);
			sessionData.setTypePrint(type);
			sessionData.setAccountBranchId(branch);
			sessionData.setAccountType(type);
			sessionData.setAccount(account);
			sessionData.setCardNumber(responseClass.getCardNumber());
			sessionData.setPinReferenceNumber(cardIssueForm.getPinReferenceNumber());
			sessionData.setFreeOfChargeChoice(freeOfCharge);
			sessionData.setFreeOfChargeFlag((freeOfCharge != null && (freeOfCharge.equals("Y") || freeOfCharge.equals("N"))) ? "3" : "2");
			
			logger.info("[CardIssueAction - cardIssueConfirm] sessionData: " + sessionData.getDebugString());
			
			String xpiCheckParam = "";
			boolean isPaper = "".equalsIgnoreCase(request.getParameter("tabletStatusKo"));
			boolean storedOkAndNoTabletIssues = !isPaper && !((request.getParameter("tabletStatusKo") != null && "true".equalsIgnoreCase(request.getParameter("tabletStatusKo"))));
			if(storedOkAndNoTabletIssues){
				logger.info("EsgCardInquiryAction - storedOkAndNoTabletIssues");
				//Chiamo controllo XPI su modulo e filiale e setto attributo in request
				
				boolean xpiCheck;
				if (GecUtilities.isFirmaMiaSkipXpiCheckSet()) {
					logger.info("SKIPPING XPI CHECK: TRUE");
					xpiCheck = true;
				} else {
					logger.info("SKIPPING XPI CHECK: FALSE");
					xpiCheck = xpiCheck(responseClass.getPrintForm());
				}
				
				logger.info("XPI CHECK: " + xpiCheck);
				xpiCheckParam = xpiCheck ? "true" : "false";
			}
			
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "printForm", responseClass.getPrintForm());
			
			String cardNumber = sessionData.getCardNumber();
			String pin = sessionData.getPinReferenceNumber();
			cardIssueForm.setPinReferenceNumber(pin);
			request.setAttribute("cardNumber", cardNumber);

			String[] arrayString = new String[1];
			arrayString[0] = responseClass.getCardNumber();

			if(request.getAttribute("showToPaperPopup") != null && "true".equalsIgnoreCase((String)request.getAttribute("showToPaperPopup"))){
				XfrMessage.showInformationMessage(request, "card.label.oldIssueToPaperPopup.text", arrayString, null, "cardIssue.do?method=mapping.cardIssue.cardIssueRefresh&xpiCheck=" + xpiCheckParam + "&sessionMarker=" + request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg());
			} else {
				if(isWarningPopupVisible) {
					XfrMessage.showWarningMessage(request, "card.label.warningMessage.text", arrayString, null, "cardIssue.do?method=mapping.cardIssue.cardIssueRefresh&xpiCheck=" + xpiCheckParam + "&sessionMarker=" + request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg());
				} else {
					//XfrMessage.showInformationMessage(request, "card.label.confirmMessage.text", arrayString, null, "cardIssue.do?method=mapping.cardIssue.cardIssueRefresh&sessionMarker=" + request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg());
					XfrMessage.showWarningMessage(request, "card.label.warningMessage1533.text", arrayString, null, "cardIssue.do?method=mapping.cardIssue.cardIssueRefresh&xpiCheck=" + xpiCheckParam + "&sessionMarker=" + request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg());
				}
			}
			forward = this.cardIssueRefreshPrint(mapping, form, request, response);
			
			/* EE29570 - Garante2 start */
			if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){ 				
				log.debug("GARANTE2 LOG STARTS");
				try {
					Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(14, it.usi.warranter.Utils.REQUEST_TYPE_DISPOSITIVE, request); 				
					if (warranty2 != null) {
						String ndgClientCode = FormatUtils.formatString(sessionData.getClientIdCard());
						String siaCode 	= "";
						String cidCode 	= "";
						String accountNumber = "";
						String accountBranch = FormatUtils.formatString(sessionData.getAccountBranchId());
						String accountType 	= "";
						String accountIBAN 	= "";
						String accountABI 	= "";
						String accountCAB 	= "";
						String abi 			= FormatUtils.formatNumber(sessionData.getAbi(), 5, 0, "N");
						String cardNumberW  = FormatUtils.formatNumber(sessionData.getCardNumber(), 8, 0, "N");
						String product		= responseClass.getCardType();
	
						//LOG - NUMERO RAPPORTO CARTA (Forma Tecnica GeCa, Abi + Numero Carta)
						accountType = CardTypeConverter.convertCardType(product,true);
						accountNumber = abi + cardNumberW;	
						// if (accountNumber.length() < 13) accountNumber = "";													
						GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						
						//LOG - NUMERO RAPPORTO CONTO
						accountType = FormatUtils.formatString(sessionData.getAccountType());
						accountNumber = FormatUtils.formatString(sessionData.getAccount());														
						GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
																			
						if (warranty2.getParams().size() > 0)
							WarrantyTracer.trace(warranty2);
		
						log.debug("GARANTE2 LOG ENDS");
					}
				} catch (Exception e) {
					logger.info("[CardIssueAction: unspecified] GARANTE2 exception: " + e.getMessage(), e);
					throw new XFRException(e);
				}
			}
			/* Garante2 end	*/			
			
		} else { // gauss service error
			logger.info("[CardIssueAction - cardIssueConfirm] gauss service ended with errors");

			// ee21246 metto in sessione il messaggio d'errore
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "issueConfirmMessage", responseClass.getGaussResponse());
			
			String actionBackUrl = "cardIssue.do?method=&sessionMarker=" + request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg();
			
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, responseClass.getGaussResponse());
			complexPopUpParams.setActionBackError(actionBackUrl);
			complexPopUpParams.setActionBackMessage("");
			complexPopUpParams.setActionBackConfirm("");
			complexPopUpParams.setActionConfirm("");
			complexPopUpParams.setErrorForward("");
			complexPopUpParams.setSevereError(false);
			complexPopUpParams.setReturnBackError(true);
			complexPopUpParams.setReturnBackMessage(false);
			complexPopUpParams.setForwardBackError(false);
			complexPopUpParams.setForward("cardIssueFirstPage");
			forward = Utl.createComplexPopUp(complexPopUpParams);
		}
		
		// request management
		request.setAttribute("cardTypeArray", sessionData.getCardType());
		request.setAttribute("preContract", preContract);
		request.setAttribute("selectedCardType", selectedCardType);
		request.setAttribute("clientIdCard", clientIdCard);
		request.setAttribute("typePrint", type);
		request.setAttribute("selectedAccount", account);
		request.setAttribute("numRef", cardIssueForm.getPinReferenceNumber());
		
		// title header and quickly (knowledge base) button management
		GecWebUtilities.createTitleHeader(request, "menu.label.cardIssue.text", this.getClass());
		
		// Riabilito la chiamata a DS2
		request.getSession().setAttribute("disableDs2Call","false");
		
		logger.info("[CardIssueAction - cardIssueConfirm] --- end ---");
		return forward;
	}
	
	public ActionForward cardIssueBMConfirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("[CardIssueAction - cardIssueBMConfirm] --- init ---");
		
		ActionForward forward = null;
		CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");
		DebitCardIssueInOut debitCardIssueInOut = (DebitCardIssueInOut) request.getSession().getAttribute(DEBIT_CARD_ISSUE_IN_OUT);
		String actionBackAfterSuccessUrl = "cardIssue.do?method=mapping.cardIssue.cardIssueRefresh&xpiCheck=&sessionMarker=" + request.getAttribute("sessionMarker") + "&ndg=" + sessionData.getNdg();
		String actionBackToOldErrorUrl = "cardIssue.do?method=mapping.cardIssue.cardIssueConfirm&sessionMarker=" + request.getAttribute("sessionMarker") + "&ndg=" + sessionData.getNdg();
		UserData userInfo = GecWebUtilities.getUserData(request);
		
		// retrieve ndgType from AFA
		String language = ((Locale) request.getSession().getAttribute(Globals.LOCALE_KEY)).getLanguage();
		
		// recovering others ndg email
		String clientIdCard = cardIssueForm.getNdgCard();
		String tmpAccount = cardIssueForm.getAccountBranch();
		boolean emptytmpacc = tmpAccount.equalsIgnoreCase("");
		String type = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(0, tmpAccount.indexOf("/")) :"";
		String branch = tmpAccount !=null && !emptytmpacc ? tmpAccount.substring(tmpAccount.indexOf("/") + 1, tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1)) : "";
		String account = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1) + 1):"";
		String cardType = cardIssueForm.getCardType();
		String executeSpCardOpNdg = executeSpCardOpNdg(clientIdCard,branch,type,account,cardType,SP_DEFAULT_HIERARCHY,SP_DEFAULT_FLAG_FE);
		logger.info("CardIssueAction - GECKSNCO OUTPUT: " + executeSpCardOpNdg);
		boolean isMinor = false;
		if(executeSpCardOpNdg != null && !"".equalsIgnoreCase(executeSpCardOpNdg.trim()) && Long.parseLong(executeSpCardOpNdg.trim().split(";")[0]) != Long.parseLong(clientIdCard.trim())){
			logger.info("MINOR NDG FOUND: " + clientIdCard + " - setting isMinor to true");
			isMinor = true;
		}
		ArrayList customersDataFromAFAList = new ArrayList();
		if(executeSpCardOpNdg != null && !"".equals(executeSpCardOpNdg.trim())) {
			String[] ndgColl =  executeSpCardOpNdg.trim().split(";");
			if(ndgColl.length != 0){
				for(int i=0; i<ndgColl.length; i++){
					if((ndgColl[i] != null && !"".equals(ndgColl[i].trim()))){
						SearchCustomerParams custParamTemp = new SearchCustomerParams(userInfo, language);
						custParamTemp.setNdg(ndgColl[i]);
						it.usi.xframe.afa.bfutil.Customer customerTemp = AFAServiceFactory.getInstance().getAfaBaseServiceFacade().getCustomerSyntheticData(custParamTemp);
						if(false && (customerTemp.getContacts() == null || customerTemp.getContacts().getEmail() == null || "".equals(customerTemp.getContacts().getEmail().trim()))){
							logger.info("cardIssueBMConfirm: ndg number " + ndgColl[i] + " associated with ndg number " + sessionData.getNdg() + " has no valid email address - cannot send contract without a valid email address");
							return noEmailAddressErrorComplexPopUp(mapping, cardIssueForm, request, sessionData, false);
						}
						customersDataFromAFAList.add(customerTemp);
					}
				}
			}
		}
		logger.info("CardIssueAction - customersDataFromAFAList size = " + customersDataFromAFAList.size());
		String ndgType = isMinor ? null : ((it.usi.xframe.afa.bfutil.Customer)(customersDataFromAFAList.get(0))).getNdgType().getCode();
		
		//####################### INIZIO CHIAMATA OPEN DOSSIER BASKET MANAGER #######################
		
		String dossierMasterName = null; // must be short or Basket Manager will throw an exception
		String documentName = null;
		String cardTypeDescription = null;
		if(CARD_TYPE_MBV_TEEN.equalsIgnoreCase(debitCardIssueInOut.getCardType())) {
			cardTypeDescription = GecUtilities.getGecParameterArea(BR0646, "DIGITAMB");
			dossierMasterName = "Richiesta " + cardTypeDescription;
			documentName = dossierMasterName;
		} else if(
				CARD_TYPE_MBE_MAES.equalsIgnoreCase(debitCardIssueInOut.getCardType()) 
				|| CARD_TYPE_MBV_MVAP.equalsIgnoreCase(debitCardIssueInOut.getCardType())) {
			cardTypeDescription = GecUtilities.getGecParameterArea(BU0323, "DIGITAMB");
			dossierMasterName = cardTypeDescription; // leave this as short as possible cause Basket Manager can throw exception if this string is too long
			documentName = cardTypeDescription; // leave this as short as possible cause Basket Manager can throw exception if this string is too long
		}

		String sequence = "";
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;
		try {
			service = serviceFactory.getGecServiceFacade();
			sequence = service.retrieveSequenceBM();
		} catch (Exception e) {
			logger.error("[cardIssueBMConfirm - retrieveSequence] Error: ", e);
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, request, form, response,actionBackToOldErrorUrl);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		String correlationId = 	GEC_APPLICATION + 
				FormatUtils.formatNumber((String)userInfo.getFilialeOperatore(), 5, 0, "N") +
				FormatUtils.formatNumber(debitCardIssueInOut.getCustomerNdg(), 15, 0, "N") +//FormatUtils.formatNumber((String)inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg().getValue(), 15, 0, "N") +
				sequence; //sequence (progr)
		
		// Call BM Add Dossier
		Date plusThirtyDaysDate = GecWebUtilities.getPlusThirtyDaysDate(new Date());
		DateFormat df = new SimpleDateFormat(EXPIRATION_TIMESTAMP_FORMAT);
		String expirationTimestamp = df.format(plusThirtyDaysDate); // today plus thrirty days at midnight
		Date endOfDayDate = GecWebUtilities.getEndOfDayDate(new Date());
		Date midDayTestDate = GecWebUtilities.getMidDayTestDate(new Date());
		String dossierClassification = "Monetica Emissione Carte"; //constant
		
		DossierOutput outputWS;
		try {
			outputWS = callBMOpenDossier(userInfo, correlationId, dossierMasterName, dossierClassification, expirationTimestamp); // used same name as document but different businessKey
		} catch (Exception e) {
			logger.error("[cardIssueBMConfirm: WS BasketDossier open] Error: ", e);
			logger.info("cardIssueBMConfirm: PROSEGUIMENTO AS-IS a causa di errore durante chiamata Open al servizio di Basket Manager");
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, request, form, response, actionBackToOldErrorUrl);
		}
		
		if(outputWS == null || !"0".equals(outputWS.getOutcome().getCode())) { // KO OPEN BASKET MANAGER
			logger.info("[cardIssueBMConfirm] BasketDossier Open - End with KO");
			logger.info("cardIssueBMConfirm: PROSEGUIMENTO AS-IS a causa di KO dal servizio Basket Manager in chiamata alla Open");
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, request, form, response, actionBackToOldErrorUrl);
		}

		//####################### FINE CHIAMATA OPEN DOSSIER BASKET MANAGER #######################
		logger.info("[cardIssueBMConfirm] BasketDossier Open - End with success");
		
		// retireving dossierId from service output
		String dossierId = outputWS.getDossierId();

		// setting new data to call GECKTIN0 in CONFIRM
		debitCardIssueInOut.setCorrelationId(correlationId);
		debitCardIssueInOut.setIdDossier(dossierId);
		debitCardIssueInOut.setSubDossier(""); // leave this empty at this moment cause there isn't a subDossier right now
		debitCardIssueInOut.setExpirationTimestamp(""); // leave this empty at this moment cause there isn't a subDossier right now
		debitCardIssueInOut.setFunction(ISSUE_FUNCTION);

		CardIssueConfirmResponseClass classReturn = null;
		serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		// GECKTIN0 in CONFIRM
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			classReturn = serviceF.debitCardIssueConfirmDMB(debitCardIssueInOut);
		} catch (Exception e) {
			logger.error("[cardIssueBMConfirm] Error: ", e);
			logger.info("cardIssueBMConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a GECKTIN0 in CONFIRM");
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, request, form, response, actionBackToOldErrorUrl);
		} finally {
			if(serviceF != null && serviceFactory != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		
		if (!this.isGaussResponseError(classReturn.getGaussResponse())) {
			logger.info("[cardIssueBMConfirm] GECKTIN0 in CONFIRM response successfully - begin operations on data before calling Basket Manager web service Add");
			
			String cardNumber = classReturn.getCardNumber();
			debitCardIssueInOut.setCardNumber(cardNumber);
			
			try {
				// preliminary operation before Basket Manager Add
				XDocument[] contract = new XDocument[1];
				for (int i = 0; i < classReturn.getPrintForm().length; i++) {
					logger.info("CardIssueAction.cardIssueBMConfirm classReturn.getPrintForm().length = " + classReturn.getPrintForm().length);
					if(!"Y".equalsIgnoreCase(classReturn.getPrintForm()[i].getMapElement("MOD_GEM"))){
						logger.info("CardIssueAction.cardIssueBMConfirm found module with MOD_GEM != Y (contract) - index = " + i + ", formName = " + classReturn.getPrintForm()[i].getFormName() + ", docILC = " + classReturn.getPrintForm()[i].getDocILC());
						contract[0] = classReturn.getPrintForm()[i];
						String[] ndgColl =  executeSpCardOpNdg.trim().split(";");
						if(isMinor || ndgColl.length > 1){
							contract[0].addPrintVar("SYS_COINT", clientIdCard);
							contract[0].setNdg(clientIdCard);
							ArrayList signersArray = new ArrayList();
							for (int j = 0; j < ndgColl.length; j++) {
								Signer signer = new Signer();
								signer.setNdg(ndgColl[j]);
								signersArray.add(signer);
								logger.info("cardissueBMConfirm - adding Signer " + (j + 1) + " to doc #" + i + ": " + ndgColl[j]);
								
								contract[0].addPrintVar("SYS_SIGNER_" + (j + 1), ndgColl[j]);
								logger.info("cardIssueBMConfirm - adding SYS_SIGNER_" + (j + 1) + " to doc #" + i + ": " + ndgColl[j]);
							}
							contract[0].setSigners(signersArray);
							contract[0].setSignersFromCallingApp(true);
						}
					}
				}
				
				//###############
				String contractData = GecUtilities.getGecParameterArea("PRE" + contract[0].getFormName(), "DIGITAMB");
				String ftr = contractData.split(",")[0].trim();
				String product = contractData.split(",")[1].trim();
				String groupId = contractData.split(",")[2].trim();
				String contractPosition = "";
				String contractPracticeNumber = FormatUtils.formatNumber(cardNumber, 13, 0, "N");
				if(contract[0].getMapElement("POSIZIONE") != null && !"".equalsIgnoreCase(contract[0].getMapElement("POSIZIONE"))){
					contractPosition = contract[0].getMapElement("POSIZIONE");
				}
				AgreedSetRequest saveContractConditionsInput = new AgreedSetRequest();
				saveContractConditionsInput.setPracticeNumber("DMGEC" + contractPracticeNumber);
				AgreedSetRequestElement[] contractProducts = new AgreedSetRequestElement[1];
				AgreedSetRequestElement contractElement = new AgreedSetRequestElement();
				contractElement.setFtf("");
				contractElement.setFtr(ftr);
				contractElement.setGroupId(groupId);
				contractElement.setPosition(contractPosition);
				contractElement.setProduct(product);
				contractProducts[0] = contractElement;
				saveContractConditionsInput.setProducts(contractProducts);
				
				AgreedSetResponse saveContractConditionsResponse = null;
				
				try {
					serviceF = serviceFactory.getGecServiceFacade();
					saveContractConditionsResponse = serviceF.callSaveActualSet(saveContractConditionsInput);
				} catch (Exception e) {
					logger.error("[cardIssueBMConfirm] Error: ", e);
					logger.info("cardIssueBMConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio condizioni saveActualSet");
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
				} finally {
					if(serviceF != null && serviceFactory != null) {
						serviceFactory.dispose(serviceF);
					}
				}
				
				if(saveContractConditionsResponse == null || "KO".equalsIgnoreCase(saveContractConditionsResponse.getReturnCode())){
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
				}
				
				AgreedSetRequest retrieveContractConditionsInput = new AgreedSetRequest();
				retrieveContractConditionsInput.setPracticeNumber("DMGEC" + contractPracticeNumber);
				AgreedSetRequestElement[] retrieveContractConditionsProducts = new AgreedSetRequestElement[1];
				AgreedSetRequestElement retrieveContractConditionsElement = new AgreedSetRequestElement();
				retrieveContractConditionsElement.setGroupId(groupId); // C1?
				retrieveContractConditionsProducts[0] = retrieveContractConditionsElement;
				retrieveContractConditionsInput.setProducts(retrieveContractConditionsProducts);
				
				CtbWsPrintDocument[] retrieveContractConditionsResponse = null;
				try {
					serviceF = serviceFactory.getGecServiceFacade();
					retrieveContractConditionsResponse = serviceF.callRetrieveCtbConditionsSet(retrieveContractConditionsInput);
				} catch (Exception e) {
					logger.error("[cardIssueBMConfirm] Error: ", e);
					logger.info("cardIssueBMConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio condizioni contratto retrieveCtbConditionsSet");
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
				} finally {
					if(serviceF != null && serviceFactory != null) {
						serviceFactory.dispose(serviceF);
					}
				}
				
				if(retrieveContractConditionsResponse == null){
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
				}
				
				logger.info("CardIssueAction.cardIssueBMConfirm retrieveContractConditionsResponse.length = " + retrieveContractConditionsResponse.length);
				
				XDocument[] contractConditions = new XDocument[retrieveContractConditionsResponse.length];
				for (int i = 0; i < retrieveContractConditionsResponse.length; i++) {
	                CtbWsPrintDocument ctbDoc = retrieveContractConditionsResponse[i];
	                contractConditions[i] = new XDocument();
	                contractConditions[i].setFormName(ctbDoc.getFormName());
	                contractConditions[i].setJFormDocType(ctbDoc.getJFormDocType());
	                contractConditions[i].setPrecontratto(ctbDoc.getPrintMethod());
	                contractConditions[i].setSubForm(true);
	                contractConditions[i].setSubformGroup(ctbDoc.getGroup());
	                
	                if (ctbDoc.getVarMap() != null) {
	                   Iterator iterator = ctbDoc.getVarMap().keySet().iterator();
	                   while (iterator.hasNext()) {
	                       String k = (String) iterator.next();
	                       contractConditions[i].addPrintVar(k, ctbDoc.getVarMap().get(k));
	                   }
	                }
				}
				
				logger.info("CardIssueAction.cardIssueBMConfirm contractConditions.length = " + contractConditions.length);

				//Alla fine si hanno il XDocument originario e quello del Documento di Sintesi, da unire:

				XDocument[] contractDocsWithConditions = new XDocument[1 + contractConditions.length];
				contractDocsWithConditions[0] = contract[0];
				for (int i = 0; i < contractConditions.length; i++) {
					contractDocsWithConditions[i + 1] = contractConditions[i];
				}
				
				logger.info("CardIssueAction.cardIssueBMConfirm contractDocsWithConditions.length = " + contractDocsWithConditions.length);

				
				//###############
				
				String originalModuleList = XPrintUtilities.createModuleListXMLFromXDocument(contractDocsWithConditions);
				logger.info("cardIssueBMConfirm: ORIGINAL MODULELIST: " + originalModuleList);

				// set moduleId on modules
				for (int i = 0; i < contractDocsWithConditions.length; i++) {
					contractDocsWithConditions[i].setDigitalSigns("".toCharArray());

					if(contractDocsWithConditions[i].getDocID() == null || "".equalsIgnoreCase(contractDocsWithConditions[i].getDocID())){
						contractDocsWithConditions[i].setDocID("module"+i);
					}
				}
				
				// search the correct module for the current card type to send to Basket Manager Add Dossier
				/*XDocument[] bmDoc = new XDocument[1];
				boolean moduleForBMAddFound = false;
				
				// search correct module for current cardType among those obtained from GECKTIN0 in Confirm
				for(int i=0; i<classReturn.getPrintForm().length; i++){
					if((CARD_TYPE_MBV_TEEN.equalsIgnoreCase(debitCardIssueInOut.getCardType()) 
							&& BR0646.equalsIgnoreCase(classReturn.getPrintForm()[i].getFormName()))
						||	((CARD_TYPE_MBV_MAES.equalsIgnoreCase(debitCardIssueInOut.getCardType()) || CARD_TYPE_MBV_MVAP.equalsIgnoreCase(debitCardIssueInOut.getCardType()))
								&& BU0323.equalsIgnoreCase(classReturn.getPrintForm()[i].getFormName()))) {
						moduleForBMAddFound = true;
					}
					
					if(moduleForBMAddFound){
						bmDoc[0] = classReturn.getPrintForm()[i];
						break;
					}
				}
				
				if(!moduleForBMAddFound){
					logger.error("Cannot call Basket Manager Add Dossier cause the correct module to use was not found in the moduleList returned from transaction GECKTIN0");
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl);
				}*/
				
				// backup modules to reuse them in DSI services call
				XDocument[] modulesBackup = classReturn.getPrintForm();
				
				String modifiedModuleList = XPrintUtilities.createModuleListXMLFromXDocument(contractDocsWithConditions);
				modifiedModuleList = removeDataRif(modifiedModuleList);
				String wrappedModuleList = "<![CDATA[" + modifiedModuleList + "]]>";
				logger.info("FINAL MODULELIST: " + wrappedModuleList);
				classReturn.setModuleList(wrappedModuleList);

				//####################### INIZIO CHIAMATA ADD DOSSIER BASKET MANAGER #######################
				
				String dossierExpirationTimeStamp = df.format(plusThirtyDaysDate); 
				logger.info("dossierExpirationTimeStamp for BM: [" + dossierExpirationTimeStamp + "] ");
				String documentExpirationTimeStamp = df.format(endOfDayDate); 
				logger.info("documentExpirationTimeStamp for BM: [" + documentExpirationTimeStamp + "] ");
				
				DossierDocumentOutput outputAddWS;
				
				XDocument[] mainDocument = new XDocument[]{contractDocsWithConditions[0]};
				
				try {
					outputAddWS = callBMAddDossier(userInfo, correlationId, dossierId, documentName, dossierClassification, dossierExpirationTimeStamp, documentExpirationTimeStamp, ndgType, mainDocument, wrappedModuleList, isMinor, executeSpCardOpNdg, customersDataFromAFAList);
				} catch (Exception e) {
					logger.error("Basket Manager Add request error: " + e.getMessage(), e);
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
				}
				
				if(outputAddWS == null || !"0".equals(outputAddWS.getOutcome().getCode())) { // KO ADD BASKET MANAGER
					logger.info("[CardIssueAction:cardIssueBMConfirm] BasketDossier Add - End with KO");

					//INIZIO ROLLBACK
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
					//FINE ROLLBACK
				} else {
					logger.info("[CardIssueAction:cardIssueBMConfirm] BasketDossier Add - End with success");
					//####################### FINE CHIAMATA ADD DOSSIER BASKET MANAGER #######################

					//call GECKTIN0 in Update
					// all input data are as the previous GECKTIN0 update call
					String documentId = "";
					for (int j = 0; j < outputAddWS.getDossier()[0].getDocuments().length; j++) {
//						if(!outputAddWS.getDossier()[0].getDocuments()[j].getModule().startsWith("S")){
							documentId = outputAddWS.getDossier()[0].getDocuments()[j].getDocumentId();
//						}
					}
					debitCardIssueInOut.setSubDossier(outputAddWS.getDossier()[0].getDossierId());
					debitCardIssueInOut.setDocumentId(documentId);
					debitCardIssueInOut.setExpirationTimestamp(expirationTimestamp); //main Dossier expiration timeStamp 
					
					// GECKTIN0 in UPDATE
					try {
						serviceF = serviceFactory.getGecServiceFacade();
						classReturn = serviceF.debitCardIssueConfirmDMBUpdate(debitCardIssueInOut);
					} finally {
						if(serviceF != null && serviceFactory != null) {
							serviceFactory.dispose(serviceF);
						}
					}

					ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
					if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
						logger.info("cardIssueBMConfirm: KO from GECKTIN0 in UPDATE - stopping procedure and redirecting to initial page");
						return commonOperationsBeforeComplexPopUpAndForwardAfterError(mapping, cardIssueForm, request, sessionData, classReturn.getGaussResponse(), false);
					} else {
						logger.info("success from GECKTIN0 in UPDATE");
						request.setAttribute("dmbStopPrint", "true");
						complexPopUpParams.setActionBackMessage(actionBackAfterSuccessUrl); // "gec.cardIssueConfirm.page"
						complexPopUpParams.setReturnBackMessage(true);
					}
					
					// DSI services
					// recovering precontract from modules list
					XDocument[] dsiDoc = new XDocument[1];
					boolean preContractFound = false;
					for(int i=0; i<modulesBackup.length; i++){
						if(
//								modulesBackup[i].getFormName() != null && modulesBackup[i].getFormName().startsWith("S")
								"Y".equalsIgnoreCase(modulesBackup[i].getMapElement("MOD_GEM"))
								){
							dsiDoc[0] = modulesBackup[i];
							preContractFound = true;
							break;
						}
					}
					if(preContractFound) {
						dsiDoc[0].addPrintVar("ANA_CTB_FLAG", "Y");
						dsiDoc[0].setDigitalSigns("".toCharArray());
						if (dsiDoc[0].getFormName() != null && !"".equalsIgnoreCase(dsiDoc[0].getFormName().trim())) {
							dsiDoc[0].setDocILC(dsiDoc[0].getFormName().trim() + "#11");
						} else {
							dsiDoc[0].setDocILC(dsiDoc[0].getDocILC().trim() + "#11");
						}
						dsiDoc[0].setDocumentNumber1("Precontratto " + cardTypeDescription);
						
						if(dsiDoc[0].getNdg() == null || "".equals(dsiDoc[0].getNdg())){
							dsiDoc[0].setNdg(clientIdCard);
						}
						
						String[] ndgColl =  executeSpCardOpNdg.trim().split(";");
						
						boolean isMultipleNdg = !isMinor && ndgColl.length > 1;
						
						XDocument[] docs = dsiDoc;
						
						//####################################
						
						String preContractPracticeNumber = "1" + FormatUtils.formatNumber(cardNumber, 12, 0, "N");
						AgreedSetRequest savePreContractConditionsInput = new AgreedSetRequest();
						savePreContractConditionsInput.setPracticeNumber("DMGEC" + preContractPracticeNumber);
						AgreedSetRequestElement[] preContractProducts = new AgreedSetRequestElement[1];
						AgreedSetRequestElement preContractElement = new AgreedSetRequestElement();
						preContractElement.setFtf("");
						preContractElement.setFtr(ftr);
						preContractElement.setGroupId(groupId);
//						preContractElement.setPosition(contractPosition);
						preContractElement.setProduct(product);
						preContractProducts[0] = preContractElement;
						savePreContractConditionsInput.setProducts(preContractProducts);
						
						AgreedSetResponse savePreContractConditionsResponse = null;
						
						try {
							serviceF = serviceFactory.getGecServiceFacade();
							savePreContractConditionsResponse = serviceF.callSaveActualSet(savePreContractConditionsInput);
						} catch (Exception e) {
							logger.error("[cardIssueBMConfirm] Error: ", e);
							logger.info("cardIssueBMConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio precondizioni saveActualSet");
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
						} finally {
							if(serviceF != null && serviceFactory != null) {
								serviceFactory.dispose(serviceF);
							}
						}
						
						if(savePreContractConditionsResponse == null || "KO".equalsIgnoreCase(savePreContractConditionsResponse.getReturnCode())){
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
						}
						
						AgreedSetRequest retrievePreContractConditionsInput = new AgreedSetRequest();
						retrievePreContractConditionsInput.setPracticeNumber("DMGEC" + preContractPracticeNumber);
						
						CtbWsPrintDocument[] retrievePreContractConditionsResponse = null;
						try {
							serviceF = serviceFactory.getGecServiceFacade();
							retrievePreContractConditionsResponse = serviceF.callRetrieveCtbConditionsSet(retrievePreContractConditionsInput);
						} catch (Exception e) {
							logger.error("[cardIssueBMConfirm] Error: ", e);
							logger.info("cardIssueBMConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio condizioni precontratto retrieveCtbConditionsSet");
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
						} finally {
							if(serviceF != null && serviceFactory != null) {
								serviceFactory.dispose(serviceF);
							}
						}
						
						if(retrievePreContractConditionsResponse == null){
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
						}
						
						XDocument[] preContractConditions = new XDocument[retrievePreContractConditionsResponse.length];
						for (int i = 0; i < retrievePreContractConditionsResponse.length; i++) {
			                CtbWsPrintDocument ctbDoc = retrievePreContractConditionsResponse[i];
			                preContractConditions[i] = new XDocument();
			                preContractConditions[i].setFormName(ctbDoc.getFormName());
			                preContractConditions[i].setJFormDocType(ctbDoc.getJFormDocType());
			                preContractConditions[i].setPrecontratto(ctbDoc.getPrintMethod());
			                preContractConditions[i].setSubForm(true);
			                preContractConditions[i].setSubformGroup(ctbDoc.getGroup());
			                
			                if (ctbDoc.getVarMap() != null) {
			                   Iterator iterator = ctbDoc.getVarMap().keySet().iterator();
			                   while (iterator.hasNext()) {
			                       String k = (String) iterator.next();
			                       preContractConditions[i].addPrintVar(k, ctbDoc.getVarMap().get(k));
			                   }
			                }
						}
						
						//Alla fine si hanno il XDocument originario e quello del Documento di Sintesi, da unire:

						XDocument[] preContractDocsWithConditions = new XDocument[1 + preContractConditions.length];
						preContractDocsWithConditions[0] = dsiDoc[0];
						for (int i = 0; i < preContractConditions.length; i++) {
							preContractDocsWithConditions[i + 1] = preContractConditions[i];
						}
						
						//####################################
						
						//#############
//						if(isMinor){
							/*docs = new XDocument[ndgColl.length];
							for (int i = 0; i < docs.length; i++) {
								docs[i] = GecUtilities.getXDocumentCopy(dsiDoc[0]);
								docs[i].setNdg(ndgColl[i]);
//								docs[i].addPrintVar("SYS_COINT", clientIdCard);
							}*/
						ArrayList preContractList = new ArrayList();
						if(isMinor){
							logger.info("CardIssueAction - creating preContractList for minor ndg");
							for (int i = 0; i < ndgColl.length; i++) {
								logger.info("CardIssueAction - creating preContractList #" + i);
								XDocument doc = GecUtilities.getXDocumentCopy(dsiDoc[0]);
								doc.setNdg(ndgColl[i]);
								doc.addPrintVar("ANA_CTB_FLAG", "Y");
								
								XDocument[] preContrWithConditions = new XDocument[1 + preContractConditions.length];
								preContrWithConditions[0] = doc;
								for (int j = 0; j < preContractConditions.length; j++) {
									preContrWithConditions[j + 1] = preContractConditions[j];
								}
								preContractList.add(preContrWithConditions);
							}
						} else {
							logger.info("CardIssueAction - creating preContractList for not-minor ndg");
							for (int i = 0; i < ndgColl.length; i++) {
								logger.info("CardIssueAction - creating preContractList #" + i);
								XDocument doc = GecUtilities.getXDocumentCopy(dsiDoc[0]);
								doc.setNdg(ndgColl[i]);
								doc.addPrintVar("ANA_CTB_FLAG", "Y");
								
								XDocument[] preContrWithConditions = new XDocument[1 + preContractConditions.length];
								preContrWithConditions[0] = doc;
								for (int j = 0; j < preContractConditions.length; j++) {
									preContrWithConditions[j + 1] = preContractConditions[j];
								}
								preContractList.add(preContrWithConditions);
							}
						}
						/*} else if(isMultipleNdg){
							docs = new XDocument[ndgColl.length + 1];
							for (int i = 0; i < docs.length; i++) {
								if(i == 0){
									docs[i] = dsiDoc[0];
								} else {
									docs[i] = GecUtilities.getXDocumentCopy(dsiDoc[0]);
									docs[i].setNdg(ndgColl[i]);
								}
							}
						}*/
						//#############
							
						int ind = 0;
						XDocument[] allDocs = new XDocument[ndgColl.length * (1 + preContractDocsWithConditions.length)];
						for (int i = 0; i < preContractList.size(); i++) {
							XDocument[] preContr = (XDocument[])preContractList.get(i);
							for (int j = 0; j < preContr.length; j++) {
								allDocs[ind + j] = preContr[j];
							}
							ind += preContr.length;
						}
						
//						String emailModuleList = XPrintUtilities.createModuleListXMLFromXDocument(dsiDoc);
//						emailModuleList = emailModuleList.replaceAll("name=\"docILC", "name=\"doc_ilc");
//						String emailWrappedModuleList = "<![CDATA[" + emailModuleList + "]]>";
//						logger.info("FINAL MODULELIST: " + emailWrappedModuleList);
//						callDSIServicesForContract(correlationId, customersDataFromAFAList, emailWrappedModuleList, userInfo, cardTypeDescription, isMinor);
						callDSIServicesForContract(correlationId, customersDataFromAFAList, userInfo, cardTypeDescription, isMinor, isMultipleNdg, docs, preContractList, ((XDocument[])(preContractList.get(0))));
					} else {
						logger.info("cardIssueBMConfirm: precontract not found");
					}
					// END of DSI services
					request.getSession().setAttribute("disableDs2Call","false");
					forward = Utl.createComplexPopUp(complexPopUpParams);
					return forward;
				}
			} catch (Exception e) {
				logger.error("Error during BM add call / email process: ", e);
				try{
					//INIZIO ROLLBACK
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, false);
					//FINE ROLLBACK
				} catch(XFRException ex) {
					logger.error("Exception from rollback: ", ex);
					throw ex;
				}
			} finally {
				if (service != null) {
					serviceFactory.dispose(service);
				}
			}
		} else { // this is the case of GECKTIN0 in CONFIRM when returns a GaussReponse with KO
			logger.info("cardIssueBMConfirm: KO from GECKTIN0 in CONFIRM - stopping procedure and redirecting to initial page");
			return commonOperationsBeforeComplexPopUpAndForwardAfterError(mapping, cardIssueForm, request, sessionData, classReturn.getGaussResponse(), false);
		}
	}
	
	public ActionForward cardIssueBMVRConfirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("[CardIssueAction - cardIssueBMVRConfirm] --- init ---");
		
		ActionForward forward = null;
		CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");
		DebitCardIssueInOut debitCardIssueInOut = (DebitCardIssueInOut) request.getSession().getAttribute(DEBIT_CARD_ISSUE_IN_OUT);
		String actionBackAfterSuccessUrl = "cardIssue.do?method=mapping.cardIssue.cardIssueVRRefresh&xpiCheck=&sessionMarker=" + request.getAttribute("sessionMarker") + "&ndg=" + sessionData.getNdg();
		String actionBackToOldErrorUrl = "cardIssue.do?method=mapping.cardIssue.cardIssueVRConfirm&sessionMarker=" + request.getAttribute("sessionMarker") + "&ndg=" + sessionData.getNdg();
		UserData userInfo = GecWebUtilities.getUserData(request);
		
		// retrieve ndgType from AFA
		String language = ((Locale) request.getSession().getAttribute(Globals.LOCALE_KEY)).getLanguage();
		SearchCustomerParams custParam = new SearchCustomerParams(userInfo, language);
		custParam.setNdg(debitCardIssueInOut.getCustomerNdg());
		it.usi.xframe.afa.bfutil.Customer customerDataFromAFA = AFAServiceFactory.getInstance().getAfaBaseServiceFacade().getCustomerSyntheticData(custParam);
		String ndgType =  customerDataFromAFA.getNdgType().getCode();
		// retrieve ndg's email address for DSI services call
		if(customerDataFromAFA.getContacts() == null || customerDataFromAFA.getContacts().getEmail() == null) {
			logger.info("cardIssueBMVRConfirm: ndg has no valid email address - cannot send contract without a valid email address");
			return noEmailAddressErrorComplexPopUp(mapping, cardIssueForm, request, sessionData, true);
		}
		
		// recovering others ndg email
		String clientIdCard = cardIssueForm.getNdgCard();
		String tmpAccount = cardIssueForm.getAccountBranch();
		boolean emptytmpacc = tmpAccount.equalsIgnoreCase("");
		String type = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(0, tmpAccount.indexOf("/")) :"";
		String branch = tmpAccount !=null && !emptytmpacc ? tmpAccount.substring(tmpAccount.indexOf("/") + 1, tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1)) : "";
		String account = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1) + 1):"";
		String cardType = cardIssueForm.getCardType();
		String executeSpCardOpNdg = executeSpCardOpNdg(clientIdCard,branch,type,account,cardType,SP_DEFAULT_HIERARCHY,SP_DEFAULT_FLAG_FE);
		logger.info("CardIssueAction - GECKSNCO OUTPUT: " + executeSpCardOpNdg);
		ArrayList customersDataFromAFAList = new ArrayList();
		if(executeSpCardOpNdg != null && !"".equals(executeSpCardOpNdg.trim())) {
			String[] ndgColl =  executeSpCardOpNdg.trim().split(";");
			if(ndgColl.length != 0){
				for(int i=0; i<ndgColl.length; i++){
					if((ndgColl[i] != null && !"".equals(ndgColl[i].trim())) || debitCardIssueInOut.getCustomerNdg().equals(ndgColl[i])){ // skip empty ndg or the primary ndg contained in the list
						SearchCustomerParams custParamTemp = new SearchCustomerParams(userInfo, language);
						custParamTemp.setNdg(ndgColl[i]);
						it.usi.xframe.afa.bfutil.Customer customerTemp = AFAServiceFactory.getInstance().getAfaBaseServiceFacade().getCustomerSyntheticData(custParamTemp);
						if(customerTemp.getContacts() == null || customerTemp.getContacts().getEmail() == null || "".equals(customerTemp.getContacts().getEmail().trim())){
							logger.info("cardIssueBMConfirm: ndg number " + ndgColl[i] + " associated with ndg number " + sessionData.getNdg() + " has no valid email address - cannot send contract without a valid email address");
							return noEmailAddressErrorComplexPopUp(mapping, cardIssueForm, request, sessionData, true);
						}
						customersDataFromAFAList.add(customerTemp);
					}
				}
			}
		}
		logger.info("CardIssueAction - customersDataFromAFAList size = " + customersDataFromAFAList.size());
		
		//####################### INIZIO CHIAMATA OPEN DOSSIER BASKET MANAGER #######################
		
		String cardTypeDescription = GecUtilities.getGecParameterArea(BR0605, "DIGITAMB");
		String dossierMasterName = "Richiesta " + cardTypeDescription;
		String documentName = dossierMasterName;

		String sequence = "";
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;
		try {
			service = serviceFactory.getGecServiceFacade();
			sequence = service.retrieveSequenceBM();
		} catch (Exception e) {
			logger.error("[cardIssueBMVRConfirm - retrieveSequence] Error: ", e);
			return openComplexPopUpFailureDMBAndContinueToOldUpdate(mapping, request, form, response, actionBackToOldErrorUrl);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		String correlationId = 	GEC_APPLICATION + 
				FormatUtils.formatNumber((String)userInfo.getFilialeOperatore(), 5, 0, "N") +
				FormatUtils.formatNumber(debitCardIssueInOut.getCustomerNdg(), 15, 0, "N") +//FormatUtils.formatNumber((String)inquiryResponseClass.getCardInquiryData().getStandardContract().getNdg().getValue(), 15, 0, "N") +
				sequence; //sequence (progr)
		
		// Call BM Add Dossier
		Date plusThirtyDaysDate = GecWebUtilities.getPlusThirtyDaysDate(new Date());
		DateFormat df = new SimpleDateFormat(EXPIRATION_TIMESTAMP_FORMAT);
		String expirationTimestamp = df.format(plusThirtyDaysDate); // today plus thrirty days at midnight
		Date endOfDayDate = GecWebUtilities.getEndOfDayDate(new Date());
		Date midDayTestDate = GecWebUtilities.getMidDayTestDate(new Date());
		String dossierClassification = "Monetica Emissione Carte"; //constant
		
		DossierOutput outputWS;
		try {
			outputWS = callBMOpenDossier(userInfo, correlationId, dossierMasterName, dossierClassification, expirationTimestamp); // used same name as document but different businessKey
		} catch (Exception e) {
			logger.error("[cardIssueBMVRConfirm: WS BasketDossier open] Error: ", e);
			logger.info("cardIssueBMVRConfirm: PROSEGUIMENTO AS-IS a causa di errore durante chiamata Open al servizio di Basket Manager");
			return openComplexPopUpFailureDMBAndContinueToOldUpdateVR(mapping, request, form, response, actionBackToOldErrorUrl);
		}
		
		if(outputWS == null || !"0".equals(outputWS.getOutcome().getCode())) { // KO OPEN BASKET MANAGER
			logger.info("[cardIssueBMVRConfirm] BasketDossier Open - End with KO");
			logger.info("cardIssueBMVRConfirm: PROSEGUIMENTO AS-IS a causa di KO dal servizio Basket Manager in chiamata alla Open");
			return openComplexPopUpFailureDMBAndContinueToOldUpdateVR(mapping, request, form, response, actionBackToOldErrorUrl);
		}

		//####################### FINE CHIAMATA OPEN DOSSIER BASKET MANAGER #######################
		logger.info("[cardIssueBMVRConfirm] BasketDossier Open - End with success");
		
		// retireving dossierId from service output
		String dossierId = outputWS.getDossierId();

		// setting new data to call GECKTIN0 in CONFIRM
		debitCardIssueInOut.setCorrelationId(correlationId);
		debitCardIssueInOut.setIdDossier(dossierId);
		debitCardIssueInOut.setSubDossier(""); // leave this empty at this moment cause there isn't a subDossier right now
		debitCardIssueInOut.setExpirationTimestamp(""); // leave this empty at this moment cause there isn't a subDossier right now
		debitCardIssueInOut.setFunction(ISSUE_FUNCTION);

		CardIssueConfirmResponseClass classReturn = null;
		serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = null;
		// GECKTIN0 in CONFIRM
		try {
			serviceF = serviceFactory.getGecServiceFacade();
			classReturn = serviceF.debitCardIssueConfirmDMB(debitCardIssueInOut);
		} catch (Exception e) {
			logger.error("[cardIssueBMVRConfirm] Error: ", e);
			logger.info("cardIssueBMVRConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a GECKTIN0 in CONFIRM");
			return openComplexPopUpFailureDMBAndContinueToOldUpdateVR(mapping, request, form, response, actionBackToOldErrorUrl);
		} finally {
			if(serviceF != null && serviceFactory != null) {
				serviceFactory.dispose(serviceF);
			}
		}
		
		if (!this.isGaussResponseError(classReturn.getGaussResponse())) {
			logger.info("[cardIssueBMVRConfirm] GECKTIN0 in CONFIRM response successfully - begin operations on data before calling Basket Manager web service Add");
			
			String cardNumber = classReturn.getCardNumber();
			debitCardIssueInOut.setCardNumber(cardNumber);
			
			try {
				// preliminary operation before Basket Manager Add
				XDocument[] contract = new XDocument[1];
				for (int i = 0; i < classReturn.getPrintForm().length; i++) {
					logger.info("CardIssueAction.cardIssueBMVRConfirm classReturn.getPrintForm().length = " + classReturn.getPrintForm().length);
					classReturn.getPrintForm()[i].addPrintVar("ANA_CTB_FLAG", "Y");
					if(!"Y".equalsIgnoreCase(classReturn.getPrintForm()[i].getMapElement("MOD_GEM"))){
						logger.info("CardIssueAction.cardIssueBMVRConfirm found module with MOD_GEM != Y (contract) - index = " + i + ", formName = " + classReturn.getPrintForm()[i].getFormName() + ", docILC = " + classReturn.getPrintForm()[i].getDocILC());
						contract[0] = classReturn.getPrintForm()[i];
						contract[0].setNdg(clientIdCard);
						String[] ndgColl =  executeSpCardOpNdg.trim().split(";");
						if(ndgColl.length > 1){
							contract[0].addPrintVar("SYS_COINT", clientIdCard);
							ArrayList signersArray = new ArrayList();
							for (int j = 0; j < ndgColl.length; j++) {
								Signer signer = new Signer();
								signer.setNdg(ndgColl[j]);
								signersArray.add(signer);
								logger.info("cardIssueBMVRConfirm - adding Signer " + (j + 1) + " to doc #" + i + ": " + ndgColl[j]);
								
								contract[0].addPrintVar("SYS_SIGNER_" + (j + 1), ndgColl[j]);
								logger.info("cardIssueBMVRConfirm - adding SYS_SIGNER_" + (j + 1) + " to doc #" + i + ": " + ndgColl[j]);
							}
							contract[0].setSigners(signersArray);
							contract[0].setSignersFromCallingApp(true);
						}
					}
				}
				
				//######################
				String contractData = GecUtilities.getGecParameterArea("PRE" + contract[0].getFormName(), "DIGITAMB");
				String ftr = contractData.split(",")[0].trim();
				String product = contractData.split(",")[1].trim();
				String groupId = contractData.split(",")[2].trim();
				String contractPosition = "";
				String contractPracticeNumber = FormatUtils.formatNumber(cardNumber, 13, 0, "N");
				if(contract[0].getMapElement("POSIZIONE") != null && !"".equalsIgnoreCase(contract[0].getMapElement("POSIZIONE"))){
					contractPosition = contract[0].getMapElement("POSIZIONE");
				}
				AgreedSetRequest saveContractConditionsInput = new AgreedSetRequest();
				saveContractConditionsInput.setPracticeNumber("DMGEC" + contractPracticeNumber);
				AgreedSetRequestElement[] contractProducts = new AgreedSetRequestElement[1];
				AgreedSetRequestElement contractElement = new AgreedSetRequestElement();
				contractElement.setFtf("");
				contractElement.setFtr(ftr);
				contractElement.setGroupId(groupId);
				contractElement.setPosition(contractPosition);
				contractElement.setProduct(product);
				contractProducts[0] = contractElement;
				saveContractConditionsInput.setProducts(contractProducts);
				
				AgreedSetResponse saveContractConditionsResponse = null;
				
				try {
					serviceF = serviceFactory.getGecServiceFacade();
					saveContractConditionsResponse = serviceF.callSaveActualSet(saveContractConditionsInput);
				} catch (Exception e) {
					logger.error("[cardIssueBMVRConfirm] Error: ", e);
					logger.info("cardIssueBMVRConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio condizioni saveActualSet");
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
				} finally {
					if(serviceF != null && serviceFactory != null) {
						serviceFactory.dispose(serviceF);
					}
				}
				
				if(saveContractConditionsResponse == null || "KO".equalsIgnoreCase(saveContractConditionsResponse.getReturnCode())){
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
				}
				
				AgreedSetRequest retrieveContractConditionsInput = new AgreedSetRequest();
				retrieveContractConditionsInput.setPracticeNumber("DMGEC" + contractPracticeNumber);
				AgreedSetRequestElement[] retrieveContractConditionsProducts = new AgreedSetRequestElement[1];
				AgreedSetRequestElement retrieveContractConditionsElement = new AgreedSetRequestElement();
				retrieveContractConditionsElement.setGroupId(groupId); // C1?
				retrieveContractConditionsProducts[0] = retrieveContractConditionsElement;
				retrieveContractConditionsInput.setProducts(retrieveContractConditionsProducts);
				
				CtbWsPrintDocument[] retrieveContractConditionsResponse = null;
				try {
					serviceF = serviceFactory.getGecServiceFacade();
					retrieveContractConditionsResponse = serviceF.callRetrieveCtbConditionsSet(retrieveContractConditionsInput);
				} catch (Exception e) {
					logger.error("[cardIssueBMVRConfirm] Error: ", e);
					logger.info("cardIssueBMVRConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio condizioni contratto retrieveCtbConditionsSet");
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
				} finally {
					if(serviceF != null && serviceFactory != null) {
						serviceFactory.dispose(serviceF);
					}
				}
				
				if(retrieveContractConditionsResponse == null){
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
				}
				
				logger.info("CardIssueAction.cardIssueBMVRConfirm retrieveContractConditionsResponse.length = " + retrieveContractConditionsResponse.length);
				
				XDocument[] contractConditions = new XDocument[retrieveContractConditionsResponse.length];
				for (int i = 0; i < retrieveContractConditionsResponse.length; i++) {
	                CtbWsPrintDocument ctbDoc = retrieveContractConditionsResponse[i];
	                contractConditions[i] = new XDocument();
	                contractConditions[i].setFormName(ctbDoc.getFormName());
	                contractConditions[i].setJFormDocType(ctbDoc.getJFormDocType());
	                contractConditions[i].setPrecontratto(ctbDoc.getPrintMethod());
	                contractConditions[i].setSubForm(true);
	                contractConditions[i].setSubformGroup(ctbDoc.getGroup());
	                
	                if (ctbDoc.getVarMap() != null) {
	                   Iterator iterator = ctbDoc.getVarMap().keySet().iterator();
	                   while (iterator.hasNext()) {
	                       String k = (String) iterator.next();
	                       contractConditions[i].addPrintVar(k, ctbDoc.getVarMap().get(k));
	                   }
	                }
				}
				
				logger.info("CardIssueAction.cardIssueBMVRConfirm contractConditions.length = " + contractConditions.length);

				//Alla fine si hanno il XDocument originario e quello del Documento di Sintesi, da unire:

				XDocument[] contractDocsWithConditions = new XDocument[1 + contractConditions.length];
				contractDocsWithConditions[0] = contract[0];
				for (int i = 0; i < contractConditions.length; i++) {
					contractDocsWithConditions[i + 1] = contractConditions[i];
				}
				//######################
				
				logger.info("CardIssueAction.cardIssueBMVRConfirm contractDocsWithConditions.length = " + contractDocsWithConditions.length);
				
				String originalModuleList = XPrintUtilities.createModuleListXMLFromXDocument(contractDocsWithConditions);
				logger.info("cardIssueBMVRConfirm: ORIGINAL MODULELIST: " + originalModuleList);

				// set moduleId on modules
				for (int i = 0; i < contractDocsWithConditions.length; i++) {
					contractDocsWithConditions[i].setDigitalSigns("".toCharArray());

					if(contractDocsWithConditions[i].getDocID() == null || "".equalsIgnoreCase(contractDocsWithConditions[i].getDocID())){
						contractDocsWithConditions[i].setDocID("module"+i);
					}
				}
				
				// search the correct module for the current card type to send to Basket Manager Add Dossier
				/*XDocument[] bmDoc = new XDocument[1];
				boolean moduleForBMAddFound = false;
				
				// search correct module for current cardType among those obtained from GECKTIN0 in Confirm
				for(int i=0; i<classReturn.getPrintForm().length; i++){
					if(((CARD_TYPE_CC_VERN.equalsIgnoreCase(debitCardIssueInOut.getCardType()) || CARD_TYPE_CC_VERP.equalsIgnoreCase(debitCardIssueInOut.getCardType()))
							&& BR0605.equalsIgnoreCase(classReturn.getPrintForm()[i].getFormName()))) {
						moduleForBMAddFound = true;
					}
					
					if(moduleForBMAddFound){
						bmDoc[0] = classReturn.getPrintForm()[i];
						break;
					}
				}
				
				if(!moduleForBMAddFound){
					logger.error("Cannot call Basket Manager Add Dossier cause the correct module to use was not found in the moduleList returned from transaction GECKTIN0");
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl);
				}*/
				
				// backup modules to reuse them in DSI services call
				XDocument[] modulesBackup = classReturn.getPrintForm();
				
				String modifiedModuleList = XPrintUtilities.createModuleListXMLFromXDocument(contractDocsWithConditions);
				modifiedModuleList = removeDataRif(modifiedModuleList);
				String wrappedModuleList = "<![CDATA[" + modifiedModuleList + "]]>";
				logger.info("FINAL MODULELIST: " + wrappedModuleList);
				classReturn.setModuleList(wrappedModuleList);

				//####################### INIZIO CHIAMATA ADD DOSSIER BASKET MANAGER #######################
				
				String dossierExpirationTimeStamp = df.format(plusThirtyDaysDate); // TODO: change to endOfDayDate after test
				logger.info("dossierExpirationTimeStamp for BM: [" + dossierExpirationTimeStamp + "] ");
				String documentExpirationTimeStamp = df.format(endOfDayDate); // TODO: change to endOfDayDate after test
				logger.info("documentExpirationTimeStamp for BM: [" + documentExpirationTimeStamp + "] ");
				
				debitCardIssueInOut.setCardNumber(classReturn.getCardNumber());

				DossierDocumentOutput outputAddWS;
				
				XDocument[] mainDocument = new XDocument[]{contractDocsWithConditions[0]};
				
				try {
					outputAddWS = callBMAddDossier(userInfo, correlationId, dossierId, documentName, dossierClassification, dossierExpirationTimeStamp, documentExpirationTimeStamp, ndgType, mainDocument, wrappedModuleList, false, executeSpCardOpNdg, customersDataFromAFAList);
				} catch (Exception e) {
					logger.error("Basket Manager Add request error: " + e.getMessage(), e);
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
				}
				
				if(outputAddWS == null || !"0".equals(outputAddWS.getOutcome().getCode())) { // KO ADD BASKET MANAGER
					logger.info("[CardIssueAction:cardIssueBMVRConfirm] BasketDossier Add - End with KO");

					//INIZIO ROLLBACK
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
					//FINE ROLLBACK
				} else {
					logger.info("[CardIssueAction:cardIssueBMVRConfirm] BasketDossier Add - End with success");
					//####################### FINE CHIAMATA ADD DOSSIER BASKET MANAGER #######################

					//call GECKTIN0 in Update
					// all input data are as the previous GECKTIN0 update call
					String documentId = "";
					for (int j = 0; j < outputAddWS.getDossier()[0].getDocuments().length; j++) {
//						if(!outputAddWS.getDossier()[0].getDocuments()[j].getModule().startsWith("S")){
							documentId = outputAddWS.getDossier()[0].getDocuments()[j].getDocumentId();
//						}
					}
					debitCardIssueInOut.setSubDossier(outputAddWS.getDossier()[0].getDossierId());
					debitCardIssueInOut.setDocumentId(documentId);
					debitCardIssueInOut.setExpirationTimestamp(expirationTimestamp); //main Dossier expiration timeStamp 
					
					// GECKTIN0 in UPDATE
					try {
						serviceF = serviceFactory.getGecServiceFacade();
						classReturn = serviceF.debitCardIssueConfirmDMBUpdate(debitCardIssueInOut);
					} finally {
						if(serviceF != null && serviceFactory != null) {
							serviceFactory.dispose(serviceF);
						}
					}

					ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
					if (this.isGaussResponseError(classReturn.getGaussResponse())) { // service error
						logger.info("cardIssueBMVRConfirm: KO from GECKTIN0 in UPDATE - stopping procedure and redirecting to initial page");
						return commonOperationsBeforeComplexPopUpAndForwardAfterError(mapping, cardIssueForm, request, sessionData, classReturn.getGaussResponse(), true);
					} else {
						logger.info("success from GECKTIN0 in UPDATE");
						request.setAttribute("dmbStopPrint", "true");
						complexPopUpParams.setActionBackMessage(actionBackAfterSuccessUrl); // "gec.cardIssueConfirm.page"
						complexPopUpParams.setReturnBackMessage(true);
					}
					
					// DSI services
					// recovering precontract from modules list
					XDocument[] dsiDoc = new XDocument[1];
					boolean preContractFound = false;
					for(int i=0; i<modulesBackup.length; i++){
						if(
//								modulesBackup[i].getFormName() != null && modulesBackup[i].getFormName().startsWith("S")
								"Y".equalsIgnoreCase(modulesBackup[i].getMapElement("MOD_GEM"))
								){
							dsiDoc[0] = modulesBackup[i];
							preContractFound = true;
							break;
						}
					}
					if(preContractFound) {
						dsiDoc[0].addPrintVar("ANA_CTB_FLAG", "Y");
						dsiDoc[0].setDigitalSigns("".toCharArray());
						if (dsiDoc[0].getFormName() != null && !"".equalsIgnoreCase(dsiDoc[0].getFormName().trim())) {
							dsiDoc[0].setDocILC(dsiDoc[0].getFormName().trim() + "#11");
						} else {
							dsiDoc[0].setDocILC(dsiDoc[0].getDocILC().trim() + "#11");
						}
						dsiDoc[0].setDocumentNumber1("Precontratto " + cardTypeDescription);
						
						if(dsiDoc[0].getNdg() == null || "".equals(dsiDoc[0].getNdg())){
							dsiDoc[0].setNdg(clientIdCard);
						}
						
						String[] ndgColl =  executeSpCardOpNdg.trim().split(";");
						
						boolean isMultipleNdg = ndgColl.length > 1;
						
						XDocument[] docs = dsiDoc;
						
						//####################################
						
						String preContractPracticeNumber = "1" + FormatUtils.formatNumber(cardNumber, 12, 0, "N");
						AgreedSetRequest savePreContractConditionsInput = new AgreedSetRequest();
						savePreContractConditionsInput.setPracticeNumber("DMGEC" + preContractPracticeNumber);
						AgreedSetRequestElement[] preContractProducts = new AgreedSetRequestElement[1];
						AgreedSetRequestElement preContractElement = new AgreedSetRequestElement();
						preContractElement.setFtf("");
						preContractElement.setFtr(ftr);
						preContractElement.setGroupId(groupId);
//						preContractElement.setPosition(contractPosition);
						preContractElement.setProduct(product);
						preContractProducts[0] = preContractElement;
						savePreContractConditionsInput.setProducts(preContractProducts);
						
						AgreedSetResponse savePreContractConditionsResponse = null;
						
						try {
							serviceF = serviceFactory.getGecServiceFacade();
							savePreContractConditionsResponse = serviceF.callSaveActualSet(savePreContractConditionsInput);
						} catch (Exception e) {
							logger.error("[cardIssueBMVRConfirm] Error: ", e);
							logger.info("cardIssueBMVRConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio precondizioni saveActualSet");
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
						} finally {
							if(serviceF != null && serviceFactory != null) {
								serviceFactory.dispose(serviceF);
							}
						}
						
						if(savePreContractConditionsResponse == null || "KO".equalsIgnoreCase(savePreContractConditionsResponse.getReturnCode())){
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
						}
						
						AgreedSetRequest retrievePreContractConditionsInput = new AgreedSetRequest();
						retrievePreContractConditionsInput.setPracticeNumber("DMGEC" + preContractPracticeNumber);
						
						CtbWsPrintDocument[] retrievePreContractConditionsResponse = null;
						try {
							serviceF = serviceFactory.getGecServiceFacade();
							retrievePreContractConditionsResponse = serviceF.callRetrieveCtbConditionsSet(retrievePreContractConditionsInput);
						} catch (Exception e) {
							logger.error("[cardIssueBMVRConfirm] Error: ", e);
							logger.info("cardIssueBMVRConfirm: PROSEGUIMENTO AS-IS a causa di errore nella chiamata a servizio condizioni precontratto retrieveCtbConditionsSet");
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
						} finally {
							if(serviceF != null && serviceFactory != null) {
								serviceFactory.dispose(serviceF);
							}
						}
						
						if(retrievePreContractConditionsResponse == null){
							return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
						}
						
						XDocument[] preContractConditions = new XDocument[retrievePreContractConditionsResponse.length];
						for (int i = 0; i < retrievePreContractConditionsResponse.length; i++) {
			                CtbWsPrintDocument ctbDoc = retrievePreContractConditionsResponse[i];
			                preContractConditions[i] = new XDocument();
			                preContractConditions[i].setFormName(ctbDoc.getFormName());
			                preContractConditions[i].setJFormDocType(ctbDoc.getJFormDocType());
			                preContractConditions[i].setPrecontratto(ctbDoc.getPrintMethod());
			                preContractConditions[i].setSubForm(true);
			                preContractConditions[i].setSubformGroup(ctbDoc.getGroup());
			                
			                if (ctbDoc.getVarMap() != null) {
			                   Iterator iterator = ctbDoc.getVarMap().keySet().iterator();
			                   while (iterator.hasNext()) {
			                       String k = (String) iterator.next();
			                       preContractConditions[i].addPrintVar(k, ctbDoc.getVarMap().get(k));
			                   }
			                }
						}
						
						//Alla fine si hanno il XDocument originario e quello del Documento di Sintesi, da unire:

						XDocument[] preContractDocsWithConditions = new XDocument[1 + preContractConditions.length];
						preContractDocsWithConditions[0] = dsiDoc[0];
						for (int i = 0; i < preContractConditions.length; i++) {
							preContractDocsWithConditions[i + 1] = preContractConditions[i];
						}
						
						//####################################
						
						//#############
						ArrayList preContractList = new ArrayList();
						logger.info("CardIssueAction - creating preContractList for not-minor ndg");
						for (int i = 0; i < ndgColl.length; i++) {
							logger.info("CardIssueAction - creating preContractList #" + i);
							XDocument doc = GecUtilities.getXDocumentCopy(dsiDoc[0]);
							doc.setNdg(ndgColl[i]);
							doc.addPrintVar("ANA_CTB_FLAG", "Y");
							
							XDocument[] preContrWithConditions = new XDocument[1 + preContractConditions.length];
							preContrWithConditions[0] = doc;
							for (int j = 0; j < preContractConditions.length; j++) {
								preContrWithConditions[j + 1] = preContractConditions[j];
							}
							preContractList.add(preContrWithConditions);
						}
						/*if(isMultipleNdg){
							docs = new XDocument[ndgColl.length];
							for (int i = 0; i < docs.length; i++) {
								if(i == 0){
									docs[i] = dsiDoc[0];
								} else {
									docs[i] = GecUtilities.getXDocumentCopy(dsiDoc[0]);
									docs[i].setNdg(ndgColl[i]);
								}
							}
						}*/
						//#############
						
						int ind = 0;
						XDocument[] allDocs = new XDocument[ndgColl.length * (1 + preContractDocsWithConditions.length)];
						for (int i = 0; i < preContractList.size(); i++) {
							XDocument[] preContr = (XDocument[])preContractList.get(i);
							for (int j = 0; j < preContr.length; j++) {
								allDocs[ind + j] = preContr[j];
							}
							ind += preContr.length;
						}
						
//						String emailModuleList = XPrintUtilities.createModuleListXMLFromXDocument(dsiDoc);
//						emailModuleList = emailModuleList.replaceAll("name=\"docILC", "name=\"doc_ilc");
//						String emailWrappedModuleList = "<![CDATA[" + emailModuleList + "]]>";
//						logger.info("FINAL MODULELIST: " + emailWrappedModuleList);
//						callDSIServicesForContract(correlationId, customersDataFromAFAList, emailWrappedModuleList, userInfo, cardTypeDescription, false);
						callDSIServicesForContract(correlationId, customersDataFromAFAList, userInfo, cardTypeDescription, false, isMultipleNdg, docs, preContractList, ((XDocument[])(preContractList.get(0))));
					} else {
						logger.info("cardIssueBMVRConfirm: precontract module not found");
					}
					// END of DSI services
					request.getSession().setAttribute("disableDs2Call","false");
					forward = Utl.createComplexPopUp(complexPopUpParams);
					return forward;
				}
			} catch (Exception e) {
				logger.error("Error during BM add call / email process: ", e);
				try{
					//INIZIO ROLLBACK
					return emissBMRequestRollback(mapping, request, debitCardIssueInOut, actionBackAfterSuccessUrl, true);
					//FINE ROLLBACK
				} catch(XFRException ex) {
					logger.error("Exception from rollback: ", ex);
					throw ex;
				}
			} finally {
				if (service != null) {
					serviceFactory.dispose(service);
				}
			}
		} else { // this is the case of GECKTIN0 in CONFIRM when returns a GaussReponse with KO
			logger.info("cardIssueBMVRConfirm: KO from GECKTIN0 in CONFIRM - stopping procedure and redirecting to initial page");
			return commonOperationsBeforeComplexPopUpAndForwardAfterError(mapping, cardIssueForm, request, sessionData, classReturn.getGaussResponse(), true);
		}
	}
	
	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param sessionData
	 * @param cardIssueForm
	 * @param isVR if true must be changed the internal actionbackUrl generation process
	 * @return
	 * @throws Exception
	 */
	private ActionForward noEmailAddressErrorComplexPopUp(ActionMapping mapping, CardIssueForm cardIssueForm, HttpServletRequest request, SessionData sessionData, boolean isVR) throws Exception {
		//INIZIO MESSAGGIO PER SOLUZIONE NON DMB
		GaussResponse gaussResponse = new GaussResponse();

		HostResponseMessage[] newMessage = new HostResponseMessage[1];
		HostResponseMessage msg0000 = new HostResponseMessage();
		msg0000.setMessage("GEC01222"); //TEMP
		newMessage[0] = msg0000;
		gaussResponse.setFlagCode("E");
		gaussResponse.setHostResponseMessage(newMessage);
		//FINE MESSAGGIO PER SOLUZIONE NON DMB

//		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, gaussResponse);
////		complexPopUpParams.setActionBackMessage(actionBackErrorUrl);
////		complexPopUpParams.setReturnBackMessage(true);
//		complexPopUpParams.setActionBackError(actionBackErrorUrl);
//		complexPopUpParams.setReturnBackError(true);
////		complexPopUpParams.setForward("cardIssueConfirmPage"); // forward to subsAddendumUpdate method to continue the update the old-fashioned way
//
//		return Utl.createComplexPopUp(complexPopUpParams);
		
		
		return commonOperationsBeforeComplexPopUpAndForwardAfterError(mapping, cardIssueForm, request, sessionData, gaussResponse, isVR);
	}
	
	private ActionForward commonOperationsBeforeComplexPopUpAndForwardAfterError(ActionMapping mapping, CardIssueForm cardIssueForm, HttpServletRequest request, SessionData sessionData, GaussResponse gaussResponse, boolean isVR) throws Exception {
		// ee21246 metto in sessione il messaggio d'errore
		MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "issueConfirmMessage", gaussResponse);
		
		String actionBackUrl = "cardIssue.do?method=&sessionMarker=" + request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg();
		if(isVR){
			actionBackUrl += "&kind=" + sessionData.getKind();
		}
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, gaussResponse);
		complexPopUpParams.setActionBackError(actionBackUrl);
		complexPopUpParams.setActionBackMessage("");
		complexPopUpParams.setActionBackConfirm("");
		complexPopUpParams.setActionConfirm("");
		complexPopUpParams.setErrorForward("");
		complexPopUpParams.setSevereError(false);
		complexPopUpParams.setReturnBackError(true);
		complexPopUpParams.setReturnBackMessage(false);
		complexPopUpParams.setForwardBackError(false);
		complexPopUpParams.setForward("cardIssueFirstPage");
		ActionForward forward = Utl.createComplexPopUp(complexPopUpParams);
			
		String cardType = cardIssueForm.getCardType();
		String preContract = cardIssueForm.getPreContract();
		String clientIdCard = cardIssueForm.getNdgCard();
		String tmpAccount = cardIssueForm.getAccountBranch();
		boolean emptytmpacc = "".equals(tmpAccount);
		String type = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(0, tmpAccount.indexOf("/")) :"";
		String account = tmpAccount!=null && !emptytmpacc ? tmpAccount.substring(tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1) + 1):"";
		
		// request management
		request.setAttribute("cardTypeArray", sessionData.getCardType());
		request.setAttribute("preContract", preContract);
		request.setAttribute("selectedCardType", cardType);
		request.setAttribute("clientIdCard", clientIdCard);
		request.setAttribute("typePrint", type);
		request.setAttribute("selectedAccount", account);
		request.setAttribute("numRef", cardIssueForm.getPinReferenceNumber());
		
		if(isVR) {
			// title header and quickly (knowledge base) button management
			GecWebUtilities.createTitleHeader(request, "menu.label.cardIssueVR.text", this.getClass());
		} else {
			// title header and quickly (knowledge base) button management
			GecWebUtilities.createTitleHeader(request, "menu.label.cardIssue.text", this.getClass());
		}
		
		// Riabilito la chiamata a DS2
		request.getSession().setAttribute("disableDs2Call","false");
		
		return forward;
	}
	
	/**
	 * Starting from the input parameters, creates the input and calls the Basket Manager service to Open Dossier.<br>
	 * Returns the output from the service.<br>
	 * Throws every exceptions to the caller.
	 * 
	 * @param userInfo
	 * @param correlationId
	 * @param dossierName
	 * @param dossierClassification
	 * @param expirationTimestamp
	 * @return
	 * @throws IllegalAccessException
	 * @throws XFRException
	 * @throws RemoteException
	 */
	private DossierOutput callBMOpenDossier(
			UserData userInfo, 
			String correlationId, 
			String dossierName, 
			String dossierClassification,
			String expirationTimestamp) throws IllegalAccessException, XFRException, RemoteException {
		
		logger.info("correlationId for BM: " + correlationId);
		logger.info("expirationTimeStamp for BM: [" + expirationTimestamp + "] ");
		DossierInput input = new DossierInput();
		ProcessInfo processInfo = new ProcessInfo();
		processInfo.setApplication(GEC_APPLICATION);
		processInfo.setBranch(userInfo.getFilialeOperatore());
		processInfo.setChannel(DMB_REMOTE_CHANNEL);
		processInfo.setUserId(userInfo.getCodOperatore());
		DossierData dossierData = new DossierData();
		dossierData.setCorrelationId(correlationId);
		String dossierBusinessKey = "DMBSTOCK" + correlationId;
		dossierData.setBusinessKey(dossierBusinessKey);
		dossierData.setName(dossierName);
		dossierData.setClassification(dossierClassification);
		DossierParameter dossierParameter = new DossierParameter();
		dossierParameter.setExpirationTimestamp(expirationTimestamp);
		dossierData.setParameter(dossierParameter);
		input.setProcessInfo(processInfo);
		input.setDossierData(dossierData);
		input.setProcessParams(new ProcessParams());

		//PRINT INPUT START
		Class inputClass = DossierInput.class;
		Object inputObj = input;
		GecWebUtilities.printIOObject(inputClass, inputObj);
		//PRINT INPUT END

		GecServiceFactory gecServiceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;
		try {
			service = gecServiceFactory.getGecServiceFacade();
			DossierOutput outputBMOpen =  service.openDossier(input);
			
			//PRINT INPUT START
			Class outputClass = DossierOutput.class;
			Object outputObj = outputBMOpen;
			GecWebUtilities.printIOObject(outputClass, outputObj);
			//PRINT INPUT END
			
			return outputBMOpen;
		} finally {
			if (service != null) {
				gecServiceFactory.dispose(service);
			}
		}
	}
	
	/**
	 * Starting from the input parameters, creates the input and calls the Basket Manager service to Add Dossier.<br>
	 * Returns the output from the service.<br>
	 * Throws every exceptions to the caller.
	 * 
	 * @param userInfo
	 * @param correlationId
	 * @param dossierId
	 * @param documentName
	 * @param subDossierClassification
	 * @param documentExpirationTimestamp
	 * @param ndgType
	 * @param bmDoc
	 * @param wrappedModuleList must be the XML data to send to Basket Manager, inclusive of CDATA enclosing tags
	 * @return
	 * @throws IllegalAccessException
	 * @throws XFRException
	 * @throws RemoteException
	 */
	private DossierDocumentOutput callBMAddDossier(
			UserData userInfo, 
			String correlationId, 
			String dossierId, 
			String documentName, 
			String subDossierClassification,
			String dossierExpirationTimestamp,
			String documentExpirationTimestamp,
			String ndgType,
			XDocument[] bmDoc,
			String wrappedModuleList, 
			boolean isMinor, 
			String executeSpCardOpNdg,
			ArrayList customers) throws IllegalAccessException, XFRException, RemoteException {
		
		DossierDocumentInput inputDocument = new DossierDocumentInput();

		ProcessInfo processInfo = new ProcessInfo();
		processInfo.setApplication(GEC_APPLICATION);
		processInfo.setBranch(userInfo.getFilialeOperatore());
		processInfo.setChannel(DMB_REMOTE_CHANNEL);
		processInfo.setUserId(userInfo.getCodOperatore());
		
		DossierData masterDossier = new DossierData();
		masterDossier.setCorrelationId(correlationId);
		masterDossier.setDossierId(dossierId);

		DossierData[] subDossierList = new DossierData[1];

		DossierData subDossier = new DossierData();
		subDossier.setName(documentName); // using same name as open call, same as document
		subDossier.setClassification(subDossierClassification); // using same classification as open call
		subDossier.setCorrelationId(correlationId); // using same correlationId as open call
		FieldType[] subDossierAttributes = new FieldType[1];
		FieldType pushNotificationAttribute = new FieldType();
		pushNotificationAttribute.setName("sendAddDossierPushNotification");
		pushNotificationAttribute.setValue("Y");
		subDossierAttributes[0] = pushNotificationAttribute;
		subDossier.setAttribute(subDossierAttributes);
		CallbackParameter callback = new CallbackParameter();
		callback.setType("SOAP");
		callback.setEndpoint(GecUtilities.getGecParameterArea("CALLBACKURL", "DMB"));
		subDossier.setCallback(callback);
		
		Customer[] subDossierCustomers;
		
		String[] ndgList = executeSpCardOpNdg.trim().split(";");
		subDossierCustomers = new Customer[ndgList.length];
		for (int i = 0; i < ndgList.length; i++) {
			Customer subDossierCustomer = new Customer();
			subDossierCustomer.setNdg(ndgList[i]);
			String type = ((it.usi.xframe.afa.bfutil.Customer)(customers.get(i))).getNdgType().getCode();
			String name = ((it.usi.xframe.afa.bfutil.Customer)(customers.get(i))).getCompleteHeading();
			subDossierCustomer.setType(type);
			subDossierCustomer.setName(name);
			subDossierCustomers[i] = subDossierCustomer;
		}
		subDossier.setCustomers(subDossierCustomers);

		DossierParameter subDossierParameter = new DossierParameter();
		subDossierParameter.setExpirationTimestamp(dossierExpirationTimestamp);
		subDossier.setParameter(subDossierParameter);
		
//		// this attribute was required to specify that it's necessary to receive callback notifications only in case of Dossier expiration
//		FieldType[] subDossierAttributes = new FieldType[1];
//		FieldType subscribingEventTypeDossierExpired = new FieldType();
//		subscribingEventTypeDossierExpired.setName("subscribingEventType");
//		subscribingEventTypeDossierExpired.setValue("DOSSIER_EXPIRED");
//		subDossierAttributes[0] = subscribingEventTypeDossierExpired;
//		subDossier.setAttribute(subDossierAttributes);

		DossierDocument[] subDossierDocuments = new DossierDocument[bmDoc.length];
		
		logger.info("CardIssueAction.callBMAddDossier subDossierDocuments.length = " + subDossierDocuments.length);

		for (int j = 0; j < bmDoc.length; j++) {
			DossierDocument subDossierDocument = new DossierDocument();
			subDossierDocument.setBusinessKey("doc_externalKey"); // constant - don't change with values without testing, can break the service
			subDossierDocument.setName(documentName);
			subDossierDocument.setModuleCode(bmDoc[j].getFormName()); //another way can be the field docILC of the class BmDoc
			logger.info("CardIssueAction.callBMAddDossier subDossierDocument[" + j + "] moduleCode = " + bmDoc[j].getFormName());
			subDossierDocument.setModuleId(bmDoc[j].getDocID());
			logger.info("CardIssueAction.callBMAddDossier subDossierDocument[" + j + "] moduleId = " + bmDoc[j].getDocID());
			FieldType[] subDossierDocumentAttributes = new FieldType[1];
			FieldType layoutAttribute = new FieldType();
			layoutAttribute.setName("layout");
			layoutAttribute.setValue("1");
			subDossierDocumentAttributes[0] = layoutAttribute;
			subDossierDocument.setAttribute(subDossierDocumentAttributes);
			DocumentParameter subDossierDocumentParameter = new DocumentParameter();
			subDossierDocumentParameter.setExpirationTimestamp(documentExpirationTimestamp);
			subDossierDocument.setParameter(subDossierDocumentParameter);
			Customer[] subDossierDocumentCustomers = subDossierCustomers;
			for (int i = 0; i < subDossierDocumentCustomers.length; i++) {
				subDossierDocumentCustomers[i].setSigner("Y");
			}
			subDossierDocument.setCustomers(subDossierDocumentCustomers);
			subDossierDocuments[j] = subDossierDocument;
		}

		subDossier.setDocument(subDossierDocuments);
		subDossierList[0] = subDossier;
		masterDossier.setDossier(subDossierList);

		inputDocument.setDossierData(masterDossier);
		inputDocument.setProcessInfo(processInfo); // using same ProcessInfo object of the Open call
		inputDocument.setModuleListData(wrappedModuleList);

		//PRINT INPUT START
		Class inputClass = DossierDocumentInput.class;
		Object inputObj = inputDocument;
		GecWebUtilities.printIOObject(inputClass, inputObj);
		//PRINT INPUT END

		GecServiceFactory gecServiceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;
		try {
			service = gecServiceFactory.getGecServiceFacade();
			DossierDocumentOutput outputBMAdd = service.addDossier(inputDocument);
			
			//PRINT OUTPUT START
			Class outputClass = DossierDocumentOutput.class;
			Object outputObj = outputBMAdd;
			GecWebUtilities.printIOObject(outputClass, outputObj);
			//PRINT OUTPUT END
			
			return outputBMAdd;
		} finally {
			if (service != null) {
				gecServiceFactory.dispose(service);
			}
		}
	}
	
	/**
	 * Method to handle the calls to three consecutive DSI services.
	 * 
	 * @param correlationId
	 * @param customerDataFromAFA object from AFA with data of the primary NDG
	 * @param moduleListAsString text version of the module to send with email. It must be in XML format and enclosed in CDATA tag.
	 * @param connectedCustomers list of connected NDGs to put in CC in the email
	 * @param userData is necessary to recover additional data requested in the email message
	 * @param descriptionCardType card type description necessary for the email message and attachment name
	 * @throws Exception 
	 */
	private void callDSIServicesForContract(
			String correlationId, 
			ArrayList customersDataFromAFAList, 
			String moduleListAsString, 
			UserData userData,
			String descriptionCardType,
			boolean isMinor,
			boolean isMultipleNdg) throws Exception {
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = serviceFactory.getGecServiceFacade();
		try {
			
			InputDataVO inputData = new InputDataVO();
			inputData.setCorrelationId(correlationId);
			Field[] list = new Field[2];
			Field item0 = new Field();
			item0.setName("pdfProcessType");
			item0.setValue("EMPTY");
			Field item1 = new Field();
			item1.setName("callingApplication");
			item1.setValue(GEC_APPLICATION);
			list[0] = item0;
			list[1] = item1;
			inputData.setField(list);
			
			OutputResponse outputResponse = service.retrieveDsiGeneratePdf(inputData, moduleListAsString);
			
			if("OK".equals(outputResponse.getOutputData().getField(0).getValue())) {
				logger.info("OK from retrieveDsiGeneratePdf");
				
				CustomerNotificationSpecification input = new CustomerNotificationSpecification();
				RequestInfoSpecification req = new RequestInfoSpecification();
				req.setVerticalApp(GEC_APPLICATION);
				input.setRequestInfo(req);
				CustomerNotificationTypeEnum[] types = new CustomerNotificationTypeEnum[1];
				types[0] = CustomerNotificationTypeEnum.MAIL;
				CustomerMailNotificationSpecification mail = new CustomerMailNotificationSpecification();
				// Attachments Area
				// Specifications report only a single attachment
				if(outputResponse.getDocumentArray() != null 
						&& outputResponse.getDocumentArray().getDocument() != null 
						&& outputResponse.getDocumentArray().getDocument().length > 0) {
					MailAttachmentSpecification[] attachments = new MailAttachmentSpecification[1];
					MailAttachmentSpecification attachment = new MailAttachmentSpecification();
					//byte[] pdf = Base64.decodeBase64(outputResponse.getDocumentArray().getDocument(0).getPdf());
					attachment.setContent(outputResponse.getDocumentArray().getDocument(0).getPdf());
					attachment.setName("Precontratto " + descriptionCardType);
					attachments[0] = attachment;
					mail.setAttachments(attachments);
				}
				
				mail.setFrom("requestor@unicredit.eu");
				if (isMinor) {
					logger.info("Customer is minor: setting up legal guardian list for mail");
					String[] to = new String[customersDataFromAFAList.size()];
					for (int i = 0; i < customersDataFromAFAList.size(); i++) {
						to[i] = ((it.usi.xframe.afa.bfutil.Customer)(customersDataFromAFAList.get(i))).getContacts().getEmail();
					}
					mail.setTo(to);
				} else {
					logger.info("Customer is not minor: sending mail to main ndg");
					String[] to = new String[1];
					to[0] = ((it.usi.xframe.afa.bfutil.Customer)(customersDataFromAFAList.get(0))).getContacts().getEmail();
					mail.setTo(to);
					// cc Area
					if(customersDataFromAFAList != null && customersDataFromAFAList.size() > 1){
						String[] cc = new String[customersDataFromAFAList.size()-1];
						for(int i = 0; i < customersDataFromAFAList.size(); i++){
							if(i > 0){
								cc[i - 1] = ((it.usi.xframe.afa.bfutil.Customer) customersDataFromAFAList.get(i)).getContacts().getEmail();
							}
						}
						mail.setCc(cc);
					}
				}
				
				String todayDate = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
				mail.setMessage(
						"Roma, " + todayDate + "<br><br>" +
						"Gentile Cliente,<br><br>" +
						"come da sua richiesta trasmettiamo all'indirizzo mail su indicato<br><br>" +
						"- il Documento Informativo sulle spese ed il precontratto relativo a " + descriptionCardType +
						"<br><br><br>" +
						"<b>Cordiali saluti,</b><br>" +
						"<i>UniCredit S.p.A.</i><br><br>" +
						"Filiale di " + userData.getLuogo() + "<br><br><br>" // space to avoid automatic data to be too close
						);
				mail.setSubject("Precontratto");
				input.setNotificationTypes(types);
				input.setMailDetails(mail);
				
				CustomerNotificationResponse outputNot = service.retrieveDsiNotifyPdf(input);
				
				if("SENT".equalsIgnoreCase(outputNot.getMailNotification().getStatus().getValue())) {
				
					ArchiveModuleListDto inputA = new ArchiveModuleListDto();
					inputA.setApplicationCode(GEC_APPLICATION);
					inputA.setInputDocs(moduleListAsString);
					inputA.setProcessId("");
					ArchivingResult outputArch = service.retrieveDsiArchivePdf(inputA);
					logger.info("Data saved with success: " + outputArch.isDataSaved());
					if(!outputArch.isDataSaved()){
						logger.info("retrieveDsiArchivePdf FAILED");
						throw new Exception("retrieveDsiArchivePdf FAILED");
					}
				} else {
					logger.info("EMAIL NOT SENT");
					throw new Exception("ERROR: EMAIL NOT SENT");
				}
			} else {
				logger.info("retrieveDsiGeneratePdf FAILED");
				throw new Exception("retrieveDsiGeneratePdf FAILED");
			}
			
		} catch(Exception e) {
			logger.error("Error during DSI mail service setup or call: ", e);
			throw e;
		}

	}
	
	private void callDSIServicesForContract(
			String correlationId, 
			ArrayList customersDataFromAFAList, 
			UserData userData,
			String descriptionCardType,
			boolean isMinor,
			boolean isMultipleNdg,
			XDocument[] docs,
			ArrayList preContractList,
			XDocument[] allDocs) throws Exception {
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = serviceFactory.getGecServiceFacade();
		
		for (int i = 0; i < preContractList.size(); i++) {
			XDocument[] preContract = (XDocument[])(preContractList.get(i));
			logger.info("processing precontract #" + i);
			try {
				
				InputDataVO inputData = new InputDataVO();
				inputData.setCorrelationId(correlationId);
				Field[] list = new Field[2];
				Field item0 = new Field();
				item0.setName("pdfProcessType");
				item0.setValue("EMPTY");
				Field item1 = new Field();
				item1.setName("callingApplication");
				item1.setValue(GEC_APPLICATION);
				list[0] = item0;
				list[1] = item1;
				inputData.setField(list);
				
				String emailModuleList = XPrintUtilities.createModuleListXMLFromXDocument(preContract);
				emailModuleList = emailModuleList.replaceAll("name=\"docILC", "name=\"doc_ilc");
				String emailWrappedModuleList = "<![CDATA[" + emailModuleList + "]]>";
				logger.info("FINAL MODULELIST: " + emailWrappedModuleList);
				
				OutputResponse outputResponse = service.retrieveDsiGeneratePdf(inputData, emailWrappedModuleList);
				
				if("OK".equals(outputResponse.getOutputData().getField(0).getValue())) {
					logger.info("OK from retrieveDsiGeneratePdf");
					
					CustomerNotificationSpecification input = new CustomerNotificationSpecification();
					RequestInfoSpecification req = new RequestInfoSpecification();
					req.setVerticalApp(GEC_APPLICATION);
					input.setRequestInfo(req);
					CustomerNotificationTypeEnum[] types = new CustomerNotificationTypeEnum[1];
					types[0] = CustomerNotificationTypeEnum.MAIL;
					CustomerMailNotificationSpecification mail = new CustomerMailNotificationSpecification();
					// Attachments Area
					// Specifications report only a single attachment
					if(outputResponse.getDocumentArray() != null 
							&& outputResponse.getDocumentArray().getDocument() != null 
							&& outputResponse.getDocumentArray().getDocument().length > 0) {
						MailAttachmentSpecification[] attachments = new MailAttachmentSpecification[outputResponse.getDocumentArray().getDocument().length];
						for (int j = 0; j < attachments.length; j++) {
							MailAttachmentSpecification attachment = new MailAttachmentSpecification();
							//byte[] pdf = Base64.decodeBase64(outputResponse.getDocumentArray().getDocument(0).getPdf());
							attachment.setContent(outputResponse.getDocumentArray().getDocument(j).getPdf());
							attachment.setName("Precontratto " + descriptionCardType);
							attachments[j] = attachment;
						}
						mail.setAttachments(attachments);
						mail.setFrom("requestor@unicredit.eu");
						String[] to = new String[1];
						to[0] = ((it.usi.xframe.afa.bfutil.Customer)(customersDataFromAFAList.get(i))).getContacts().getEmail();
						mail.setTo(to);
						logger.info("Sending mail #" + (i + 1) + " to ndg " + preContract[0].getNdg() + " (mail: " + to[0] + ")");
						String todayDate = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
						mail.setMessage(
								"Roma, " + todayDate + "<br><br>" +
										"Gentile Cliente,<br><br>" +
										"come da sua richiesta trasmettiamo all'indirizzo mail su indicato<br><br>" +
										"- il Documento Informativo sulle spese ed il precontratto relativo a " + descriptionCardType +
										"<br><br><br>" +
										"<b>Cordiali saluti,</b><br>" +
										"<i>UniCredit S.p.A.</i><br><br>" +
										"Filiale di " + userData.getLuogo() + "<br><br><br>" // space to avoid automatic data to be too close
								);
						mail.setSubject("Precontratto");
						input.setNotificationTypes(types);
						input.setMailDetails(mail);
						
						CustomerNotificationResponse outputNot = service.retrieveDsiNotifyPdf(input);
						
						if(!"SENT".equalsIgnoreCase(outputNot.getMailNotification().getStatus().getValue())) {
							logger.info("EMAIL NOT SENT TO " + preContract[0].getNdg());
							throw new Exception("ERROR: EMAIL NOT SENT");
						} 
						ArchiveModuleListDto inputA = new ArchiveModuleListDto();
						inputA.setApplicationCode(GEC_APPLICATION);
						inputA.setInputDocs(emailWrappedModuleList);
						inputA.setProcessId("GEC_ARC");
						ArchivingResult outputArch = service.retrieveDsiArchivePdf(inputA);
						logger.info("Data saved with success: " + outputArch.isDataSaved());
						if(!outputArch.isDataSaved()){
							logger.info("retrieveDsiArchivePdf FAILED");
							throw new Exception("retrieveDsiArchivePdf FAILED");
						}
					}
					
				} else {
					logger.info("retrieveDsiGeneratePdf FAILED");
					throw new Exception("retrieveDsiGeneratePdf FAILED");
				}
				
			} catch(Exception e) {
				logger.error("Error during DSI mail service setup or call: ", e);
				throw e;
			}
			
		}

	}
	
	/**
	 * This method creates a ComplexPopUp in all the scenarios which require to forward to the old GECKWIN0 for UPDATE.<br>
	 * Also knows as Print on Paper procedure.
	 * @param mapping
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private ActionForward openComplexPopUpFailureDMBAndContinueToOldUpdate(ActionMapping mapping, HttpServletRequest request, ActionForm form, HttpServletResponse response, String actionBackErrorUrl) throws Exception{
		request.setAttribute(NO_DMB, "Y"); // necessary to avoid a loop inside cardIssueConfirm method
		request.setAttribute("showToPaperPopup", "true");
		return cardIssueConfirm(mapping, form, request, response);
	}
	
	/**
	 * This method creates a ComplexPopUp in all the scenarios which require to forward to the old GECKWIN0 for UPDATE.<br>
	 * Also knows as Print on Paper procedure.
	 * @param mapping
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private ActionForward openComplexPopUpFailureDMBAndContinueToOldUpdateVR(ActionMapping mapping, HttpServletRequest request, ActionForm form, HttpServletResponse response, String actionBackErrorUrl) throws Exception{
		request.setAttribute(NO_DMB, "Y"); // necessary to avoid a loop inside cardIssueConfirm method
		request.setAttribute("showToPaperPopup", "true");
		return cardIssueVRConfirm(mapping, form, request, response);
	}

	public ActionForward cardIssueVRConfirm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		logger.info("[CardIssueAction - cardIssueVRConfirm] --- init ---");
		
		boolean isCompanyAccount = "C".equalsIgnoreCase(request.getParameter("enabledFlag"));

		ActionForward forward = new ActionForward();

		CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");
		
		// retrieve input parameters
		String clientIdCard = cardIssueForm.getNdgCard();
		String tmpAccount = cardIssueForm.getAccountBranch();
		String type = tmpAccount.substring(0, tmpAccount.indexOf("/"));
		String branch = tmpAccount.substring(tmpAccount.indexOf("/") + 1, tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1));
		String account = tmpAccount.substring(tmpAccount.indexOf("/", tmpAccount.indexOf("/") + 1) + 1);
		String clientIdAccount = sessionData.getNdg();
		String pinReferenceNumber = "";
		String cardType = cardIssueForm.getCardType();
		String preContract = cardIssueForm.getPreContract();
		String freeOfCharge = cardIssueForm.getFreeOfChargeChoice();
		
		String typePrint = type;
		request.setAttribute("typePrint", typePrint);

		String selectedCardType = cardType;
		sessionData.setSelectedCardType(selectedCardType);
		logger.info("[CardIssueAction - cardIssueVRConfirm] selectedCardType: " + selectedCardType);

		
		// gauss service input definition
		DebitCardIssueInOut inputParams = new DebitCardIssueInOut();
		inputParams.setAbi("02008");
		inputParams.setCustomerNdg(clientIdCard);
		inputParams.setAccountType(type);
		inputParams.setAccountBranch(branch);
		inputParams.setAccountNumber(account); 
		inputParams.setAccountNdg(clientIdAccount);
		inputParams.setPinReferenceNumber(pinReferenceNumber);
		inputParams.setCardType(cardType);
		inputParams.setPreContract(preContract);
		inputParams.setFreeOfCharge(freeOfCharge);
		logger.info("[CardIssueAction - cardIssueVRConfirm] inputParams: " + inputParams.toJson());
		
		// Avvio integrazione DS2
		// ****************************************************************************************
		logger.info("[CardIssueAction - cardIssueVRConfirm] Chiamata DSI - Start");

		if(EsgCountryCode.isItalianCountry() && !isCompanyAccount){
			logger.info("cardIssueVRConfirm: selected card type: " + cardType);
			// Check DMB
			if(request.getAttribute(NO_DMB) == null && GecUtilities.isDigitalMailBoxOldSet()){
				if(
						!CARD_TYPE_CC_VERN.equalsIgnoreCase(cardIssueForm.getCardType()) //BR0605
						&& 
						!CARD_TYPE_CC_VERP.equalsIgnoreCase(cardIssueForm.getCardType()) //BR0605
						){

					// Do nothing - continue with DS2Call logic
					//							request.setAttribute(NO_DMB, "Y");

				} else {
					// Save necessary data to use after Boost call
//					request.getSession().setAttribute(CARD_ISSUE_FORM_CLASS, cardIssueForm);
					request.getSession().setAttribute(DEBIT_CARD_ISSUE_IN_OUT, inputParams);

					ActionForward fwd = executeDSICall(request, 
							sessionData, 
							mapping, 
							clientIdCard, 
							branch, 
							type, 
							account, 
							cardType,
							SP_DMB_V_FLAG_FE);
					if(fwd!=null){

						// Avvio reindirizzamento verso DS2
						return fwd;
					}
				}

			}
		}

		logger.info("[CardIssueAction - cardIssueVRConfirm] Chiamata DSI - End");
		// Fine integrazione DS2
		// ****************************************************************************************
		
		// gauss service call
		CardIssueConfirmResponseClass responseClass = new CardIssueConfirmResponseClass();
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade service = null;
		
		try {
			service = serviceFactory.getGecServiceFacade();
			responseClass = service.paymentCardIssueConfirm(inputParams);
		} catch (Exception e) {
			throw new XFRException(e);
		} finally {
			if (service != null) {
				serviceFactory.dispose(service);
			}
		}
		//test
		//responseClass.setGaussResponse(null);// to remove
		// service response management
		if (responseClass.getGaussResponse() == null || !responseClass.getGaussResponse().isErrorFlag()) { // gauss service ok
			
			logger.info("[CardIssueAction - cardIssueVRConfirm] gauss service correctly performed");
			
			sessionData.setAbi("02008");
			sessionData.setPreContract(preContract);
			sessionData.setSelectedCardType(selectedCardType);
			sessionData.setClientIdCard(clientIdCard);
			sessionData.setTypePrint(type);
			sessionData.setAccountBranchId(branch);
			sessionData.setAccountType(type);
			sessionData.setAccount(account);
			sessionData.setCardNumber(responseClass.getCardNumber());
			sessionData.setPinReferenceNumber(cardIssueForm.getPinReferenceNumber());
			sessionData.setFreeOfChargeChoice(freeOfCharge);
			sessionData.setFreeOfChargeFlag((freeOfCharge != null && (freeOfCharge.equals("Y") || freeOfCharge.equals("N"))) ? "3" : "2");
			
			
			logger.info("[CardIssueAction - cardIssueVRConfirm] sessionData: " + sessionData.getDebugString());
			
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "printForm", responseClass.getPrintForm());
			
			String cardNumber = sessionData.getCardNumber();
			String pin = sessionData.getPinReferenceNumber();
			cardIssueForm.setPinReferenceNumber(pin);
			request.setAttribute("cardNumber", cardNumber);

			String[] arrayString = new String[1];
			arrayString[0] = responseClass.getCardNumber();
			
			if(request.getAttribute("showToPaperPopup") != null && "true".equalsIgnoreCase((String)request.getAttribute("showToPaperPopup"))){
				XfrMessage.showInformationMessage(request, "card.label.oldIssueToPaperPopup.text", arrayString, null, "cardIssue.do?method=mapping.cardIssue.cardIssueVRRefresh&sessionMarker="	+ request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg()+ "&kind="+sessionData.getKind());
			} else {
				XfrMessage.showWarningMessage(request, "card.label.warningMessage1533.text", arrayString, null, "cardIssue.do?method=mapping.cardIssue.cardIssueVRRefresh&sessionMarker="	+ request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg()+ "&kind="+sessionData.getKind());
			}
			forward = this.cardIssueVRRefreshPrint(mapping, form, request, response);
			
			/* EE29570 - Garante2 start */
			if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){ 				
				log.debug("GARANTE2 LOG STARTS");
				try {
					Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(14, it.usi.warranter.Utils.REQUEST_TYPE_DISPOSITIVE, request); 				
					if (warranty2 != null) {
						String ndgClientCode = FormatUtils.formatString(sessionData.getClientIdCard());
						String siaCode 	= "";
						String cidCode 	= "";
						String accountNumber = "";
						String accountBranch = FormatUtils.formatString(sessionData.getAccountBranchId());
						String accountType 	= "";
						String accountIBAN 	= "";
						String accountABI 	= "";
						String accountCAB 	= "";
						String abi 			= FormatUtils.formatNumber(sessionData.getAbi(), 5, 0, "N");
						String cardNumberW  = FormatUtils.formatNumber(sessionData.getCardNumber(), 8, 0, "N");
						String product		= responseClass.getCardType();
	
						//LOG - NUMERO RAPPORTO CARTA (Forma Tecnica GeCa, Abi + Numero Carta)
						accountType = CardTypeConverter.convertCardType(product,true);
						accountNumber = abi + cardNumberW;	
						// if (accountNumber.length() < 13) accountNumber = "";													
						GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						
						//LOG - NUMERO RAPPORTO CONTO
						accountType = FormatUtils.formatString(sessionData.getAccountType());
						accountNumber = FormatUtils.formatString(sessionData.getAccount());														
						GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
																			
						if (warranty2.getParams().size() > 0)
							WarrantyTracer.trace(warranty2);
		
						log.debug("GARANTE2 LOG ENDS");
					}
				} catch (Exception e) {
					logger.info("[CardIssueAction: unspecified] GARANTE2 exception: " + e.getMessage(), e);
					throw new XFRException(e);
				}
			}
			/* Garante2 end	*/			
			
		} else { // gauss service error
			logger.info("[CardIssueAction - cardIssueConfirm] gauss service ended with errors");
			
			// ee21246 metto in sessione il messaggio d'errore
			MarkedSessionManager.getInstance().setMarkedSessionAttribute(request, "issueConfirmMessage", responseClass.getGaussResponse());
			
			String actionBackUrl = "cardIssue.do?method=&sessionMarker=" + request.getParameter("sessionMarker") + "&ndg=" + sessionData.getNdg()+ "&kind="+sessionData.getKind();
			
			ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, responseClass.getGaussResponse());
			complexPopUpParams.setActionBackError(actionBackUrl);
			complexPopUpParams.setActionBackMessage("");
			complexPopUpParams.setActionBackConfirm("");
			complexPopUpParams.setActionConfirm("");
			complexPopUpParams.setErrorForward("");
			complexPopUpParams.setSevereError(false);
			complexPopUpParams.setReturnBackError(true);
			complexPopUpParams.setReturnBackMessage(false);
			complexPopUpParams.setForwardBackError(false);
			complexPopUpParams.setForward("cardIssueVRFirstPage");
			forward = Utl.createComplexPopUp(complexPopUpParams);
		}
		
		// request management
		request.setAttribute("cardTypeArray", sessionData.getCardType());
		request.setAttribute("preContract", preContract);
		request.setAttribute("selectedCardType", selectedCardType);
		request.setAttribute("clientIdCard", clientIdCard);
		request.setAttribute("typePrint", type);
		request.setAttribute("selectedAccount", account);
		//request.setAttribute("numRef", cardIssueForm.getPinReferenceNumber());
		
		// title header and quickly (knowledge base) button management
		GecWebUtilities.createTitleHeader(request, "menu.label.cardIssueVR.text", this.getClass());
		
		// Riabilito la chiamata a DS2/DSI
		request.getSession().setAttribute("disableDs2Call","false");
		
		logger.info("[CardIssueAction - cardIssueVRConfirm] --- end ---");
		return forward;
	}


	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward cardIssueRefresh(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.info("[CardIssueAction - cardIssueRefresh] --- init ---");

		ActionForward forward = new ActionForward();
		CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");

		String preContract = sessionData.getPreContract();
		String selectedCardType = sessionData.getSelectedCardType();
		logger.info("*** selectedCardType >> " + selectedCardType);
		String clientIdCard = sessionData.getClientIdCard();
		String typePrint = sessionData.getTypePrint();
		String account = sessionData.getAccount();
		String cardNumber = sessionData.getCardNumber();
		String pin = sessionData.getPinReferenceNumber();

		cardIssueForm.setPinReferenceNumber(pin);

		request.setAttribute("numRef", cardIssueForm.getPinReferenceNumber());
		request.setAttribute("preContract", preContract);
		request.setAttribute("selectedCardType", selectedCardType);
		request.setAttribute("clientIdCard", clientIdCard);
		request.setAttribute("typePrint", typePrint);
		request.setAttribute("selectedAccount", account);
		request.setAttribute("cardNumber", cardNumber);
		request.setAttribute("cardIssueArray", sessionData.getCardIssueArray());
		request.setAttribute("cardTypeArray", sessionData.getCardType());

		request.setAttribute("cardType", sessionData.getCardType());
		request.setAttribute("noteMarks", sessionData.getNoteMarks());

		request.setAttribute("printFlag", "true");
		
		request.setAttribute("freeOfChargeChoice", sessionData.getFreeOfChargeChoice());
		request.setAttribute("freeOfChargeFlag", sessionData.getFreeOfChargeFlag());
		request.setAttribute("fastPayFlag", sessionData.getFastPayFlag());
		
		// FIRMAMIA
		request.setAttribute("xpiCheck", request.getParameter("xpiCheck"));

		// gestione titleHeader e button Quickly knowledge base
		GecWebUtilities.createTitleHeader(request, "menu.label.cardIssue.text", this.getClass());

		// non c'� GaussResponse, faccio un forward diretto
		forward = mapping.findForward("cardIssueFirstPage");
		
		// *** Debit Fast Pay - Start
		if("S1".equals(sessionData.getFastPayFlag())) {
				// --- Chiamata al servizio
			// -----------------------------------------------------------------------------------------------------------------------------------------------------
			DebitFastPayInOut paramsIn = new DebitFastPayInOut();
			// Definizione dei parametri di input al servizio
			paramsIn.getAbi().setValue(sessionData.getAbi());
			paramsIn.getNdg().setValue(sessionData.getNdg());
			paramsIn.getCard().setValue(cardNumber);
			paramsIn.getDeliveryTypeChoice().setValue("SU");
			paramsIn.setService("esgRequestOldDeliveryRetrieve");
			InquiryBancomatResponseClass infoResponse = new InquiryBancomatResponseClass();
	
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			IGecServiceFacade service = null;
			
			try {
				service = serviceFactory.getGecServiceFacade();
				infoResponse = service.retrieveFastPayInfo(paramsIn);
			} catch (Exception e) {
				logger.debug("[CardIssueAction - cardIssueRefresh] exception while calling inquiry service: " + e.getMessage(), e);
				throw new XFRException(e);
			} finally {
				if (service != null) {
					serviceFactory.dispose(service);
				}
			}
			
			if (infoResponse != null && infoResponse.getGaussResponse() != null
					&& infoResponse.getGaussResponse().isErrorFlag()) {
				logger.debug("[CardIssueAction - cardIssueRefresh] service error!");
				request.setAttribute("fastPayFlag", "");
			} else {
				logger.debug("[CardIssueAction - cardIssueRefresh]  service ok!");
				cardIssueForm.setDebitFastPayInOut(infoResponse != null? infoResponse.getDebitFastPay() : null);
			}
		}
		// *** Debit Fast Pay - End

		/* EE29570 - Garante2 start */
		if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){ 				

			log.debug("GARANTE2 LOG STARTS");
			try {
				Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(15, it.usi.warranter.Utils.REQUEST_TYPE_INQUIRY, request); 				
				if (warranty2 != null) {
					String ndgClientCode = FormatUtils.formatString(sessionData.getNdg());
					String siaCode 	= "";
					String cidCode 	= "";
					String accountNumber = "";
					String accountBranch = FormatUtils.formatString(sessionData.getAccountBranchId());
					String accountType 	= "";
					String accountIBAN 	= "";
					String accountABI 	= "";
					String accountCAB 	= "";
					String abi 			= FormatUtils.formatNumber(sessionData.getAbi(), 5, 0, "N");
					String cardNumberW  = FormatUtils.formatNumber(sessionData.getCardNumber(), 8, 0, "N");
					String product		= FormatUtils.formatString(sessionData.getSelectedCardType()).trim();
	
					//LOG - NUMERO RAPPORTO CARTA (Forma Tecnica GeCa, Abi + Numero Carta)
					accountType = CardTypeConverter.convertCardType(product,true);
					accountNumber = abi + cardNumberW;	
					// if (accountNumber.length() < 13) accountNumber = "";													
					GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
					warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						
					//LOG - NUMERO RAPPORTO CONTO
					accountType = FormatUtils.formatString(sessionData.getAccountType());
					accountNumber = FormatUtils.formatString(sessionData.getAccount());														
					GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
					warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
																			
					if (warranty2.getParams().size() > 0)
						WarrantyTracer.trace(warranty2);
		
					log.debug("GARANTE2 LOG ENDS");
				}
			} catch (Exception e) {
				logger.info("[CardIssueAction: unspecified] GARANTE2 exception: " + e.getMessage(), e);
				throw new XFRException(e);
			}
		}
		/* Garante2 end	*/	
		
		// FIRMAMIA EE57985
		this.print(mapping, form, request, response);

		logger.info("[CardIssueAction - cardIssueRefresh] --- end ---");
		return forward;
	}

	public ActionForward cardIssueVRRefresh(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.info("[CardIssueAction - cardIssueVRRefresh] --- init ---");

		ActionForward forward = null;
		CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");

		String preContract = sessionData.getPreContract();
		String selectedCardType = sessionData.getSelectedCardType();
		logger.info("*** selectedCardType >> " + selectedCardType);
		String clientIdCard = sessionData.getClientIdCard();
		String typePrint = sessionData.getTypePrint();
		String account = sessionData.getAccount();
		String cardNumber = sessionData.getCardNumber();
		String pin = sessionData.getPinReferenceNumber();

		cardIssueForm.setPinReferenceNumber(pin);

		request.setAttribute("numRef", cardIssueForm.getPinReferenceNumber());
		request.setAttribute("preContract", preContract);
		request.setAttribute("selectedCardType", selectedCardType);
		request.setAttribute("clientIdCard", clientIdCard);
		request.setAttribute("typePrint", typePrint);
		request.setAttribute("selectedAccount", account);
		request.setAttribute("cardNumber", cardNumber);
		request.setAttribute("cardIssueArray", sessionData.getCardIssueArray());
		request.setAttribute("cardTypeArray", sessionData.getCardType());

		request.setAttribute("cardType", sessionData.getCardType());
		request.setAttribute("noteMarks", sessionData.getNoteMarks());

		request.setAttribute("printFlag", "true");
		
		request.setAttribute("freeOfChargeChoice", sessionData.getFreeOfChargeChoice());
		request.setAttribute("freeOfChargeFlag", sessionData.getFreeOfChargeFlag());

		// gestione titleHeader e button Quickly knowledge base
		GecWebUtilities.createTitleHeader(request, "menu.label.cardIssueVR.text", this.getClass());

		// non c'� GaussResponse, faccio un forward diretto
		forward = mapping.findForward("cardIssueVRFirstPage");

		/* EE29570 - Garante2 start */
		if (EsgCountryCode.isItalianCountry() && GecUtilities.isGarante2Set()){ 				

			log.debug("GARANTE2 LOG STARTS");
			try {
				Warranty2 warranty2 = GecWebUtilities.getLoggerGarante2(15, it.usi.warranter.Utils.REQUEST_TYPE_INQUIRY, request); 				
				if (warranty2 != null) {
					String ndgClientCode = FormatUtils.formatString(sessionData.getNdg());
					String siaCode 	= "";
					String cidCode 	= "";
					String accountNumber = "";
					String accountBranch = FormatUtils.formatString(sessionData.getAccountBranchId());
					String accountType 	= "";
					String accountIBAN 	= "";
					String accountABI 	= "";
					String accountCAB 	= "";
					String abi 			= FormatUtils.formatNumber(sessionData.getAbi(), 5, 0, "N");
					String cardNumberW  = FormatUtils.formatNumber(sessionData.getCardNumber(), 8, 0, "N");
					String product		= FormatUtils.formatString(sessionData.getSelectedCardType()).trim();
	
					//LOG - NUMERO RAPPORTO CARTA (Forma Tecnica GeCa, Abi + Numero Carta)
					accountType = CardTypeConverter.convertCardType(product,true);
					accountNumber = abi + cardNumberW;	
					// if (accountNumber.length() < 13) accountNumber = "";													
					GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
					warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
						
					//LOG - NUMERO RAPPORTO CONTO
					accountType = FormatUtils.formatString(sessionData.getAccountType());
					accountNumber = FormatUtils.formatString(sessionData.getAccount());														
					GecWebUtilities.logParametriGarante2(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
					warranty2.addParam(ndgClientCode, siaCode, cidCode, accountType, accountBranch, accountNumber, accountIBAN, accountABI, accountCAB);
																			
					if (warranty2.getParams().size() > 0)
						WarrantyTracer.trace(warranty2);
		
					log.debug("GARANTE2 LOG ENDS");
				}
			} catch (Exception e) {
				logger.info("[CardIssueAction: cardIssueVRRefresh] GARANTE2 exception: " + e.getMessage(), e);
				throw new XFRException(e);
			}
		}
		/* Garante2 end	*/	

		logger.info("[CardIssueAction - cardIssueVRRefresh] --- end ---");
		return forward;
	}


	/**
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward cardIssueRefreshPrint(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.info("[CardIssueAction - cardIssueRefreshPrint] --- init ---");

		ActionForward forward = null;
		CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");

		String preContract = sessionData.getPreContract();
		String selectedCardType = sessionData.getSelectedCardType();
		logger.info("*** selectedCardType >> " + selectedCardType);
		String clientIdCard = sessionData.getClientIdCard();
		String typePrint = sessionData.getTypePrint();
		String account = sessionData.getAccount();
		String cardNumber = sessionData.getCardNumber();
		String pin = sessionData.getPinReferenceNumber();

		cardIssueForm.setPinReferenceNumber(pin);

		request.setAttribute("numRef", cardIssueForm.getPinReferenceNumber());
		request.setAttribute("preContract", preContract);
		request.setAttribute("selectedCardType", selectedCardType);
		request.setAttribute("clientIdCard", clientIdCard);
		request.setAttribute("typePrint", typePrint);
		request.setAttribute("selectedAccount", account);
		request.setAttribute("cardNumber", cardNumber);
		request.setAttribute("cardIssueArray", sessionData.getCardIssueArray());
		request.setAttribute("cardTypeArray", sessionData.getCardType());
		request.setAttribute("cardType", sessionData.getCardType());
		request.setAttribute("noteMarks", sessionData.getNoteMarks());
		request.setAttribute("printFlag", "false");
		
		request.setAttribute("freeOfChargeChoice", sessionData.getFreeOfChargeChoice());
		request.setAttribute("freeOfChargeFlag", sessionData.getFreeOfChargeFlag());

		// gestione titleHeader e button Quickly knowledge base
		GecWebUtilities.createTitleHeader(request, "menu.label.cardIssue.text", this.getClass());

		forward = mapping.findForward("cardIssueFirstPage");

		logger.info("[CardIssueAction - cardIssueRefreshPrint] --- end ---");
		return forward;
	}
	
	public ActionForward cardIssueVRRefreshPrint(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.info("[CardIssueAction - cardIssueVRRefreshPrint] --- init ---");

		ActionForward forward = null;
		//CardIssueForm cardIssueForm = (CardIssueForm) form;
		request.setAttribute("sessionMarker", request.getParameter("sessionMarker"));
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");

		String preContract = sessionData.getPreContract();
		String selectedCardType = sessionData.getSelectedCardType();
		logger.info("*** selectedCardType >> " + selectedCardType);
		String clientIdCard = sessionData.getClientIdCard();
		String typePrint = sessionData.getTypePrint();
		String account = sessionData.getAccount();
		String cardNumber = sessionData.getCardNumber();
		//String pin = sessionData.getPinReferenceNumber();

		//cardIssueForm.setPinReferenceNumber(pin);

		//request.setAttribute("numRef", cardIssueForm.getPinReferenceNumber());
		request.setAttribute("preContract", preContract);
		request.setAttribute("selectedCardType", selectedCardType);
		request.setAttribute("clientIdCard", clientIdCard);
		request.setAttribute("typePrint", typePrint);
		request.setAttribute("selectedAccount", account);
		request.setAttribute("cardNumber", cardNumber);
		request.setAttribute("cardIssueArray", sessionData.getCardIssueArray());
		request.setAttribute("cardTypeArray", sessionData.getCardType());
		request.setAttribute("cardType", sessionData.getCardType());
		request.setAttribute("noteMarks", sessionData.getNoteMarks());
		request.setAttribute("printFlag", "false");
		
		request.setAttribute("freeOfChargeChoice", sessionData.getFreeOfChargeChoice());
		request.setAttribute("freeOfChargeFlag", sessionData.getFreeOfChargeFlag());
		//request.setAttribute("kind", sessionData.getKind());

		// gestione titleHeader e button Quickly knowledge base
		GecWebUtilities.createTitleHeader(request, "menu.label.cardIssueVR.text", this.getClass());

		forward = mapping.findForward("cardIssueVRFirstPage");

		logger.info("[CardIssueAction - cardIssueVRRefreshPrint] --- end ---");
		return forward;
	}
	
	
	/**
	 * returns a json description of all accounts, using this structure
	 *  {
	 * 	  "<ndg>": <string of 16 chars>
	 *      [{
	 *        acnType: <string>
	 *        , acnBranch: <string>
	 *        , acnNumber: <string>
	 *        , enabledFlag: <string [E=enabled | D=disabled]>
	 *        , freeOfChargeFlag: <string>
	 *        , freeOfChargeValue: <string>
	 *      }]
	 *    , <ndg>: ...
	 *  }
	 * @param holders
	 * @return
	 */
	private String getJsonAccountList(CardIssueHolder[] holders) {
		
		String result = "";
		if (holders != null && holders.length > 0) {
			for (int i = 0; i < holders.length; i++) {
				result += (result.length() > 0) ? ", " : "";
				
				result += "\"" + holders[i].getClientId() + "\":"; // main key (ndg)
				result += "{";
				
				Account[] accounts = holders[i].getAccountList();
				String acnList = "";
				if (accounts != null && accounts.length > 0) {
					for (int k = 0; k < accounts.length; k++) {
						acnList += (acnList.length() > 0) ? ", " : "";
						
						acnList += "\"" + accounts[k].getType() + "/" + accounts[k].getBranch() + "/" + accounts[k].getAccountId() + "\":"; // secondary key (account)
						acnList += "{";
						acnList += "acnType:" + getJsonString(accounts[k].getType());
						acnList += ",acnBranch:" + getJsonString(accounts[k].getBranch(), true);
						acnList += ",acnNumber:" + getJsonString(accounts[k].getAccountId(), true);
						acnList += ",enabledFlag:" + getJsonString(accounts[k].getAccountFlAbil());
						acnList += ",freeOfChargeFlag:" + getJsonString(accounts[k].getFreeOfChargeFlag());
						acnList += ",freeOfChargeValue:" + getJsonString(accounts[k].getFreeOfChargeValue());
						acnList += "}";
					}
				}
				result += acnList;
				result += "}";
			} 
		}
		result = "{" + result + "}";
		logger.info("[CardIssueAction - getJsonAccountList] result: " + result);
		return result;
	}

	/**
	 * @param string
	 * @param b
	 * @return
	 */
	private String getJsonString(String string, boolean trimLeadingZeroes) {
		if (string != null) {
			String toReturn = (trimLeadingZeroes) ? Utl.trimLeft(string, '0') : string;
			return "\"" + toReturn + "\"";
		}
		return "null";
	}

	/**
	 * @param string
	 * @return
	 */
	private String getJsonString(String string) {
		return getJsonString(string, false);
	}
	
	/**
	 * EE47373 - A.P.
	 * Esegue la chiamata alla SP
	 * su CardIssueAction.cardIssueConrif()
	 * @param ndg
	 * @param accountBranch
	 * @param accountType
	 * @param accountNumber
	 * @param productCode
	 * @param hierarchy
	 * @param flagFrontEnd
	 * @return String
	 * @throws Exception
	 */
	private String executeSpCardOpNdg(String ndg,
									  String accountBranch,
									  String accountType,
									  String accountNumber,
									  String productCode,
									  String hierarchy,
									  String flagFrontEnd)throws Exception{
		
		logger.info("[CardIssueAction - executeSpCardOpNdg] --- start ---");
		
		// variabile di controllo
		String ret = null;
		
		// Ottiene una istanza valida della Service Factory
		GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
		IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
		
		try{
			
			if(ndg!=null && !ndg.equalsIgnoreCase("") &&
					accountBranch!=null && !accountBranch.equalsIgnoreCase("") && 
						accountType!=null && !accountType.equalsIgnoreCase("") &&
							accountNumber!=null && !accountNumber.equalsIgnoreCase(""))
			{
				// Eseguo creazione dell'Oggetto per chiamata a Store Procedure
				
				EsgCardOpNdgConnectedRequestInOut ndgConRequestIn = new EsgCardOpNdgConnectedRequestInOut();
				ndgConRequestIn.getIn_ndg().setValue(ndg);
				ndgConRequestIn.getIn_dipCC().setValue(accountBranch);
				ndgConRequestIn.getIn_tipoRap().setValue(accountType);
				ndgConRequestIn.getIn_numCC().setValue(accountNumber);
				ndgConRequestIn.getIn_codProdotto().setValue(productCode); 
				ndgConRequestIn.getIn_flFrontEnd().setValue(flagFrontEnd);
				ndgConRequestIn.getIn_codGerarchia().setValue(hierarchy);
				
				logger.info("Request SP with follow parameters:");
				logger.info("NDG >>..............." + ndg);
				logger.info("Account branch >>...." + accountBranch);
				logger.info("Account type >>......" + accountType);
				logger.info("Account number >>...." + accountNumber);		
				logger.info("Product code >>......" + productCode);
				logger.info("Hierarchy >>........." + hierarchy);
				logger.info("Flg Front-End >>....." + flagFrontEnd);
				
				// chiamata al servizio
				EsgCardOpNdgConnectedRequestInOut result = new EsgCardOpNdgConnectedRequestInOut();
				ndgConRequestIn.debug(); // display prima della chiamata al servizio
												
				result = serviceF.retriveNdgConnectedRequestInfo(ndgConRequestIn);
				
				// Verifico il risultato della SP.
				// e Creo un array di stringhe contenente gli NDG estratti dalla SP
				if(result!=null){
					
					ret = result.getOut_NdgColl()!=null ?  result.getOut_NdgColl().getValue().toString() :"";					
				}							
			}
			else{
				
				logger.error("Error during executeSpCardOpNdg. Error, parameters not found or not set");
			}
		}
		catch(Exception ex){
			
			// Sollevo eccesione
			logger.error(ex.getLocalizedMessage());
			throw ex;
		}
		finally{
			
			// Eseguo il dispose della risorsa transazionale verso Host
			serviceFactory.dispose(serviceF);
		}
		
		logger.info("[CardIssueAction - executeSpCardOpNdg] --- end ---");
		
		return ret;
	}
	/**
	 * Ottiene il valore della URL al quale eseguire la chiamata DS2 
	 * 
	 * @return String
	 */
	private String getEnvironmentVariable(){		
		String urlToCall = DS2Config.configure().getDs2EnvRuntimeVariable();//DS2Config.configure().getProperty("ds2.signerSelection.endpoint");
		logger.debug("DS2 page at url >> " + urlToCall);
		return  urlToCall;//DS2Config.configure().getProperty("ds2.signerSelection.endpoint");
		
	}
	/**
	 * Ottiene il valore con il quale verifico in Request
	 * se il controllo sulla chiamata a DS2 � o meno abilitata.
	 * @param request
	 * @return boolean
	 */
	private boolean isDisableDs2Call(HttpServletRequest request){
		boolean ret = false;
		String value  	= request.getSession().getAttribute("disableDs2Call")!=null ?
							request.getSession().getAttribute("disableDs2Call").toString() : "";
							
		if(value.equals("true")){
			ret = true;
		}
		
		return ret;
	}
	/**
	 * Ottiene la Url di Call Back da passare a DS2
	 * @param request
	 * @return String
	 */
	private String getDS2CallBackUrl(HttpServletRequest request){
		StringBuffer reqURL = request.getRequestURL();
		String contextPath = request.getContextPath();
		int endUrlServer = reqURL.indexOf(contextPath);
		String urlServer = reqURL.substring(0, endUrlServer); 
		
		// Visualizza la URL del server che verr� utilizzata come call back
		logger.debug("Call Back Url >> " + urlServer);
		
		return urlServer;
	}
	/**
	 * Recupera i parametri con i quali �
	 * stata effettuata la chiamata 
	 * @param req
	 * @return HashMap
	 */
	private HashMap mapRequestParameter(HttpServletRequest req){		
		int i=1;
		Enumeration params = req.getParameterNames(); 
		
		HashMap map = new HashMap();
						
		while(params.hasMoreElements()){
			String paramName = params.nextElement().toString();
			logger.debug("Parameter Name - "+paramName+", Value - " +req.getParameter(paramName));
			
			map.put(paramName, req.getParameter(paramName));
			
			i++;
		}
		
		
		return map;				
	}	
	/**
	 * EE47373 - A.P. Se previsto esegue la chiamata a DS2
	 * @param request
	 * @param sessionData
	 * @param mapping
	 * @param clientIdAccount
	 * @param branch
	 * @param type
	 * @param account
	 * @param cardType
	 * @return ActionForward
	 * @throws Exception
	 */
	private ActionForward executeDs2Call(HttpServletRequest request,
										 SessionData sessionData,
										 ActionMapping mapping,
										 String clientIdAccount,
										 String branch,
										 String type,
										 String account,
										 String cardType)throws Exception{
		
		ActionForward fwd = null;
		
		logger.info("[CardIssueAction - executeDs2Call] --- init ---");
		
		//
		// Variabili DS2		
		// ----------------------------------------------------------------------->
		String ds2branch = "";
		String ds2CallBackUrl="";
		String ds2Ndg = "";
		String ds2Bvi = "";
		String ds2SelectSigner="";
		String ds2UserId="";
		String ds2SkipSMS = "";
		String ds2Ca="";
		String ds2ShowHtml="";
		
		//
		// Variabile develop_op per la verifica del parametro Develop
		// ----------------------------------------------------------------------->
		String develop_od = "";
		
		// Mappa, i parametri della request in sessione.
		request.getSession().setAttribute("mapParameter",mapRequestParameter(request));		
		
		//
		// URL al quale eseguire la chiamata DS2
		// ----------------------------------------------------------------------->
		String DS2Url = getEnvironmentVariable();
//		String DS2Url = "https://dsi-uj.collaudo.usinet.it/DSI-EBA-FMW-RS/service-secure/boost/redirect"; // TEMP
///		String DS2Url = "https://ds2-uj.collaudo.usinet.it/DS2BIS-EBA-PF/pages/signerSelection.jsf"; // TEMP

		
		//
		// Metto in request i parametri rispetto alla url ds2 da chiamare
		// ----------------------------------------------------------------------->
		request.setAttribute("formActionDs2Url", DS2Url);
		
		//
		// Metto in request il front-end chiamante (FL_FE)
		// ----------------------------------------------------------------------->
		request.getSession().setAttribute("FL_FE",SP_DEFAULT_FLAG_FE);
						
		try{
						
			//
			// Verifico se � il primo giro e quindi la chimata a DS2 � consentita
			// ------------------------------------------------------------------->
			if(!isDisableDs2Call(request)){
				
				//
				// chiamata a SP per il recupero degli NDG
				// ------------------------------------------------------------------->
				String executeSpCardOpNdg = executeSpCardOpNdg(clientIdAccount,branch,type,account,cardType,SP_DEFAULT_HIERARCHY,SP_DEFAULT_FLAG_FE);
				String ndgResult =  executeSpCardOpNdg != null ? executeSpCardOpNdg.trim() : null;
				
				if(ndgResult!=null && !ndgResult.equals("")){
					
					
					// Verifico che la stringa non termini con il separatore
					// nel qual caso lo elimino per evitare di creare un array con un elemento in piu
					// ------------------------------------------------------------------->
					ndgResult = ndgResult.endsWith(";") ? ndgResult.substring(0,(ndgResult.length()-1)).trim() :ndgResult.trim();
					if(ndgResult!=null && !ndgResult.equals("")) {
						
						//
						// Genero un array utilizzando come separatore di campo il ';'
						// ------------------------------------------------------------------->
						String[] ndgColl = ndgResult.split(";");
						
						if(ndgColl!=null &&
								ndgColl.length<=4)
						{
							//
							// Innesco la chiamara a DS2
							// ---------------------------------------------------------------->
							develop_od = GecUtilities.getGecParameterArea("SMS-OTP-OD","DEVELOP");
							logger.info(">> DEVELOP OD Value >> " + develop_od);
							
							logger.info("Obtain country....");
							
							if(EsgCountryCode.isItalianCountry()){
								
								logger.info("Country >> ITA");
								
								if(develop_od!=null && develop_od.equalsIgnoreCase("Y")){
									
									ds2Bvi = DS2_BVI;
									ds2Ca = GecWebConstants.APPLICATION_CODE;	 														
									ds2CallBackUrl = getDS2CallBackUrl(request) + CALL_BACK_ACTION;
									ds2Ndg = ndgResult;
									ds2SelectSigner = DS2_SELECTSIGNER;
									ds2ShowHtml = DS2_SHOWHTML;
									ds2UserId = GecWebUtilities.getUserCode();
									ds2SkipSMS=DS2_SKIPSMS;
									
									// Carico in request i parametri che mi servono per fare la POST
									
									logger.info("Load DS2 parameters in request -- Start");
									
									request.setAttribute("branch", branch);
									request.setAttribute("callbackUrl", ds2CallBackUrl);
									request.setAttribute("ndg",ds2Ndg.trim());
									request.setAttribute("bvi", ds2Bvi);
									request.setAttribute("selectSigner", ds2SelectSigner);
									request.setAttribute("userId", ds2UserId);
									request.setAttribute("skipSMS", ds2SkipSMS);
									request.setAttribute("ca", ds2Ca);
									request.setAttribute("showHtml",ds2ShowHtml);
									
									logger.info("Load DS2 parameters in request -- End");
									
									// [DEBUG] Mostro il valore dei campi che costituiscono le informazioni 
									// passate mezzo POST a DS2
									logger.info("Branch..........>> " + ds2branch);
									logger.info("callBackUrl.....>> " + ds2CallBackUrl);
									logger.info("Ndg.............>> " + ds2Ndg);
									logger.info("Bvi.............>> " + ds2Bvi);
									logger.info("Select Signer...>> " + ds2SelectSigner);
									logger.info("User id.........>> " + ds2UserId);
									logger.info("Skip SMS........>> " + ds2SkipSMS);
									logger.info("Ca..............>> " + ds2Ca);
									logger.info("Show HTML.......>> " + ds2ShowHtml);
									
									// Metto in sessione il form con i suoi dati
									//request.getSession().setAttribute("cardAddDataActionForm", cardAddDataActionForm);
									
									// metto in sessione l'oggetto sessionData
									logger.info("Load session data parameters in session");
									request.getSession().setAttribute("sessionData", sessionData);																														
									
									// Return DS2 Call
									logger.info("Obrain DS2 forward parameter");
									fwd = mapping.findForward(GecWebConstants.DS2_CALL_PAGE);
								}
							}
						}
					}						
				}			
			}
			
		}
		catch(Exception ex){
						
			logger.error(ex.getLocalizedMessage());
			throw ex;
		}
		
		
		logger.info("[CardIssueAction - executeDs2Call] --- End ---");
		return fwd;
	}
	
	/**
	 * EE47373 - A.P. Se previsto esegue la chiamata a DS2
	 * @param request
	 * @param sessionData
	 * @param mapping
	 * @param clientIdAccount
	 * @param branch
	 * @param type
	 * @param account
	 * @param cardType
	 * @return ActionForward
	 * @throws Exception
	 */
	private ActionForward executeDSICall(HttpServletRequest request,
										 SessionData sessionData,
										 ActionMapping mapping,
										 String clientIdAccount,
										 String branch,
										 String type,
										 String account,
										 String cardType,
										 String flFeFlag)throws Exception{
		
		ActionForward fwd = null;
		
		logger.info("[CardIssueAction - executeDs2Call] --- init ---");
		
		//
		// Variabili DS2		
		// ----------------------------------------------------------------------->
		String ds2branch = "";
		String ds2CallBackUrl="";
		String ds2Ndg = "";
		String ds2Bvi = "";
		String ds2SelectSigner="";
		String ds2UserId="";
		String ds2SkipSMS = "";
		String ds2Ca="";
		String ds2ShowHtml="";
		String ds2DMB = "";
		
		//
		// Variabile develop_op per la verifica del parametro Develop
		// ----------------------------------------------------------------------->
		String develop_od = ""; //TODO: sostituire con flag develop DMB
		
		// Mappa, i parametri della request in sessione.
		request.getSession().setAttribute("mapParameter",mapRequestParameter(request));		
		
		//
		// URL al quale eseguire la chiamata DS2
		// ----------------------------------------------------------------------->
//		String DS2Url = getEnvironmentVariable();
//		String DS2Url = "https://dsi-uj.collaudo.usinet.it/DSI-EBA-FMW-RS/service-secure/boost/redirect"; // TEMP
//		String DS2Url = "https://ds2-uj.collaudo.usinet.it/DS2BIS-EBA-PF/pages/signerSelection.jsf"; // TEMP
		String DS2Url = GecUtilities.getGecParameterArea("ENDPOINT_URL", "WSDSI");

		
		//
		// Metto in request i parametri rispetto alla url ds2 da chiamare
		// ----------------------------------------------------------------------->
		request.setAttribute("formActionDs2Url", DS2Url);
		
		//
		// Metto in request il front-end chiamante (FL_FE)
		// ----------------------------------------------------------------------->
		request.getSession().setAttribute("FL_FE", flFeFlag);
						
		try{
						
			//
			// Verifico se � il primo giro e quindi la chimata a DS2 � consentita
			// ------------------------------------------------------------------->
			if(!isDisableDs2Call(request)){
				
				//
				// chiamata a SP per il recupero degli NDG
				// ------------------------------------------------------------------->
				String executeSpCardOpNdg = executeSpCardOpNdg(clientIdAccount,branch,type,account,cardType,SP_DEFAULT_HIERARCHY,SP_DEFAULT_FLAG_FE);
				String ndgResult =  executeSpCardOpNdg != null ? executeSpCardOpNdg.trim() : null;
				
				if(ndgResult!=null && !ndgResult.equals("")){
					
					
					// Verifico che la stringa non termini con il separatore
					// nel qual caso lo elimino per evitare di creare un array con un elemento in piu
					// ------------------------------------------------------------------->
					ndgResult = ndgResult.endsWith(";") ? ndgResult.substring(0,(ndgResult.length()-1)).trim() :ndgResult.trim();
					if(ndgResult!=null && !ndgResult.equals("")) {
						
						//
						// Genero un array utilizzando come separatore di campo il ';'
						// ------------------------------------------------------------------->
						String[] ndgColl = ndgResult.split(";");
						
						if(ndgColl!=null &&
								ndgColl.length<=4)
						{
							//
							// Innesco la chiamara a DS2
							// ---------------------------------------------------------------->
							develop_od = GecUtilities.getGecParameterArea("SMS-OTP-OD","DEVELOP");
							logger.info(">> DEVELOP OD Value >> " + develop_od);
							
							logger.info("Obtain country....");
							
							if(EsgCountryCode.isItalianCountry()){
								
								logger.info("Country >> ITA");
								
								if(develop_od!=null && develop_od.equalsIgnoreCase("Y")){
									
									ds2Bvi = DS2_BVI;
									ds2Ca = GecWebConstants.APPLICATION_CODE;	 														
									ds2CallBackUrl = getDS2CallBackUrl(request) + CALL_BACK_ACTION;
									ds2Ndg = ndgResult;
									ds2SelectSigner = DS2_SELECTSIGNER;
									ds2ShowHtml = DS2_SHOWHTML;
									ds2UserId = GecWebUtilities.getUserCode();
									ds2SkipSMS=DS2_SKIPSMS;
									ds2DMB="Y";
									
									// Carico in request i parametri che mi servono per fare la POST
									
									logger.info("Load DS2 parameters in request -- Start");
									
									request.setAttribute("branch", branch);
									request.setAttribute("callbackUrl", ds2CallBackUrl);
									request.setAttribute("ndg",ds2Ndg.trim());
									request.setAttribute("bvi", ds2Bvi);
									request.setAttribute("selectSigner", ds2SelectSigner);
									request.setAttribute("userId", ds2UserId);
									request.setAttribute("skipSMS", ds2SkipSMS);
									request.setAttribute("ca", ds2Ca);
									request.setAttribute("showHtml",ds2ShowHtml);
									request.setAttribute("ds2DMB", ds2DMB);
									
									logger.info("Load DS2 parameters in request -- End");
									
									// [DEBUG] Mostro il valore dei campi che costituiscono le informazioni 
									// passate mezzo POST a DS2
									logger.info("Branch..........>> " + ds2branch);
									logger.info("callBackUrl.....>> " + ds2CallBackUrl);
									logger.info("Ndg.............>> " + ds2Ndg);
									logger.info("Bvi.............>> " + ds2Bvi);
									logger.info("Select Signer...>> " + ds2SelectSigner);
									logger.info("User id.........>> " + ds2UserId);
									logger.info("Skip SMS........>> " + ds2SkipSMS);
									logger.info("Ca..............>> " + ds2Ca);
									logger.info("Show HTML.......>> " + ds2ShowHtml);
									logger.info("DMB.............>> " + ds2DMB);
									
									// Metto in sessione il form con i suoi dati
									//request.getSession().setAttribute("cardAddDataActionForm", cardAddDataActionForm);
									
									// metto in sessione l'oggetto sessionData
									logger.info("Load session data parameters in session");
									request.getSession().setAttribute("sessionData", sessionData);																														
									
									// Return DS2 Call
									logger.info("Obrain DS2 forward parameter");
									fwd = mapping.findForward(GecWebConstants.DS2_CALL_PAGE);
								}
							}
						}
					}						
				}			
			}
			
		}
		catch(Exception ex){
						
			logger.error(ex.getLocalizedMessage());
			throw ex;
		}
		
		
		logger.info("[CardIssueAction - executeDs2Call] --- End ---");
		return fwd;
	}
	
	public ActionForward cardIssueUpdateFastPay(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws java.lang.Exception {

		logger.debug("[CardIssueAction - updatePinReprintInfo] --- init ---");
		//boolean isWarningPopupVisible = false;
		// Forward and Form initialization

		ActionForward forward = new ActionForward();
		CardIssueForm oForm = (CardIssueForm) form;

		// managin session data
		String sessionMarker = request.getParameter("sessionMarker");
		logger.debug("sessionMarker=" + sessionMarker);
		request.setAttribute("sessionMarker", sessionMarker);

		// L'oggetto sessionData � recuperato dalla session, altrimentri dalla
		// request, altrimenti contiene stringhe vuote
		SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");

		logger.debug("[CardIssueAction - updateFastPayInfo] session marker: " + sessionMarker);
		logger.debug("[CardIssueAction - updateFastPayInfo] ndg: " + sessionData.getNdg());
		logger.debug("[CardIssueAction - updateFastPayInfo] cardNumber: " + sessionData.getCardNumber());
		logger.debug("[CardIssueAction - updateFastPayInfo] accountBranchId: " + sessionData.getAccountBranchId());
		logger.debug("[CardIssueAction - updateFastPayInfo] abi: " + sessionData.getAbi());

		// title header management
		GecWebUtilities.createTitleHeader(request, "image.label.reprintPin", this.getClass());

		// ---- 1. update service
		// ---------------------------------------------------------------------------------------------------------------------------------------------------
		// call inquiry service
		InquiryBancomatResponseClass updateResponse = new InquiryBancomatResponseClass();
		
		oForm.getDebitFastPayInOut().getAbi().setValue(sessionData.getAbi());
		oForm.getDebitFastPayInOut().getCard().setValue(sessionData.getCardNumber());

		try {
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			try {
				IGecServiceFacade serviceF = serviceFactory.getGecServiceFacade();
				try {
					oForm.getDebitFastPayInOut().setService("esgRequestOldDeliveryConfirm");
					updateResponse = serviceF.updateFastPayInfo(oForm.getDebitFastPayInOut());
				} finally {
					serviceFactory.dispose(serviceF);
				}
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}
		
		MarkedSessionManager markedSessionManager = new MarkedSessionManager();
		request.setAttribute("printFlagFast", "Y");
		sessionData.setFastPayFlag("");
		markedSessionManager.setMarkedSessionAttribute(request, "sessionData", sessionData);
		
		this.cardIssueRefresh(mapping, oForm, request, response);
		
		ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, updateResponse.getGaussResponse());
		complexPopUpParams.setForward("cardIssueFirstPage");
		complexPopUpParams.setActionBackError("");
		complexPopUpParams.setActionBackMessage("");
		complexPopUpParams.setSevereError(false);
		complexPopUpParams.setReturnBackError(false);
		complexPopUpParams.setReturnBackMessage(false);
		complexPopUpParams.setForwardBackError(false);

		forward = Utl.createComplexPopUp(complexPopUpParams);
		
		logger.debug("[CardIssueAction - updatePinReprintInfo] --- end ---");
		return forward;
	}
	
	public ActionForward normalizeAddress(ActionMapping mapping,
			ActionForm form,
			HttpServletRequest request,
			HttpServletResponse response) 
	throws Exception {
		
		logger.info("normalizeAddress --- start");
		CardIssueForm oForm = (CardIssueForm)form;
		
		String jsonResult = GecUtilities.afaNormalizeAddress((String) oForm.getDebitFastPayInOut().getNormAddressUrl().getValue(),
															 (String) oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow02().getValue(),
															 (String) oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow04().getValue(),
															 (String) oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow05Cap().getValue(),
															 (String) oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow05Pv().getValue(),
															 (String) oForm.getDebitFastPayInOut().getAddressChoice().getAddressRow05Naz().getValue());
		
		response.setHeader("Content-Type", "application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.write(jsonResult);
		out.flush();
		out.close();
		logger.info("normalizeAddress --- end");
		return null;
	}
	
	protected boolean isGaussResponseError(GaussResponse gaussResponse) {
		if (gaussResponse != null && gaussResponse.isErrorFlag())
			return true;
		return false;
	}
	
	
	//FIRMAMIA EE57985
		//**MC**
	/*private boolean pilotBranchCheck(String module) throws RemoteException, XFRException, Exception{
		// EE29052 - Mock
//		return true;
		
		
		UserData userData = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
		String branch = userData.getFilialeOperatore() != null ? userData.getFilialeOperatore() : "";
		
		PaperlessCheckInput input = new PaperlessCheckInput();
		input.setFiliale(branch);
		input.setModulo(module);
		
		logger.info("PILOTBRANCHCHECK - BRANCH: " + branch + " MODULE: " + module);

		// -- 3 -- chiamata al servizio -----------------------------------------------------------------------------------------------------
 
		PaperlessCheckOutput output = new PaperlessCheckOutput();		
		GecServiceFactory serviceF = GecServiceFactory.getInstance();
		IGecServiceFacade serv = serviceF.getGecServiceFacade();
		try {
			// service call
			output = serv.retrievePaperlessCheck(input);
		} finally {
			serviceF.dispose(serv);
		}
 
		if (output.getReturnCode() == 0) { // service call OK
			logger.info("GECKSFMR RESPONSE OK. flagRetry = " + output.getFlagRetry());
			return "[Y]".equalsIgnoreCase(output.getFlagRetry().trim());
		} else {
			logger.info("GECKSFMR RESPONSE KO");
			return false;

		}
	}*/
		
		//**MC**
		private static boolean checkBranch(String branch) throws Exception {
			logger.info("[cardIssueAction] - [checkBranch] - START");
			String paperlessFunction = XPIConstants.PAPERLESS_CHECK_BRANCH;
			boolean risultato = false;
			try {
				SignpadInOut signpadInOut = new SignpadInOut();
				signpadInOut.getFunction().setValue(paperlessFunction);
				signpadInOut.getOperatingBranch().setValue(branch);
				SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
				risultato = signpadResponseClass.isSignpadFeasibility();
				logger.info("***************** [cardIssueAction] - [checkBranch] filialeEvoluta: " + risultato);
			} catch (Exception e) {
				throw e;
			}
			return risultato;
		}
		
		//**MC**
		private static boolean checkNdg(String ndg) throws Exception {
			logger.info("[cardIssueAction] - [checkNdg] - START");
			String paperlessFunction = XPIConstants.PAPERLESS_CHECK_NDG;
			boolean risultato = false;
			try {
				SignpadInOut signpadInOut = new SignpadInOut();
				signpadInOut.getFunction().setValue(paperlessFunction);
				signpadInOut.getNdgSigner().setValue(ndg);
				SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
				risultato = signpadResponseClass.isSignpadFeasibility();
				logger.info("***************** [cardIssueAction] - [checkNdg] ndg evoluto: " + risultato);
			} catch (Exception e) {
				throw e;
			}
			return risultato;
		}
		
		//**MC**
		private static boolean checkModule(XDocument[] module) throws Exception {
			logger.info("[cardIssueAction] - [checkModule] - START");
			String paperlessFunction = XPIConstants.PAPERLESS_CHECK_MODULE;
			boolean risultato = false;
			try {
				SignpadInOut signpadInOut = new SignpadInOut();
				signpadInOut.getFunction().setValue(paperlessFunction);
				signpadInOut.setXDocs(module);
				SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
				risultato = signpadResponseClass.isSignpadFeasibility();
				logger.info("***************** [cardIssueAction] - [checkModule] modulo evoluto: " + risultato);
			} catch (Exception e) {
				throw e;
			}
			return risultato;
		}
		
		private static boolean checkAll(String branch, String ndg, XDocument[] module) throws Exception {
			log.info("[CardIssueAction] - [checkAll] - START");
			if(GecUtilities.isFirmaMiaSkipXpiCheckSet()) return true;
			String paperlessFunction = XPIConstants.PAPERLESS_CHECK_ALL;
			boolean risultato = false;
			try {
				SignpadInOut signpadInOut = new SignpadInOut();
				signpadInOut.getFunction().setValue(paperlessFunction);
				signpadInOut.getOperatingBranch().setValue(branch);
				signpadInOut.getNdgSigner().setValue(ndg);
				signpadInOut.setXDocs(module);
				SignpadResponseClass signpadResponseClass = SignpadUtilities.checkPaperlessFeasibility(signpadInOut);
				risultato = signpadResponseClass.isSignpadFeasibility();
				log.info("***************** [CardIssueAction] - [checkAll] filiale/ndg/modulo evoluti: " + risultato);
			} catch (Exception e) {
				throw e;
			}
			return risultato;
		}
		
		public boolean xpiCheck(XDocument[] module){
			UserData dataInfo;
			try {
				dataInfo = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
			} catch (ServiceFactoryException e) {
				logger.error("Error while retrieving user info ", e);
				return false;
			} catch (RemoteException e) {
				logger.error("Error while retrieving user info ", e);
				return false;
			} catch (HostUserInfoException e) {
				logger.error("Error while retrieving user info ", e);
				return false;
			}
			String filialeOperatore = dataInfo.getFilialeOperatore();
			boolean xpiPaperlessFeasibilityResult;
			try {
				xpiPaperlessFeasibilityResult = checkBranch(filialeOperatore) && checkModule(module);
			} catch (Exception e) {
				logger.error("Error when checking module and branch paperless feasibility for FirmaMia ", e);
				return false;
			}
			if(xpiPaperlessFeasibilityResult){
				logger.info("XPICHECK - VADO IN DIGITALE");
			} else {
				logger.info("XPICHECK - VADO SU CARTA");
			}
			
			return xpiPaperlessFeasibilityResult;
		}
		
		/*private boolean checkTablet(String sessionMarker) throws Exception{
			return pilotBranchCheck(MODULE) && EsgCountryCode.isItalianCountry() ; //EE57985 Commentato perch� non riesco a fare andare la stored
		}*/
		
		private String getProcessId(HttpServletRequest request, int retryAttempt) throws ServiceFactoryException, RemoteException, HostUserInfoException{
			UserData userData = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
			Date currentDate = new Date();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			
			String appl = "GEC";
			String matricola = userData.getCodOperatore();
			String currentTimestamp = df.format(currentDate);
			String retryProgr = String.valueOf(retryAttempt);
			
			String processId = appl + matricola + currentTimestamp + retryProgr;
			logger.info("PROCESSID = " + processId);
			return processId;
		}
		
		//**MC**
		public ActionForward checkSignatureProcessOutcome(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response) throws IOException, XFRException{
			logger.debug("cardIssueAction.checkSignatureProcessOutcome --- start");
			
			GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
			IGecServiceFacade service = serviceFactory.getGecServiceFacade();
			
			String token = "";
			
			ProcessTrackBean[] outputWS = null;
			String wsOut;
			if(!"true".equalsIgnoreCase((String)request.getSession().getAttribute("stopRetry"))){
				logger.info("PROCESSTRACKSERVICE INPUT - TOKEN: " + token);
				token = (String)request.getSession().getAttribute("processId");
				try {
					service = serviceFactory.getGecServiceFacade();
					outputWS = service.callProcessTrackService(token);
				} catch (XFRException e) {
					logger.error("Error while calling processTrackService: {}", e);
				} catch (Exception e) {
					logger.error("Error while calling processTrackService: {}", e);
				}
				
				if(outputWS == null || outputWS.length == 0){
					logger.info("PROCESSTRACKSERVICE OUTPUT - NULL");
					wsOut = "KO";
				} else {
					int signVerified = 0;
					for (int i = 0; i < outputWS.length; i++) {
						logger.info("PROCESSTRACKSERVICE OUTPUT - PAPER: " + outputWS[i].getPaper());
						logger.info("PROCESSTRACKSERVICE OUTPUT - ARCHIVED: " + outputWS[i].getArchived());
						logger.info("PROCESSTRACKSERVICE OUTPUT - HISTORY: " + outputWS[i].getHistory());
						logger.info("PROCESSTRACKSERVICE OUTPUT - MODULECODE: " + outputWS[i].getModuleCode());
						if ("N".equalsIgnoreCase(outputWS[i].getPaper()) && "Y".equalsIgnoreCase(outputWS[i].getArchived())) {
							signVerified++;
						}
					}
					wsOut = signVerified == outputWS.length ? "OK" : "KO";
				}
//				wsOut = "KO";
			} else {
				wsOut = "OK";
			}
			String jsonResult = "{\"result\" : \"" + wsOut + "\"}";
			
			logger.debug("JSONRESULT = " + jsonResult);
			
			response.setHeader("Content-Type", "application/json; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.write(jsonResult);
			out.flush();
			out.close();
			logger.debug("cardIssueAction.checkSignatureProcessOutcome --- end");
			return null;
		}
		
		public ActionForward checkStored(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception{
			return GecUtilities.checkStoredFirmaMia(request, response);
		}
		
		public ActionForward verify(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response) throws Exception {
			
			logger.debug("CardIssueAction.verify --- start");
			ActionForward forward;
			String retry = request.getParameter("retry");
			String verify = request.getParameter("verify");
			logger.info("VERIFY FORWARD = " + verify);
			
				if("paper".equalsIgnoreCase(verify)){
					forward = mapping.findForward("firmaMiaVerifyPaper");
				} else if ("Ok".equalsIgnoreCase(verify)){
					forward = mapping.findForward("firmaMiaVerifyOk");
				} else if("Ko".equalsIgnoreCase(verify)){
					forward = mapping.findForward("firmaMiaVerifyKo");
				} else if("firstPage".equalsIgnoreCase(verify)){
					forward = mapping.findForward("firmaMiaVerify");
				} else {
					return null;
				}
			
			
			logger.debug("CardIssueAction.verify --- end");
			return forward;
			
		}
		
		//**MC**
		public ActionForward cardIssuePrintPrepare(ActionMapping mapping, ActionForm form,
					HttpServletRequest request, HttpServletResponse response) throws Exception {
				
				logger.debug("CardIssueAction.cardIssuePrintPrepare --- start");
				ActionForward forward = null;
				XDocument[] xdocs = null;
				SessionData sessionData = (SessionData)MarkedSessionManager.getInstance().getMarkedSessionAttribute(request,"sessionData");

				String euronovate_pluginInUse = request.getParameter("euronovate_pluginInUse");
				String euronovate_plugin_ok = request.getParameter("euronovate_plugin_ok");
				String euronovate_tablet_online = request.getParameter("euronovate_tablet_online");
				String xPD_tablet_available = request.getParameter("xPD_tablet_available");
				String xPD_tablet_busy = request.getParameter("xPD_tablet_busy");
				String xPD_tablet_service_online = request.getParameter("xPD_tablet_service_online");
				String tabletConnected = request.getParameter("tabletConnected");
				String msgErrType = request.getParameter("msgErrType");
				String checkTablet = request.getParameter("checkTablet");
				logger.info("SIGNPADVARS (printPrepare) - euronovate_pluginInUse = " + euronovate_pluginInUse);
				logger.info("SIGNPADVARS (printPrepare) - euronovate_plugin_ok = " + euronovate_plugin_ok);
				logger.info("SIGNPADVARS (printPrepare) - euronovate_tablet_online = " + euronovate_tablet_online);
				logger.info("SIGNPADVARS (printPrepare) - xPD_tablet_available = " + xPD_tablet_available);
				logger.info("SIGNPADVARS (printPrepare) - xPD_tablet_busy = " + xPD_tablet_busy);
				logger.info("SIGNPADVARS (printPrepare) - xPD_tablet_service_online = " + xPD_tablet_service_online);
				logger.info("SIGNPADVARS (printPrepare) - tabletConnected = " + tabletConnected);
				logger.info("SIGNPADVARS (printPrepare) - msgErrType = " + msgErrType);
				logger.info("SIGNPADVARS (printPrepare) - checkTablet = " + checkTablet);
				
				/* MOCK - forzo per test*/
				msgErrType = "";
				
				String retry = request.getParameter("retry");
				logger.info("RETRY FROM ACTION: " + retry);
				
				//PrintDocumentResponseClass rc = new PrintDocumentResponseClass(); EE57985 in teoria ho gi� l'xdoc originale nella session
				//PrintDocumentResponseClass savedRC = new PrintDocumentResponseClass(); EE57985 in teoria ho gi� l'xdoc originale nella session
				
				//qua � come prendo io gli xdocument
				//xdocs = (XDocument[]) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "printForm"); //io il doc dovrei gi� averlo in sessione
				
				/*GecServiceFactory serviceFactory = GecServiceFactory.getInstance();
				IGecServiceFacade service = serviceFactory.getGecServiceFacade();*/
				
				String token = getProcessId(request, Integer.parseInt(retry));
				request.getSession().setAttribute("processId", token);
				
				String verticalRetryId = "";
				
				boolean goDigital = false;
				
//				String sessionMarker = (String)MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionMarker");
				String sessionMarker = request.getParameter("sessionMarker");
				try {
					if("1".equalsIgnoreCase(retry)){
						xdocs = (XDocument[]) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "printForm");
					} else {
//						xdocs = (XDocument[]) request.getSession().getAttribute("originalDocs");
						byte[] originalDocs = (byte[])request.getSession().getAttribute("originalDocs");
						ByteArrayInputStream bis = null;
						ObjectInputStream in = null;
						try {
							bis = new ByteArrayInputStream(originalDocs);
							in = new ObjectInputStream(bis);
							xdocs = (XDocument[]) in.readObject();
							in.close();
						} catch (Exception e) {
							logger.error("Error while deserializing document ", e);
						}
						logger.info("DESERIALIZATION END");
					}
						if("1".equalsIgnoreCase(retry)){
							verticalRetryId = token.substring(0, token.length()-1) + "RID";
							request.getSession().setAttribute("RID", verticalRetryId);
							
							/*XDocument[] originalDocs = new XDocument[xdocs.length];
							for (int i = 0; i < originalDocs.length; i++) {
								originalDocs[i] = new XDocument();
								BeanUtils.copyProperties(originalDocs[i], xdocs[i]);
							}*/
							ByteArrayOutputStream bos = null;
							ObjectOutputStream out = null;
							try {
								bos = new ByteArrayOutputStream();
								out = new ObjectOutputStream(bos);
								out.writeObject(xdocs);
								out.flush();
								out.close();
							} catch (Exception e) {
								logger.error("Error while serializing document ", e);
							}
							logger.info("SERIALIZATION END");
							request.getSession().setAttribute("originalDocs", bos.toByteArray());
						} else {
							verticalRetryId = (String)request.getSession().getAttribute("RID"); 
						}
						/*xdocs = rc.getPrintableDocument();*/
						
						//direi punto "Check XPI/DS2 Business Logic" - ed il metodo che fa la chiamata � checkAll()
						if(Integer.parseInt(retry) < 4 && "true".equalsIgnoreCase(checkTablet)) {
							logger.info("CHECKTABLET: TRUE");
							if(!GecUtilities.isFirmaMiaSkipTabletCheckSet() && msgErrType != null && !"".equalsIgnoreCase(msgErrType.trim())) { //SI E' VERIFICATO UN ERRORE SUL CONTROLLO TABLET
								logger.info("ERRORE SUL CONTROLLO TABLET");
								request.getSession().setAttribute("stopRetry", "true");
								
								HostResponse hr = new HostResponse();
								HostResponseMessage[] hrm = new HostResponseMessage[1];
								hrm[0] = new HostResponseMessage();
								HostResponseParams[] hrp = new HostResponseParams[1];
								hrp[0] = new HostResponseParams();
								if ("plugin".equalsIgnoreCase(msgErrType.trim())) {
									hrm[0].setMessage("XPD00001"); //message created in XDT-tool-messages (Problemi con il plugin tablet) 
									hrp[0].setParam("Per proseguire con stampa cartacea premere OK. Per interrompere premere ANNULLA e ricercare codice errore XPD00001 in UniContact");
								}
								else if ("busy".equalsIgnoreCase(msgErrType.trim())) {
									hrm[0].setMessage("XPD00002"); //message created in XDT-tool-messages (Problemi con il tablet) 
									hrp[0].setParam("Per proseguire con stampa cartacea premere OK. Per interrompere premere ANNULLA e ricercare codice errore XPD00002 in UniContact");
								}
								else if ("notConnected".equalsIgnoreCase(msgErrType.trim())) {
									hrm[0].setMessage("XPD00003"); //message created in XDT-tool-messages (Tablet non collegato) 
									hrp[0].setParam("Per proseguire con stampa cartacea premere OK. Per interrompere premere ANNULLA e ricercare codice errore XPD00003 in UniContact");
								}
								hrm[0].setHostResponseParams(hrp);
								hr.setHostResponseMessage(hrm);
								hr.setConfirmFlag(true);

								//printDocument.do penso sia la sua stampa cartacea
								String sForward = "cardIssuePrintPrepare";
								String continueUrl = "/XA-GEC-PF/exePrintNoPreview.do?sessionMarker="+ sessionMarker;
								
								ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, hr);
								complexPopUpParams.setSevereError(false);
								complexPopUpParams.setActionConfirm(continueUrl);
								complexPopUpParams.setErrorForward(sForward);
								complexPopUpParams.setForwardBackError(false);
								complexPopUpParams.setForward(sForward);
								
								logger.info("XDOCUMENT : "+xdocs);
								sessionData.setPrintForm(xdocs);
								logger.info("XDOC SESSION DATA : "+sessionData.getPrintForm());
								MarkedSessionManager.getInstance().setMarkedSessionAttribute(request,"sessionData",sessionData);
								
								return Utl.createComplexPopUp(complexPopUpParams); //se c'� stato un errore sul tablet mi fermo e mostro il popup di scelta

							} else {
								logger.info("NESSUN ERRORE SUL CONTROLLO TABLET");
								if(checkModule(xdocs) && checkBranch(xdocs[0].getBranch())) { // OK DA XPI PER FIRMA DIGITALE
									logger.info("OK DA XPI. SETTO PARAMETRI PER DIGITAL SU XDOC. ");
									request.getSession().setAttribute("stopRetry", "false");
									goDigital = true;
									ArrayList signersArray = new ArrayList();
									for (int i = 0; i < xdocs.length; i++) {
										xdocs[i].setRequestedFlow("T"); //TABLET_DIGITAL_SIGNATURE
										xdocs[i].setSignatureToken(token);
										xdocs[i].setVerticalRetryId(verticalRetryId);
										if(xdocs[i].getSigners() == null || xdocs[i].getSigners().size() == 0){
											Signer signer = new Signer();
											signer.setNdg(xdocs[i].getNdg());
											signersArray.add(signer);
											xdocs[i].setSigners(signersArray);
										}
										xdocs[i].setSignersFromCallingApp(true);
										
										//CENTERA ARCHIVING
										xdocs[i].setDocumentArchivingFlag("1");
										if(xdocs[i].getDocumentDate() == null){
											xdocs[i].setDocumentDate(new Date());
										}
									}
								} else {
									logger.info("KO DA XPI. VADO SU CARTA. ");
									request.getSession().setAttribute("stopRetry", "true");
								}
							}
							
							
						} else {
							request.getSession().setAttribute("stopRetry", "true");
						}
						logger.info("XDOCUMENT : "+xdocs);
						sessionData.setPrintForm(xdocs);
						logger.info("XDOC SESSION DATA : "+sessionData.getPrintForm());
						MarkedSessionManager.getInstance().setMarkedSessionAttribute(request,"sessionData",sessionData);
				} finally {
					/*serviceFactory.dispose(service);*/
				}
				
				if(goDigital){
					ActionRedirect redirect = new ActionRedirect("/exePrintNoPreviewFirmamia.do?sessionMarker="+ sessionMarker);
					forward = redirect;
				} else {
					ActionRedirect redirect = new ActionRedirect("/exePrintNoPreview.do?sessionMarker="+ sessionMarker);
					forward = redirect;
				}
					
				logger.debug("FORWARD : "+forward);
				logger.debug("cardIssueAction.cardIssuePrintPrepare --- end");
				
				return forward;
		}
		
		//**MC**
		public void print(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response) throws Exception {
			
			logger.debug("CardIssueAction.print --- start");
			/*//UserData userData = IfgServiceFactory.getInstance().getIfgServiceFacade().getUserInfo();
			
			//checktablet l'ho forzato a true perch� non va la stored
			
			String checkTablet = String.valueOf(checkTablet((String)MarkedSessionManager.getInstance().getMarkedSessionAttribute(request,"sessionMarker")));
			//String checkTablet = String.valueOf(true); 
			logger.info("CHECKTABLET = " + checkTablet);
			
			request.setAttribute("checkTablet", checkTablet);
			
			request.setAttribute("MAc", "false");
			
			//request.getSession().setAttribute("retry", request.getParameter("retry")); EE57985 il giro qua � diverso, nella print non ho questa info, la setta il js quando chiama la printPrepare()
			
			IEnvironment environment = EnvironmentLoader.getDefault();
			String tower = environment.get(IEnvironment.TOWER, "");
			String signpadVerifyURL = "";
			
			if("UJ".equalsIgnoreCase(tower)){
				signpadVerifyURL = "https://usjetdw002.sd01.unicreditgroup.eu/";
			} else if ("Q0".equalsIgnoreCase(tower)){
				signpadVerifyURL = "https://usjetdw002.sd01.unicreditgroup.eu/";
			} else if("C0".equalsIgnoreCase(tower)){
				signpadVerifyURL = "https://signpad.intranet.unicredit.it/";
			}
			
			request.setAttribute("signpadVerifyURL", signpadVerifyURL);*/
			
			logger.debug("CardIssueAction.print --- end");
		}
	
		private ActionForward emissBMRequestRollback(ActionMapping mapping, HttpServletRequest request, DebitCardIssueInOut inOut, String actionBackUrl, boolean isVR) throws XFRException {
			logger.info("Rollback procedure begin");
			SessionData sessionData = (SessionData) MarkedSessionManager.getInstance().getMarkedSessionAttribute(request, "sessionData");
			
			if(isVR){
				actionBackUrl += "&kind=" + sessionData.getKind();
			}
			
			GecServiceFactory serviceFactory = null;
			IGecServiceFacade serviceF = null;
			try {
				serviceFactory = GecServiceFactory.getInstance();
				serviceF = serviceFactory.getGecServiceFacade();
				logger.info("Interruzione della procedura con messaggio di successo dalla transazione GECKTV36 in rollback");
				CardIssueConfirmResponseClass classReturn = serviceF.debitCardIssueConfirmDMBRollback(inOut);
				
				ComplexPopUpParams complexPopUpParams = new ComplexPopUpParams(mapping, request, classReturn.getGaussResponse());
				
				if (!this.isGaussResponseError(classReturn.getGaussResponse())) {
					logger.info("Interrupting process with success message from GECKTV36 transaction in rollback mode");
				} else {
					logger.info("Interrupting process with error message from GECKTV36 transaction in rollback mode");
					complexPopUpParams.setSevereError(true);
				}
				// in all the two above scenarios the user will be redirected on the first page
				complexPopUpParams.setActionBackError(actionBackUrl);
				complexPopUpParams.setReturnBackError(true);
				complexPopUpParams.setActionBackMessage(actionBackUrl);
				complexPopUpParams.setReturnBackMessage(true);
				
				request.getSession().setAttribute("disableDs2Call","false");
				request.setAttribute("dmbStopPrint", "true");
				
				logger.info("Rollback procedure end");
				return Utl.createComplexPopUp(complexPopUpParams);// back to initial page after showing error message from transaction
			}catch(Exception e){
				logger.error("Error during GECKTV36 in rollback");
				throw new XFRException(e);
			} finally {
				if(serviceF != null) {
					serviceFactory.dispose(serviceF);
				}
			}
		}
		
		private String removeDataRif(String moduleListXml){
			String modifiedModuleList = moduleListXml;
			int startIndex = moduleListXml.indexOf("name=\"data_rif");
			if(startIndex != -1){
				int endIndex = moduleListXml.indexOf("</param>", startIndex) + "</param>".length();
				String substrToReplace = moduleListXml.substring(startIndex, endIndex);
				modifiedModuleList = StringUtils.replace(modifiedModuleList, substrToReplace, "name=\"data_rif\"/>");
			}
			return modifiedModuleList;
		}
}