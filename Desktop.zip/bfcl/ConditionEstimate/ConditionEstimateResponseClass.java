package it.usi.xframe.cs0.wsutil.ConditionEstimate;


import it.usi.xframe.utl.bfutil.ResponseClass;

import java.io.Serializable;

public class ConditionEstimateResponseClass extends ResponseClass implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ConditionEstimateManagementOut creditEstimateManagementOut;

	public ConditionEstimateManagementOut getCreditEstimateManagementOut() {
		return creditEstimateManagementOut;
	}

	public void setCreditEstimateManagementOut(ConditionEstimateManagementOut creditEstimateManagementOut) {
		this.creditEstimateManagementOut = creditEstimateManagementOut;
	}
	
	
}
