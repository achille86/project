package it.usi.xframe.cs0.wsutil.ConditionEstimate;

public class ConditionEstimateManagementIn {
	
	//Input
	private String estimateNumber = "";   //LK-I-INUM-PREV
	private String codFtf = "";           //LK-I-COD-FT-FIDO
	private String descFtf = "";          //LK-I-DESC-FT-FIDO
	private String ftf = "";			  //LK-I-FM-TEC-FIDO
	private String position = "";		  //LK-I-POSIZIONE
	private String amount = "";           //LK-I-IMPORTO
	private String period = "";           //LK-I-DURATA
	private String userId = "";			  //LK-I-MAT-OPE
	private String ndg = "";			  //LK-I-NDG
	private String note = "";			  //LK-I-NOTE
	private String branch = "";			  //LK-I-DIP
	private String accountType = "";	  //LK-I-TIPORAPP
	private String account = "";		  //LK-I-CONTO
	private String cost = "";			  //LK-I-SPESE-INIZ
	private String periodDay = "";		  //LK-I-DURATA-GG
	
	
	
	public String getEstimateNumber() {
		return estimateNumber;
	}
	public void setEstimateNumber(String estimateNumber) {
		this.estimateNumber = estimateNumber;
	}
	public String getCodFtf() {
		return codFtf;
	}
	public void setCodFtf(String codFtf) {
		this.codFtf = codFtf;
	}
	public String getDescFtf() {
		return descFtf;
	}
	public void setDescFtf(String descFtf) {
		this.descFtf = descFtf;
	}
	public String getFtf() {
		return ftf;
	}
	public void setFtf(String ftf) {
		this.ftf = ftf;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNdg() {
		return ndg;
	}
	public void setNdg(String ndg) {
		this.ndg = ndg;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getPeriodDay() {
		return periodDay;
	}
	public void setPeriodDay(String periodDay) {
		this.periodDay = periodDay;
	}
}
