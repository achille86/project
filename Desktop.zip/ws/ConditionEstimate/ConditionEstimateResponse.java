package it.usi.xframe.cs0.wsutil.ConditionEstimate;

import java.io.Serializable;

public class ConditionEstimateResponse implements Serializable {

	/**
	 * ConditionEstimateResponse
	 */
	private static final long serialVersionUID = 1L;
	
	private String tan = "";              //LK-O-TAN
	private String parameter = "";	      //LK-O-PARAMETRO
	private String typeRate = "";         //LK-O-TIPO-TASSO
	private String dif = "";              //LK-O-DIF
	private String taeg = "";             //LK-O-TAEG
	private String otherExpenses = "";    //LK-O-ALTRE-SPESE
	private String ftr	= "";		      //LK-O-F-TEC-RAP
	private String dateInput = "";        //LK-O-DATA-INS
	private String expirationDate = "";   //LK-O-DATA-SCA
	private String ndg = "";			  //LK-O-NDG
	private String accFido = "";		  //LK-O-ACC-FIDO
	private String descFtf = "";		  //LK-O-DESC-FT-FIDO
	private String period = "";			  //LK-O-DURATA
	private String spread = "";			  //LK-O-SPREAD		
	private String sqlcode = "";		  //LK-O-SQLCODE
	private String messageType = "";      //LK-O-TIPO-MSG
	private String messageNumber = "";	  //LK-O-NUM-MSG
	private String table = "";            //LK-O-TABELLA 
	private String totAmount = "";		  //LK-O-IMPORTO-TOT
	private String instalmentAmount = ""; //LK-O-IMPORTO-RATA
	private String currency = "";		  //LK-O-DIVISA
	private String installmentPeriod = "";//LK-O-PERIOD-RATA
	private String taex = "";			  //LK-O-TAEX
	
	public String getTan() {
		return tan;
	}
	public void setTan(String tan) {
		this.tan = tan;
	}
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	public String getTypeRate() {
		return typeRate;
	}
	public void setTypeRate(String typeRate) {
		this.typeRate = typeRate;
	}
	public String getDif() {
		return dif;
	}
	public void setDif(String dif) {
		this.dif = dif;
	}
	public String getTaeg() {
		return taeg;
	}
	public void setTaeg(String taeg) {
		this.taeg = taeg;
	}
	public String getOtherExpenses() {
		return otherExpenses;
	}
	public void setOtherExpenses(String otherExpenses) {
		this.otherExpenses = otherExpenses;
	}
	public String getFtr() {
		return ftr;
	}
	public void setFtr(String ftr) {
		this.ftr = ftr;
	}
	public String getDateInput() {
		return dateInput;
	}
	public void setDateInput(String dateInput) {
		this.dateInput = dateInput;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getNdg() {
		return ndg;
	}
	public void setNdg(String ndg) {
		this.ndg = ndg;
	}
	public String getAccFido() {
		return accFido;
	}
	public void setAccFido(String accFido) {
		this.accFido = accFido;
	}
	public String getDescFtf() {
		return descFtf;
	}
	public void setDescFtf(String descFtf) {
		this.descFtf = descFtf;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getSpread() {
		return spread;
	}
	public void setSpread(String spread) {
		this.spread = spread;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getMessageNumber() {
		return messageNumber;
	}
	public void setMessageNumber(String messageNumber) {
		this.messageNumber = messageNumber;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public String getTotAmount() {
		return totAmount;
	}
	public void setTotAmount(String totAmount) {
		this.totAmount = totAmount;
	}
	public String getInstalmentAmount() {
		return instalmentAmount;
	}
	public void setInstalmentAmount(String instalmentAmount) {
		this.instalmentAmount = instalmentAmount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getInstallmentPeriod() {
		return installmentPeriod;
	}
	public void setInstallmentPeriod(String installmentPeriod) {
		this.installmentPeriod = installmentPeriod;
	}
	public String getTaex() {
		return taex;
	}
	public void setTaex(String taex) {
		this.taex = taex;
	}
	public void setSqlcode(String sqlcode) {
		this.sqlcode = sqlcode;
	}
	public String getSqlcode() {
		return sqlcode;
	}
	
}
