package it.usi.xframe.cs0.wsutil.ConditionEstimate;


import it.usi.xframe.cs0.bfintf.ICs0ServiceFacade;
import it.usi.xframe.cs0.bfutil.Cs0ServiceFactory;
import it.usi.xframe.system.errors.XFRException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lowagie.text.pdf.codec.postscript.ParseException;

public class ConditionEstimateWS {

	static Log logger = LogFactory.getLog(ConditionEstimateWS.class);
	
	/**
	 * ConditionEstimateWS.ConditionEstimate
	 * 
	 * @param request
	 * @return
	 * @throws XFRException
	 * @throws ParseException
	 */
	public ConditionEstimateResponse conditionEstimate (ConditionEstimateRequest request) throws XFRException, ParseException {
		
		ConditionEstimateResponse response = new ConditionEstimateResponse();
		ConditionEstimateResponseClass responseClass = new ConditionEstimateResponseClass();
		
		ConditionEstimateManagementIn in = new ConditionEstimateManagementIn();
		
		// valorizzazione input
		in = conversionInput(request);
		
		try {
			Cs0ServiceFactory cs0Factory = Cs0ServiceFactory.getInstance();
			try {
				ICs0ServiceFacade cs0Service = cs0Factory.getCs0ServiceFacade();
				try {
					// chiamata a host alla stored CS0SPPSO
					responseClass = cs0Service.getConditionEstimate(in);
					
				} finally {
					cs0Factory.dispose(cs0Service);
				}
			} catch (Exception e) {
				logger.error("ConditionEstimateWS.ConditionEstimate - error (1): " + e.getMessage());
				throw new Exception(e);
			}
		} catch (Exception ex) {
			logger.error("ConditionEstimateWS.ConditionEstimate - error (2): " + ex.getMessage());
		}
		
		response = conversionResponse(responseClass);
		
		return response;
		
	}
	
	private ConditionEstimateManagementIn conversionInput (ConditionEstimateRequest request){
		
		ConditionEstimateManagementIn in = new ConditionEstimateManagementIn();
		
		in.setEstimateNumber(request.getEstimateNumber());
		in.setCodFtf(request.getCodFtf());
		in.setDescFtf(request.getDescFtf());
		in.setFtf(request.getFtf());
		in.setPosition(request.getPosition());
		in.setAmount(request.getAmount());
		in.setPeriod(request.getPeriod());
		in.setUserId(request.getUserId());
		in.setNdg(request.getNdg());
		in.setNote(request.getNote());
		in.setBranch(request.getBranch());
		in.setAccountType(request.getAccountType());
		in.setAccount(request.getAccount());
		in.setCost(request.getCost());
		in.setPeriodDay(request.getPeriodDay());

		return in;
	}
	private ConditionEstimateResponse conversionResponse (ConditionEstimateResponseClass responseClass){
		ConditionEstimateManagementOut out;
		out = responseClass.getCreditEstimateManagementOut();
		ConditionEstimateResponse response = new ConditionEstimateResponse();
		
		response.setTan(out.getTan());
		response.setParameter(out.getParameter());
		response.setTypeRate(out.getTypeRate());
		response.setDif(out.getDif());
		response.setTaeg(out.getTaeg());
		response.setOtherExpenses(out.getOtherExpenses());
		response.setFtr(out.getFtr());
		response.setDateInput(out.getDateInput());
		response.setExpirationDate(out.getExpirationDate());
		response.setNdg(out.getNdg());
		response.setAccFido(out.getAccFido());
		response.setDescFtf(out.getDescFtf());
		response.setPeriod(out.getPeriod());
		response.setSpread(out.getSpread());	
		response.setSqlcode(out.getSqlcode());
		response.setMessageType(out.getMessageType());
		response.setMessageNumber(out.getMessageNumber());
		response.setTable(out.getTable());
		response.setTotAmount(out.getTotAmount());
		response.setInstalmentAmount(out.getInstalmentAmount());
		response.setCurrency(out.getCurrency());
		response.setInstallmentPeriod(out.getInstallmentPeriod());
		response.setTaex(out.getTaex());
		
		
		return response;
	}
	
}
