package it.usi.xframe.cs0.bfimpl.conditionEstimate;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import it.usi.xframe.cs0.bfimpl.pm.CS0PersistenceManager;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryManagementInOut;
import it.usi.xframe.cs0.wsutil.ConditionCreditInquiry.ConditionCreditInquiryResponseClass;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateManagementIn;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateManagementOut;
import it.usi.xframe.cs0.wsutil.ConditionEstimate.ConditionEstimateResponseClass;
import it.usi.xframe.system.errors.XFRException;
import it.usi.xframe.utl.bfutil.FormatUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ConditionEstimatePersistanceManager extends CS0PersistenceManager {
	private Log logger = LogFactory.getLog(this.getClass());
	
	private static ConditionEstimatePersistanceManager instance;

	public static ConditionEstimatePersistanceManager getInstance() {

		if (instance == null)
			instance = new ConditionEstimatePersistanceManager();

		return instance;
	}
		
	
	
	public ConditionEstimateResponseClass getConditionEstimate(ConditionEstimateManagementIn in) throws XFRException,	RemoteException {

		logger.info("ConditionCreditEstimatePersistanceManager.getConditionEstimate ---- begin");

		ConditionEstimateResponseClass responseClass = new ConditionEstimateResponseClass();
		ConditionEstimateManagementOut out = new ConditionEstimateManagementOut();

		Connection connection = getConnectionForCOBOLStoreProcedure("CS0SPPSO",	true);
		CallableStatement statement = null;

		// preparo lo statement con la chiamata alla stored procedure
		try {
			String sql = "CALL DB2C.CS0SPPSO(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			statement = connection.prepareCall(sql);

			// Parametri di input
			statement.registerOutParameter(1, Types.DECIMAL);
			statement.registerOutParameter(2, Types.VARCHAR);
			statement.registerOutParameter(3, Types.VARCHAR);
			statement.registerOutParameter(4, Types.VARCHAR);
			statement.registerOutParameter(5, Types.VARCHAR);
			statement.registerOutParameter(6, Types.DECIMAL);
			statement.registerOutParameter(7, Types.DECIMAL);
			statement.registerOutParameter(8, Types.VARCHAR);
			statement.registerOutParameter(9, Types.VARCHAR);
			statement.registerOutParameter(10, Types.VARCHAR);
			statement.registerOutParameter(11, Types.DECIMAL);
			statement.registerOutParameter(12, Types.VARCHAR);
			statement.registerOutParameter(13, Types.DECIMAL);
			statement.registerOutParameter(14, Types.DECIMAL);
			statement.registerOutParameter(15, Types.DECIMAL);

			// parametri di output
			statement.registerOutParameter(16, Types.DECIMAL);
			statement.registerOutParameter(17, Types.VARCHAR);
			statement.registerOutParameter(18, Types.VARCHAR);
			statement.registerOutParameter(19, Types.DECIMAL);
			statement.registerOutParameter(20, Types.DECIMAL);
			statement.registerOutParameter(21, Types.DECIMAL);
			statement.registerOutParameter(22, Types.VARCHAR);
			statement.registerOutParameter(23, Types.VARCHAR);
			statement.registerOutParameter(24, Types.VARCHAR);
			statement.registerOutParameter(25, Types.VARCHAR);
			statement.registerOutParameter(26, Types.DECIMAL);
			statement.registerOutParameter(27, Types.VARCHAR);
			statement.registerOutParameter(28, Types.DECIMAL);
			statement.registerOutParameter(29, Types.DECIMAL);
			statement.registerOutParameter(30, Types.VARCHAR);
			statement.registerOutParameter(31, Types.VARCHAR);
			statement.registerOutParameter(32, Types.VARCHAR);
			statement.registerOutParameter(33, Types.VARCHAR);
			statement.registerOutParameter(34, Types.DECIMAL);
			statement.registerOutParameter(35, Types.DECIMAL);
			statement.registerOutParameter(36, Types.VARCHAR);
			statement.registerOutParameter(37, Types.VARCHAR);
			statement.registerOutParameter(38, Types.DECIMAL);

			// valorizzazione input
			if (in.getEstimateNumber() == null
					|| " ".equalsIgnoreCase(in.getEstimateNumber())
					|| "".equalsIgnoreCase(in.getEstimateNumber())
					|| !StringUtils.isNumeric(in.getEstimateNumber())) {
				in.setEstimateNumber("0");
			}
			statement.setBigDecimal(1, new BigDecimal(in.getEstimateNumber()));
			logger.debug("estimateNumber 1: " + in.getEstimateNumber());

			statement.setString(2, FormatUtils.formatString(in.getCodFtf()));
			logger.debug("codFtf 2: " + in.getCodFtf());
			
			statement.setString(3, FormatUtils.formatString(in.getDescFtf()));
			logger.debug("descFtf 3: " + in.getDescFtf());
			
			statement.setString(4, FormatUtils.formatString(in.getFtf()));
			logger.debug("ftf 4: " + in.getFtf());
			
			statement.setString(5, FormatUtils.formatString(in.getPosition()));
			logger.debug("position 5: " + in.getPosition());
						
			if (in.getAmount() == null
					|| " ".equalsIgnoreCase(in.getAmount())
					|| "".equalsIgnoreCase(in.getAmount())
					|| !StringUtils.isNumeric(in.getAmount())) {
				in.setAmount("0");
			}
			statement.setBigDecimal(6, new BigDecimal(in.getAmount()));
			logger.debug("amount 6: " + in.getAmount());
			
			if (in.getPeriod() == null
					|| " ".equalsIgnoreCase(in.getPeriod())
					|| "".equalsIgnoreCase(in.getPeriod())
					|| !StringUtils.isNumeric(in.getPeriod())) {
				in.setPeriod("0");
			}
			statement.setBigDecimal(7, new BigDecimal(in.getPeriod()));
			logger.debug("period() 7: " + in.getPeriod());
			
			statement.setString(8, FormatUtils.formatString(in.getUserId()));
			logger.debug("userid 8: " + in.getUserId());
			
			statement.setString(9, FormatUtils.formatString(in.getNdg()));
			logger.debug("ndg 9: " + in.getNdg());
			
			statement.setString(10, FormatUtils.formatString(in.getNote()));
			logger.debug("userid 10: " + in.getNote());
			
			if (in.getBranch() == null
					|| " ".equalsIgnoreCase(in.getBranch())
					|| "".equalsIgnoreCase(in.getBranch())
					|| !StringUtils.isNumeric(in.getBranch())) {
				in.setBranch("0");
			}
			statement.setBigDecimal(11, new BigDecimal(in.getBranch()));
			logger.debug("branch 11: " + in.getBranch());
			
			statement.setString(12, FormatUtils.formatString(in.getAccountType()));
			logger.debug("userid 12: " + in.getAccountType());
			
			statement.setString(13, FormatUtils.formatString(in.getAccount()));
			logger.debug("userid 13: " + in.getAccount());
			
			if (in.getCost() == null
					|| " ".equalsIgnoreCase(in.getCost())
					|| "".equalsIgnoreCase(in.getCost())
					|| !StringUtils.isNumeric(in.getCost())) {
				in.setCost("0");
			}
			statement.setBigDecimal(14, new BigDecimal(in.getCost()));
			logger.debug("branch 14: " + in.getCost());
			
			if (in.getCost() == null
					|| " ".equalsIgnoreCase(in.getCost())
					|| "".equalsIgnoreCase(in.getCost())
					|| !StringUtils.isNumeric(in.getCost())) {
				in.setCost("0");
			}
			statement.setBigDecimal(15, new BigDecimal(in.getPeriodDay()));
			logger.debug("periodDay 15: " + in.getPeriodDay());
			
			// richiamo della stored
			statement.execute();


			out = output(statement);
			responseClass.setCreditEstimateManagementOut(out);

		} catch (SQLException e) {
			// e.printStackTrace();
			logger.info("ConditionEstimatePersistanceManager.getConditionEstimate - error (1): "
					+ e.getMessage());
			throw new XFRException(e);
		} finally {
			try {
				// chiudo connessione e statement per liberare risorse
				connection.close();
				statement.close();
			} catch (SQLException e) {
				// e.printStackTrace();
				logger.info("ConditionEstimatePersistanceManager.getConditionEstimate - error (2): "
						+ e.getMessage());
				throw new XFRException(e);
			}
		}

		logger.info("ConditionCreditInquiryPersistanceManager.getConditionCreditInquiry ---- end");
		return responseClass;
	}
		
	
	private ConditionEstimateManagementOut output(CallableStatement statement) throws XFRException, RemoteException {
		logger.debug("ConditionEstimateManagementInOut.output ---- begin");

		ConditionEstimateManagementOut out = new ConditionEstimateManagementOut();

		try {
			out.setTan(statement.getString("LK_O_TAN"));
			out.setParameter(statement.getString("LK_O_PARAMETRO"));
			out.setTypeRate(statement.getString("LK_O_TIPO_TASSO"));
			out.setDif(statement.getString("LK_O_DIF"));
			out.setTaeg(statement.getString("LK_O_TAEG"));
			out.setOtherExpenses(statement.getString("LK_O_ALTRE_SPESE"));
			out.setFtr(statement.getString("LK_O_F_TEC_RAP"));
			out.setDateInput(statement.getString("LK_O_DATA_INS"));
			out.setExpirationDate(statement.getString("LK_O_DATA_SCA"));
			out.setNdg(statement.getString("LK-O-NDG"));
			out.setAccFido(statement.getString("LK_O_ACC_FIDO"));
			out.setDescFtf(statement.getString("LK_O_DESC_FT_FIDO"));
			out.setPeriod(statement.getString("LK-O-DURATA"));
			out.setSpread(statement.getString("LK-O-SPREAD"));
			out.setSqlcode(statement.getString("LK-O-SQLCODE"));
			out.setMessageType(statement.getString("LK-O-TIPO-MSG"));
			out.setMessageNumber(statement.getString("LK-O-NUM-MSG"));
			out.setTable(statement.getString("LK-O-TABELLA"));
			out.setTotAmount(statement.getString("LK-O-IMPORTO-TOT"));
			out.setInstalmentAmount(statement.getString("LK-O-IMPORTO-RATA"));
			out.setCurrency(statement.getString("LK-O-DIVISA"));
			out.setInstallmentPeriod(statement.getString("LK-O-PERIOD-RATA"));
			out.setTaex(statement.getString("LK-O-TAEX"));
			
			
		} catch (SQLException e) {
			//e.printStackTrace();
			logger.info("ConditionEstimatePersistanceManager.output - error (1): " + e.getMessage());
		}
		
		logger.debug("ConditionEstimatePersistanceManager.output ---- end");
		return out;
	}
	

}
